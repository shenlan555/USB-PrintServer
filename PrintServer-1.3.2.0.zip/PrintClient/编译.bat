@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
set w=80 & set h=30
powershell -command "$host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(%w%, 9999); $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(%w%, %h%)" 2>nul
title 网络打印客户端编译
echo.
echo =========================================
echo   网络打印客户端编译工具
echo =========================================
echo.
echo 正在关闭旧进程...
taskkill /f /im PrintClient.exe >nul 2>&1
echo.

C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe PrintClient.csproj /t:Rebuild /p:Configuration=Release

if %errorlevel% equ 0 (
    echo.
    echo ====================================
    echo   编译成功！
    echo ====================================
    echo   输出: bin\PrintClient-v1.3.1.1\PrintClient.exe
    echo.
) else (
    echo.
    echo ====================================
    echo   编译失败，请检查错误信息！
    echo ====================================
    echo.
)
timeout /n 1