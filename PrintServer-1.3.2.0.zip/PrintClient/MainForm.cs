using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrintClient
{
    public class MainForm : Form
    {
        // 服务器连接
        private ComboBox cboServerAddress;
        private NumericUpDown nudApiPort;
        private Button btnScan;
        private Button btnConnect;
        private Label lblConnectStatus;

        // 打印机信息
        private GroupBox gbPrinterInfo;
        private DataGridView dgvPrinters;
        private Label lblServerInfo;

        // 操作
        private TextBox txtPrinterName;
        private Button btnDownloadInstall;
        private Button btnDownloadOnly;
        private ProgressBar progressBar;
        private Label lblProgress;
        private TextBox txtLog;

        private DriverDownloader.ServerPrinterInfo _printerInfo;
        private bool _isScanning = false;

        public MainForm()
        {
            InitializeComponent();
            LoadLocalSubnets();
        }

        private void InitializeComponent()
        {
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            string productName = "";
            string companyName = "";
            object[] productAttrs = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyProductAttribute), false);
            if (productAttrs.Length > 0)
                productName = ((System.Reflection.AssemblyProductAttribute)productAttrs[0]).Product;
            object[] companyAttrs = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyCompanyAttribute), false);
            if (companyAttrs.Length > 0)
                companyName = ((System.Reflection.AssemblyCompanyAttribute)companyAttrs[0]).Company;
            string version = assembly.GetName().Version.ToString();

            this.Text = string.Format("{0} - v{1} - By：{2}", productName, version, companyName);
            this.Size = new Size(660, 700);
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using (var stream = asm.GetManifestResourceStream("PrintClient.appicon.ico"))
            {
                if (stream != null)
                    this.Icon = new System.Drawing.Icon(stream);
            }
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(245, 247, 250);

            Font baseFont = new Font("微软雅黑", 9F);
            Font boldFont = new Font("微软雅黑", 9F, FontStyle.Bold);
            Font titleFont = new Font("微软雅黑", 12F, FontStyle.Bold);

            // ========== 顶部标题栏 ==========
            Panel pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(660, 52),
                BackColor = Color.FromArgb(30, 60, 120)
            };

            Label lblTitle = new Label()
            {
                Text = "🖨️  网络打印客户端",
                Location = new Point(18, 10),
                AutoSize = true,
                Font = titleFont,
                ForeColor = Color.White
            };

            Label lblSubtitle = new Label()
            {
                Text = "自动发现 · 一键安装 · 即装即用",
                Location = new Point(18, 32),
                AutoSize = true,
                Font = new Font("微软雅黑", 8F),
                ForeColor = Color.FromArgb(180, 200, 230)
            };
            pnlHeader.Controls.AddRange(new Control[] { lblTitle, lblSubtitle });

            // ========== 服务器连接组 ==========
            GroupBox gbConnect = new GroupBox()
            {
                Text = "  🔍  服务器连接",
                Location = new Point(12, 60),
                Size = new Size(620, 105),
                Font = boldFont,
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            Label lblServer = new Label()
            {
                Text = "地址/IP:",
                Location = new Point(14, 26),
                AutoSize = true,
                Font = baseFont
            };

            cboServerAddress = new ComboBox()
            {
                Location = new Point(70, 23),
                Size = new Size(340, 24),
                Font = baseFont,
                DropDownStyle = ComboBoxStyle.DropDown,
                Text = ""
            };

            Label lblPort = new Label()
            {
                Text = "端口:",
                Location = new Point(418, 26),
                AutoSize = true,
                Font = baseFont
            };

            nudApiPort = new NumericUpDown()
            {
                Location = new Point(456, 23),
                Size = new Size(60, 24),
                Minimum = 1,
                Maximum = 65535,
                Value = 9180,
                Font = baseFont
            };

            btnScan = new Button()
            {
                Text = "📡 扫描局域网",
                Location = new Point(14, 54),
                Size = new Size(110, 28),
                Font = new Font("微软雅黑", 9F),
                BackColor = Color.FromArgb(100, 140, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnScan.FlatAppearance.BorderSize = 0;
            btnScan.Click += BtnScan_Click;

            btnConnect = new Button()
            {
                Text = "🔗 连接",
                Location = new Point(132, 54),
                Size = new Size(90, 28),
                Font = boldFont,
                BackColor = Color.FromArgb(60, 160, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnConnect.FlatAppearance.BorderSize = 0;
            btnConnect.Click += BtnConnect_Click;

            lblConnectStatus = new Label()
            {
                Text = "就绪 - 请扫描或输入服务器地址",
                Location = new Point(14, 86),
                Size = new Size(534, 14),
                Font = new Font("微软雅黑", 8F),
                ForeColor = Color.FromArgb(120, 120, 140)
            };

            gbConnect.Controls.AddRange(new Control[] {
                lblServer, cboServerAddress, lblPort, nudApiPort, btnScan, btnConnect, lblConnectStatus
            });

            // ========== 打印机信息组（DataGridView表格） ==========
            gbPrinterInfo = new GroupBox()
            {
                Text = "  📋  打印机列表（单击选中，双击安装）",
                Location = new Point(12, 173),
                Size = new Size(620, 208),
                Font = boldFont,
                ForeColor = Color.FromArgb(50, 50, 80),
                Visible = false
            };

            // 服务器信息标签
            lblServerInfo = new Label()
            {
                Text = "",
                Location = new Point(14, 17),
                Size = new Size(592, 16),
                Font = new Font("微软雅黑", 8F),
                ForeColor = Color.FromArgb(100, 120, 160)
            };

            // DataGridView 表格
            dgvPrinters = new DataGridView()
            {
                Location = new Point(14, 36),
                Size = new Size(592, 136),
                Font = new Font("微软雅黑", 9F),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                ReadOnly = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 24,
                RowTemplate = { Height = 22 }
            };

            // 列定义
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colName",
                HeaderText = "打印机名称",
                FillWeight = 38,
                MinimumWidth = 130,
                HeaderCell = { Style = { Alignment = DataGridViewContentAlignment.MiddleCenter } }
            });
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colPort",
                HeaderText = "端口",
                FillWeight = 8,
                MinimumWidth = 50,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter },
                HeaderCell = { Style = { Alignment = DataGridViewContentAlignment.MiddleCenter } }
            });
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colSize",
                HeaderText = "大小",
                FillWeight = 8,
                MinimumWidth = 55,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter },
                HeaderCell = { Style = { Alignment = DataGridViewContentAlignment.MiddleCenter } }
            });
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colStatus",
                HeaderText = "状态",
                FillWeight = 12,
                MinimumWidth = 80,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter },
                HeaderCell = { Style = { Alignment = DataGridViewContentAlignment.MiddleCenter } }
            });

            // 美化表头
            dgvPrinters.EnableHeadersVisualStyles = false;
            dgvPrinters.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(240, 242, 245);
            dgvPrinters.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(50, 50, 80);
            dgvPrinters.ColumnHeadersDefaultCellStyle.Font = new Font("微软雅黑", 9F, FontStyle.Bold);
            dgvPrinters.ColumnHeadersDefaultCellStyle.Padding = new Padding(0, 2, 0, 2);
            dgvPrinters.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvPrinters.DefaultCellStyle.SelectionBackColor = Color.FromArgb(210, 228, 255);
            dgvPrinters.DefaultCellStyle.SelectionForeColor = Color.Black;

            dgvPrinters.SelectionChanged += DgvPrinters_SelectionChanged;
            dgvPrinters.CellDoubleClick += DgvPrinters_CellDoubleClick;

            // 安装名称输入
            Label lblInstallName = new Label()
            {
                Text = "安装名称:",
                Location = new Point(14, 176),
                AutoSize = true,
                Font = baseFont
            };

            txtPrinterName = new TextBox()
            {
                Location = new Point(84, 174),
                Size = new Size(280, 22),
                Font = baseFont,
                Text = ""
            };

            gbPrinterInfo.Controls.AddRange(new Control[] { lblServerInfo, dgvPrinters, lblInstallName, txtPrinterName });

            // ========== 操作组 ==========
            GroupBox gbAction = new GroupBox()
            {
                Text = "  ⚡  操作",
                Location = new Point(12, 389),
                Size = new Size(620, 55),
                Font = boldFont,
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            btnDownloadInstall = new Button()
            {
                Text = "📥 一键下载并安装选中打印机",
                Location = new Point(14, 18),
                Size = new Size(210, 28),
                Font = boldFont,
                BackColor = Color.FromArgb(60, 160, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnDownloadInstall.FlatAppearance.BorderSize = 0;
            btnDownloadInstall.Click += BtnDownloadInstall_Click;

            btnDownloadOnly = new Button()
            {
                Text = "💾 仅下载驱动",
                Location = new Point(232, 18),
                Size = new Size(100, 28),
                Font = baseFont,
                BackColor = Color.FromArgb(100, 140, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false
            };
            btnDownloadOnly.FlatAppearance.BorderSize = 0;
            btnDownloadOnly.Click += BtnDownloadOnly_Click;

            progressBar = new ProgressBar()
            {
                Location = new Point(340, 20),
                Size = new Size(90, 24),
                Style = ProgressBarStyle.Continuous,
                Visible = false
            };

            lblProgress = new Label()
            {
                Text = "",
                Location = new Point(434, 22),
                Size = new Size(70, 20),
                Font = new Font("微软雅黑", 8F),
                ForeColor = Color.FromArgb(120, 120, 140),
                TextAlign = ContentAlignment.MiddleRight
            };

            var btnClearLog = new Button()
            {
                Text = "🗑 清空",
                Location = new Point(510, 18),
                Size = new Size(60, 28),
                Font = new Font("微软雅黑", 8F),
                BackColor = Color.FromArgb(180, 120, 110),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnClearLog.FlatAppearance.BorderSize = 0;
            btnClearLog.Click += (s, ev) => { txtLog.Clear(); Log("日志已清空"); };

            gbAction.Controls.AddRange(new Control[] { btnDownloadInstall, btnDownloadOnly, progressBar, lblProgress, btnClearLog });

            // ========== 日志组 ==========
            GroupBox gbLog = new GroupBox()
            {
                Text = "  📝  运行日志",
                Location = new Point(12, 452),
                Size = new Size(620, 202),
                Font = boldFont,
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            txtLog = new TextBox()
            {
                Location = new Point(14, 22),
                Size = new Size(592, 168),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                BackColor = Color.FromArgb(30, 32, 38),
                ForeColor = Color.FromArgb(180, 220, 180),
                Font = new Font("Consolas", 8.5F),
                BorderStyle = BorderStyle.None
            };

            gbLog.Controls.Add(txtLog);

            // 添加到窗体
            this.Controls.AddRange(new Control[] {
                pnlHeader, gbConnect, gbPrinterInfo, gbAction, gbLog
            });
        }

        #region 事件处理

        /// <summary>
        /// 自动检测本机网段并预填到地址下拉框
        /// </summary>
        private void LoadLocalSubnets()
        {
            try
            {
                var prefixes = LanScanner.GetLocalSubnetPrefixes();
                cboServerAddress.Items.Clear();

                if (prefixes.Count > 0)
                {
                    // 为每个网段生成常见网关地址（.1 和 .254），让用户可以直接扫描
                    foreach (string prefix in prefixes)
                    {
                        cboServerAddress.Items.Add(prefix + "1");
                        cboServerAddress.Items.Add(prefix + "254");
                    }
                    // 不自动选中，仅填充建议列表
                    cboServerAddress.SelectedIndex = -1;
                    cboServerAddress.Text = "";
                    lblConnectStatus.Text = "就绪 - 已检测到本地网段 " + string.Join(", ", prefixes) + "*";
                    lblConnectStatus.ForeColor = Color.FromArgb(40, 140, 60);
                }
                else
                {
                    cboServerAddress.Text = "";
                    lblConnectStatus.Text = "就绪 - 未检测到局域网，请手动输入服务器地址";
                    lblConnectStatus.ForeColor = Color.FromArgb(200, 120, 40);
                }
            }
            catch
            {
                cboServerAddress.Text = "";
                lblConnectStatus.Text = "就绪 - 请扫描或输入服务器地址";
                lblConnectStatus.ForeColor = Color.FromArgb(120, 120, 140);
            }
        }

        private async void BtnScan_Click(object sender, EventArgs e)
        {
            if (_isScanning) return;

            _isScanning = true;
            btnScan.Enabled = false;
            btnConnect.Enabled = false;
            btnScan.Text = "⏳ 扫描中...";
            cboServerAddress.Items.Clear();
            cboServerAddress.Text = "";
            lblConnectStatus.Text = "正在扫描局域网...";
            lblConnectStatus.ForeColor = Color.FromArgb(120, 120, 140);

            try
            {
                int apiPort = (int)nudApiPort.Value;
                Log("📡 开始扫描局域网 (端口 " + apiPort + ")...");

                var scanProgress = new Progress<string>(msg =>
                {
                    Log("  " + msg);
                    lblConnectStatus.Text = msg;
                });

                var results = await Task.Run(() => LanScanner.ScanAsync(apiPort, scanProgress));

                foreach (var result in results)
                {
                    string hostname = CleanHostname(result.Hostname);
                    string display = result.IpAddress;
                    if (!string.IsNullOrEmpty(hostname) && hostname != result.IpAddress)
                        display += "  (" + hostname + ")";
                    cboServerAddress.Items.Add(display);
                }

                if (cboServerAddress.Items.Count > 0)
                {
                    cboServerAddress.SelectedIndex = 0;
                    lblConnectStatus.Text = string.Format("✅ 扫描完成，发现 {0} 台服务器，自动连接中...",
                        results.Count);
                    lblConnectStatus.ForeColor = Color.FromArgb(40, 140, 60);

                    // 扫描到后自动连接第一台服务器，显示打印机信息
                    await ConnectToServer(results[0].IpAddress, (int)nudApiPort.Value);
                }
                else
                {
                    lblConnectStatus.Text = "未发现打印服务器，请手动输入地址";
                    lblConnectStatus.ForeColor = Color.FromArgb(200, 120, 40);
                }
            }
            catch (Exception ex)
            {
                lblConnectStatus.Text = "扫描出错: " + ex.Message;
                lblConnectStatus.ForeColor = Color.Red;
                Log("❌ 扫描错误: " + ex.Message);
            }
            finally
            {
                _isScanning = false;
                btnScan.Enabled = true;
                btnConnect.Enabled = true;
                btnScan.Text = "📡 扫描局域网";
            }
        }

        private async void BtnConnect_Click(object sender, EventArgs e)
        {
            string rawServer = cboServerAddress.Text.Trim();
            int spaceIdx = rawServer.IndexOf(' ');
            string server = spaceIdx > 0 ? rawServer.Substring(0, spaceIdx).Trim() : rawServer;

            if (string.IsNullOrEmpty(server))
            {
                MessageBox.Show("请输入或选择服务器地址！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            await ConnectToServer(server, (int)nudApiPort.Value);
        }

        /// <summary>
        /// 连接到指定服务器并获取打印机信息
        /// </summary>
        private async Task ConnectToServer(string server, int apiPort)
        {
            btnConnect.Enabled = false;
            btnConnect.Text = "⏳ 连接中...";
            lblConnectStatus.Text = "正在连接...";
            lblConnectStatus.ForeColor = Color.Gray;
            gbPrinterInfo.Visible = false;
            btnDownloadInstall.Enabled = false;
            btnDownloadOnly.Enabled = false;

            try
            {
                var downloader = new DriverDownloader(server, apiPort);

                Log("正在连接 " + server + ":" + apiPort + " ...");

                bool connected = await Task.Run(() => downloader.TestConnectionAsync());
                if (!connected)
                {
                    lblConnectStatus.Text = "❌ 无法连接到服务器，请检查地址和端口";
                    lblConnectStatus.ForeColor = Color.Red;
                    Log("❌ 连接失败");
                    return;
                }

                Log("✅ 服务器连接成功，正在获取打印机信息...");

                _printerInfo = await Task.Run(() => downloader.GetPrinterInfoAsync());

                // 更新服务器信息
                lblServerInfo.Text = string.Format("🖥️ {0}  |  v{1}  |  {2} 台打印机",
                    CleanHostname(_printerInfo.Hostname),
                    _printerInfo.Version ?? "?",
                    _printerInfo.Printers.Count);

                // 填充 DataGridView 表格
                dgvPrinters.Rows.Clear();
                foreach (var p in _printerInfo.Printers)
                {
                    string statusIcon = p.HasDriver ? "✅ 驱动可用" : "⚠ 未找到驱动";
                    dgvPrinters.Rows.Add(
                        p.Name,
                        p.Port.ToString(),
                        p.DriverSize ?? "-",
                        statusIcon
                    );
                }

                gbPrinterInfo.Visible = true;

                UpdateButtonState();

                lblConnectStatus.Text = string.Format("✅ 已连接 - {0} 台打印机可用", _printerInfo.Printers.Count);
                lblConnectStatus.ForeColor = Color.Green;
                Log(string.Format("✅ 打印机信息获取成功 - {0} 台打印机", _printerInfo.Printers.Count));
            }
            catch (Exception ex)
            {
                lblConnectStatus.Text = "❌ 连接错误: " + ex.Message;
                lblConnectStatus.ForeColor = Color.Red;
                Log("❌ 错误: " + ex.Message);
            }
            finally
            {
                btnConnect.Enabled = true;
                btnConnect.Text = "🔗 连接";
            }
        }

        /// <summary>
        /// DataGridView 行选中变化
        /// </summary>
        private void DgvPrinters_SelectionChanged(object sender, EventArgs e)
        {
            if (_printerInfo == null || dgvPrinters.SelectedRows.Count == 0)
                return;

            int idx = dgvPrinters.SelectedRows[0].Index;
            if (idx >= _printerInfo.Printers.Count)
                return;

            var selected = _printerInfo.Printers[idx];

            // 更新 _printerInfo 默认信息（用于下载安装）
            _printerInfo.PrinterName = selected.Name;
            _printerInfo.TcpPort = selected.Port;
            _printerInfo.DriverName = selected.DriverName;
            _printerInfo.DriverVersion = selected.DriverVersion;
            _printerInfo.DriverDate = selected.DriverDate;
            _printerInfo.Manufacturer = selected.Manufacturer;
            _printerInfo.HasDriver = selected.HasDriver;
            _printerInfo.DriverFileCount = selected.DriverFileCount;
            _printerInfo.DriverSize = selected.DriverSize;

            txtPrinterName.Text = selected.Name.Trim() + "(共享)";

            UpdateButtonState();
        }

        /// <summary>
        /// 双击行直接安装
        /// </summary>
        private void DgvPrinters_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            // 确保当前行被选中
            dgvPrinters.Rows[e.RowIndex].Selected = true;

            if (_printerInfo != null && e.RowIndex < _printerInfo.Printers.Count)
            {
                var selected = _printerInfo.Printers[e.RowIndex];
                if (selected.HasDriver && btnDownloadInstall.Enabled)
                {
                    // 异步触发安装
                    BeginInvoke((Action)(async () => await DownloadAndInstall(true)));
                }
            }
        }

        private void UpdateButtonState()
        {
            if (_printerInfo == null || dgvPrinters.SelectedRows.Count == 0)
            {
                btnDownloadInstall.Enabled = false;
                btnDownloadOnly.Enabled = false;
                return;
            }

            int idx = dgvPrinters.SelectedRows[0].Index;
            bool hasDriver = false;
            if (idx >= 0 && idx < _printerInfo.Printers.Count)
                hasDriver = _printerInfo.Printers[idx].HasDriver;

            btnDownloadInstall.Enabled = hasDriver;
            btnDownloadOnly.Enabled = hasDriver;
        }

        /// <summary>
        /// 弹出选择框让用户选择用主机名还是IP连接打印机
        /// </summary>
        private string ShowAddressSelector(string hostname, string ip)
        {
            var form = new Form()
            {
                Text = "打印机连接方式",
                Size = new Size(400, 165),
                StartPosition = FormStartPosition.CenterParent,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            };

            var lbl = new Label()
            {
                Text = "请选择打印机连接地址：",
                Location = new Point(16, 16),
                AutoSize = true,
                Font = new Font("微软雅黑", 9F)
            };

            var btnHost = new Button()
            {
                Text = "🖥️ 主机名: " + hostname,
                Location = new Point(16, 46),
                Size = new Size(350, 32),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                BackColor = Color.FromArgb(40, 140, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.Yes
            };
            btnHost.FlatAppearance.BorderSize = 0;

            var btnIp = new Button()
            {
                Text = "🌐 IP地址: " + ip,
                Location = new Point(16, 86),
                Size = new Size(350, 32),
                Font = new Font("微软雅黑", 9F),
                BackColor = Color.FromArgb(100, 140, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                DialogResult = DialogResult.No
            };
            btnIp.FlatAppearance.BorderSize = 0;

            form.Controls.AddRange(new Control[] { lbl, btnHost, btnIp });
            form.AcceptButton = btnHost;
            form.CancelButton = btnIp;

            return form.ShowDialog() == DialogResult.Yes ? hostname : ip;
        }

        /// <summary>
        /// 清理主机名，去掉 .lan .local 等域后缀
        /// </summary>
        private string CleanHostname(string hostname)
        {
            if (string.IsNullOrEmpty(hostname))
                return hostname;
            int dotIdx = hostname.IndexOf('.');
            if (dotIdx > 0)
                return hostname.Substring(0, dotIdx);
            return hostname;
        }

        private async void BtnDownloadInstall_Click(object sender, EventArgs e)
        {
            await DownloadAndInstall(true);
        }

        private async void BtnDownloadOnly_Click(object sender, EventArgs e)
        {
            await DownloadAndInstall(false);
        }

        private async Task DownloadAndInstall(bool doInstall)
        {
            if (_printerInfo == null)
            {
                MessageBox.Show("请先连接服务器！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 检查是否选中了打印机
            if (dgvPrinters.SelectedRows.Count == 0)
            {
                MessageBox.Show("请先在打印机列表中选中一台打印机！", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int selectedIndex = dgvPrinters.SelectedRows[0].Index;
            if (selectedIndex < 0 || selectedIndex >= _printerInfo.Printers.Count)
            {
                MessageBox.Show("选中的打印机无效，请重新选择！", "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            btnDownloadInstall.Enabled = false;
            btnDownloadOnly.Enabled = false;
            btnConnect.Enabled = false;
            progressBar.Visible = true;
            progressBar.Value = 0;
            lblProgress.Text = "";

            try
            {
                string rawServer = cboServerAddress.Text.Trim();
                int spaceIdx2 = rawServer.IndexOf(' ');
                string server = spaceIdx2 > 0 ? rawServer.Substring(0, spaceIdx2).Trim() : rawServer;
                int apiPort = (int)nudApiPort.Value;

                // 驱动缓存目录：程序目录\drivers
                string cacheDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "drivers");
                Directory.CreateDirectory(cacheDir);

                // 缓存文件名：服务器IP_端口_打印机名.zip
                string cacheFileName = string.Format("{0}_{1}_{2}.zip",
                    server, apiPort, SanitizeFileName(_printerInfo.PrinterName));
                string cachePath = Path.Combine(cacheDir, cacheFileName);

                // 创建临时解压目录
                string tempDir = Path.Combine(Path.GetTempPath(), "PrintClient_Driver");
                if (Directory.Exists(tempDir))
                    Directory.Delete(tempDir, true);
                Directory.CreateDirectory(tempDir);

                string zipPath;

                // 检查缓存
                if (File.Exists(cachePath))
                {
                    Log("📦 发现已缓存的驱动文件，跳过下载 (" + FormatSize(new FileInfo(cachePath).Length) + ")");
                    Log("  缓存位置: " + cachePath);
                    zipPath = Path.Combine(tempDir, "printer_driver.zip");
                    File.Copy(cachePath, zipPath, true);
                    progressBar.Value = 100;
                    lblProgress.Text = "已使用缓存";
                }
                else
                {
                    // 下载驱动（使用已校验的 selectedIndex）
                    var downloader = new DriverDownloader(server, apiPort);
                    Log("📥 开始下载驱动文件...");
                    var progress = new Progress<int>(p =>
                    {
                        progressBar.Value = p;
                        lblProgress.Text = "下载中: " + p + "%";
                        if (p % 20 == 0)
                            Log("  下载进度: " + p + "%");
                    });

                    zipPath = await Task.Run(() =>
                        downloader.DownloadDriverAsync(tempDir, selectedIndex, progress));

                    Log("✅ 驱动下载完成: " + FormatSize(new FileInfo(zipPath).Length));

                    // 保存到缓存
                    try
                    {
                        File.Copy(zipPath, cachePath, true);
                        Log("💾 驱动已缓存到: " + cachePath);
                    }
                    catch (Exception ex)
                    {
                        Log("⚠ 缓存保存失败: " + ex.Message);
                    }
                }

                if (!doInstall)
                {
                    // 仅下载：驱动已在上面保存到缓存目录
                    Log("💾 驱动已保存到: " + cachePath);
                    lblProgress.Text = "驱动已保存";
                    MessageBox.Show("驱动已保存！\n\n" + cachePath, "下载完成",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // 解压驱动
                    Log("📂 正在解压驱动文件...");
                    string extractDir = Path.Combine(tempDir, "driver");
                    DriverDownloader.ExtractDriver(zipPath, extractDir);
                    Log("✅ 解压完成");

                    // 安装驱动和打印机
                    Log("🔧 开始安装打印机驱动...");

                    // 让用户选择用主机名还是IP地址创建打印机
                    string connectAddress = server;
                    string cleanHost = CleanHostname(_printerInfo.Hostname);
                    if (!string.IsNullOrEmpty(cleanHost) && 
                        !cleanHost.Equals(server, StringComparison.OrdinalIgnoreCase))
                    {
                        connectAddress = ShowAddressSelector(cleanHost, server);
                    }

                    lblProgress.Text = "正在安装...";

                    var installProgress = new Progress<string>(msg =>
                    {
                        Log("  " + msg);
                        lblProgress.Text = msg;
                    });

                    var result = await Task.Run(() =>
                        PrinterDriverInstaller.InstallPrinter(
                            extractDir,
                            connectAddress,
                            _printerInfo.TcpPort,
                            txtPrinterName.Text.Trim(),
                            _printerInfo.DriverName,
                            installProgress));

                    // 显示安装步骤
                    foreach (string step in result.Steps)
                    {
                        Log("  " + step);
                    }

                    if (result.Success)
                    {
                        Log("🎉 " + result.Message);
                        lblProgress.Text = "✅ 安装成功！";
                        progressBar.Value = 100;
                        MessageBox.Show(
                            result.Message + "\n\n打印机名称: " + result.PrinterName +
                            "\n端口: " + result.PortName,
                            "安装成功",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                    }
                    else
                    {
                        Log("❌ " + result.Message);
                        lblProgress.Text = "❌ 安装失败";
                        MessageBox.Show(result.Message + "\n\n请确保以管理员身份运行此程序！",
                            "安装失败", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Log("❌ 操作失败: " + ex.Message);
                lblProgress.Text = "❌ 失败";
                MessageBox.Show("操作失败: " + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnDownloadInstall.Enabled = true;
                btnDownloadOnly.Enabled = true;
                btnConnect.Enabled = true;
                progressBar.Visible = false;
            }
        }

        #endregion

        private void Log(string message)
        {
            if (txtLog.InvokeRequired)
            {
                txtLog.Invoke(new Action<string>(Log), message);
                return;
            }

            string time = DateTime.Now.ToString("HH:mm:ss");
            txtLog.AppendText("[" + time + "] " + message + Environment.NewLine);

            // 自动滚动到底部
            txtLog.SelectionStart = txtLog.TextLength;
            txtLog.ScrollToCaret();

            // 限制日志行数
            if (txtLog.Lines.Length > 500)
            {
                string[] lines = txtLog.Lines;
                string[] newLines = new string[200];
                Array.Copy(lines, lines.Length - 200, newLines, 0, 200);
                txtLog.Lines = newLines;
            }
        }

        private string FormatSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double size = bytes;
            while (size >= 1024 && order < sizes.Length - 1)
            {
                order++;
                size /= 1024;
            }
            return string.Format("{0:0.##} {1}", size, sizes[order]);
        }

        private string SanitizeFileName(string name)
        {
            char[] invalid = Path.GetInvalidFileNameChars();
            foreach (char c in invalid)
                name = name.Replace(c, '_');
            return name;
        }
    }
}
