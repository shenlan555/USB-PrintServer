using System;
using System.Collections.Generic;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace PrintClient
{
    /// <summary>
    /// 局域网扫描器 - 扫描当前网段中运行 PrintServer 的主机
    /// </summary>
    public class LanScanner
    {
        /// <summary>
        /// 扫描结果
        /// </summary>
        public class ScanResult
        {
            public string IpAddress { get; set; }
            public string Hostname { get; set; }
            public bool IsReachable { get; set; }
            public int ApiPort { get; set; }
        }

        /// <summary>
        /// 扫描当前网段，返回发现的服务端列表
        /// </summary>
        public static async Task<List<ScanResult>> ScanAsync(int apiPort, IProgress<string> progress = null)
        {
            var results = new List<ScanResult>();

            try
            {
                // 获取本机所有局域网IP和子网
                var localNetworks = GetLocalNetworks();
                if (localNetworks.Count == 0)
                {
                    if (progress != null) progress.Report("未检测到局域网连接");
                    return results;
                }

                var tasks = new List<Task>();
                var lockObj = new object();

                foreach (var network in localNetworks)
                {
                    string subnet = network.Item1; // 如 "192.168.1."
                    int start = network.Item2;
                    int end = network.Item3;

                    if (progress != null) progress.Report(string.Format("正在扫描网段 {0}* (共{1}个IP)...",
                        subnet, end - start + 1));

                    // 分批并发扫描，每批50个IP
                    for (int batchStart = start; batchStart <= end; batchStart += 50)
                    {
                        int batchEnd = Math.Min(batchStart + 49, end);
                        var batchTasks = new List<Task>();

                        for (int i = batchStart; i <= batchEnd; i++)
                        {
                            string ip = subnet + i;
                            batchTasks.Add(ScanIpAsync(ip, apiPort, results, lockObj, progress));
                        }

                        await Task.WhenAll(batchTasks);
                    }
                }

                // 尝试解析主机名
                foreach (var result in results)
                {
                    try
                    {
                        var hostEntry = await Dns.GetHostEntryAsync(result.IpAddress);
                        result.Hostname = hostEntry.HostName;
                    }
                    catch
                    {
                        result.Hostname = result.IpAddress;
                    }
                }

                if (progress != null) progress.Report(string.Format("扫描完成，发现 {0} 台打印服务器", results.Count));
            }
            catch (Exception ex)
            {
                if (progress != null) progress.Report("扫描异常: " + ex.Message);
            }

            return results;
        }

        private static async Task ScanIpAsync(string ip, int port,
            List<ScanResult> results, object lockObj, IProgress<string> progress)
        {
            try
            {
                using (var client = new TcpClient())
                {
                    var connectTask = client.ConnectAsync(ip, port);
                    // 300ms 超时
                    if (await Task.WhenAny(connectTask, Task.Delay(300)) == connectTask)
                    {
                        if (client.Connected)
                        {
                            client.Close();
                            lock (lockObj)
                            {
                                results.Add(new ScanResult
                                {
                                    IpAddress = ip,
                                    IsReachable = true,
                                    ApiPort = port
                                });
                            }
                            if (progress != null) progress.Report("  发现: " + ip);
                        }
                    }
                }
            }
            catch
            {
                // 不可达，忽略
            }
        }

        /// <summary>
        /// 获取本机所有局域网网段
        /// 返回 (子网前缀, 起始IP尾数, 结束IP尾数)
        /// </summary>
        private static List<Tuple<string, int, int>> GetLocalNetworks()
        {
            var networks = new List<Tuple<string, int, int>>();

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                {
                    if (ip.Address.AddressFamily != AddressFamily.InterNetwork) continue;

                    string ipStr = ip.Address.ToString();
                    string[] parts = ipStr.Split('.');
                    if (parts.Length != 4) continue;

                    string subnet = parts[0] + "." + parts[1] + "." + parts[2] + ".";

                    // 获取子网掩码确定扫描范围
                    if (ip.IPv4Mask != null)
                    {
                        byte[] maskBytes = ip.IPv4Mask.GetAddressBytes();
                        byte[] ipBytes = ip.Address.GetAddressBytes();

                        // 逐字节计算网络地址（避免 BitConverter 的大小端问题）
                        byte[] networkBytes = new byte[4];
                        byte[] broadcastBytes = new byte[4];
                        for (int i = 0; i < 4; i++)
                        {
                            networkBytes[i] = (byte)(ipBytes[i] & maskBytes[i]);
                            broadcastBytes[i] = (byte)(networkBytes[i] | ~maskBytes[i]);
                        }

                        int start = networkBytes[3];
                        int end = broadcastBytes[3];

                        // 限制范围，最多扫描 /24 网段（254个IP）
                        if (end - start > 254 || end <= start)
                        {
                            start = 1;
                            end = 254;
                        }

                        // 使用计算出的子网前缀
                        string calcSubnet = networkBytes[0] + "." + networkBytes[1] + "." +
                                           networkBytes[2] + ".";
                        networks.Add(Tuple.Create(calcSubnet, Math.Max(1, start), Math.Min(254, end)));
                    }
                    else
                    {
                        // 无子网掩码信息，默认扫描 /24
                        networks.Add(Tuple.Create(subnet, 1, 254));
                    }
                }
            }

            return networks;
        }

        /// <summary>
        /// 获取本机所有局域网网段前缀（供UI预填）
        /// 返回如 "192.168.1." 等子网前缀列表
        /// </summary>
        public static List<string> GetLocalSubnetPrefixes()
        {
            var prefixes = new List<string>();

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;

                foreach (UnicastIPAddressInformation ip in ni.GetIPProperties().UnicastAddresses)
                {
                    if (ip.Address.AddressFamily != AddressFamily.InterNetwork) continue;

                    string ipStr = ip.Address.ToString();
                    string[] parts = ipStr.Split('.');
                    if (parts.Length != 4) continue;

                    // 获取子网掩码计算网络前缀
                    if (ip.IPv4Mask != null)
                    {
                        byte[] maskBytes = ip.IPv4Mask.GetAddressBytes();
                        byte[] ipBytes = ip.Address.GetAddressBytes();
                        byte[] networkBytes = new byte[4];
                        for (int i = 0; i < 4; i++)
                            networkBytes[i] = (byte)(ipBytes[i] & maskBytes[i]);

                        string prefix = networkBytes[0] + "." + networkBytes[1] + "." + networkBytes[2] + ".";
                        if (!prefixes.Contains(prefix))
                            prefixes.Add(prefix);
                    }
                    else
                    {
                        string prefix = parts[0] + "." + parts[1] + "." + parts[2] + ".";
                        if (!prefixes.Contains(prefix))
                            prefixes.Add(prefix);
                    }
                }
            }

            return prefixes;
        }
    }
}
