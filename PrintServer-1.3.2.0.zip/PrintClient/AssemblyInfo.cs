using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("网络打印客户端")]
[assembly: AssemblyDescription("网络打印客户端 - 自动发现、一键安装、即装即用")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("浪里个浪")]
[assembly: AssemblyProduct("网络打印客户端")]
[assembly: AssemblyCopyright("Copyright © 2026 挨踢日记")]
[assembly: ComVisible(false)]
[assembly: Guid("A1B2C3D4-E5F6-7890-ABCD-EF1234567891")]
[assembly: AssemblyVersion("1.3.2.0")]
[assembly: AssemblyFileVersion("1.3.2.0")]
