using System;

namespace PrintClient
{
    /// <summary>
    /// 统一错误处理辅助类
    /// 提供标准化的异常日志记录和安全的代码执行包装
    /// </summary>
    public static class ErrorHandler
    {
        /// <summary>
        /// 安全执行 Action，自动捕获异常
        /// </summary>
        /// <param name="action">要执行的代码</param>
        /// <param name="context">上下文描述</param>
        /// <param name="onError">错误回调（可选）</param>
        /// <returns>是否执行成功</returns>
        public static bool SafeExecute(Action action, string context, Action<string> onError = null)
        {
            try
            {
                action();
                return true;
            }
            catch (Exception ex)
            {
                string message = FormatLogMessage(ex, context);
                if (onError != null) onError(message);
                return false;
            }
        }

        /// <summary>
        /// 安全执行 Func，自动捕获异常
        /// </summary>
        /// <typeparam name="T">返回值类型</typeparam>
        public static T SafeExecute<T>(Func<T> func, string context, Action<string> onError = null, T defaultValue = default(T))
        {
            try
            {
                return func();
            }
            catch (Exception ex)
            {
                string message = FormatLogMessage(ex, context);
                if (onError != null) onError(message);
                return defaultValue;
            }
        }

        /// <summary>
        /// 格式化异常日志消息
        /// </summary>
        public static string FormatLogMessage(Exception ex, string context)
        {
            return string.Format(
                "[错误] 上下文: {0} | 类型: {1} | 消息: {2}",
                context,
                ex.GetType().Name,
                ex.Message
            );
        }

        /// <summary>
        /// 获取用户友好的错误提示
        /// </summary>
        public static string GetUserFriendlyMessage(Exception ex)
        {
            if (ex is System.Net.Sockets.SocketException)
                return "网络连接失败，请检查网络设置";
            if (ex is System.Net.Http.HttpRequestException)
                return "HTTP 请求失败，请检查服务器地址和端口";
            if (ex is System.Net.WebException)
                return "网络请求超时，请检查网络连接";
            if (ex is System.UnauthorizedAccessException)
                return "权限不足，请以管理员身份运行";
            if (ex is System.IO.IOException)
                return "文件读写失败: " + ex.Message;
            if (ex is System.TimeoutException)
                return "操作超时，请重试";
            return ex.Message;
        }
    }
}
