using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace PrintClient
{
    /// <summary>
    /// 驱动下载器 - 从打印服务器获取打印机列表和驱动文件
    /// 支持多打印机模式
    /// </summary>
    public class DriverDownloader
    {
        private readonly string _serverBaseUrl;

        public DriverDownloader(string serverHost, int apiPort = 9180)
        {
            _serverBaseUrl = string.Format("http://{0}:{1}", serverHost, apiPort);
        }

        /// <summary>
        /// 服务器打印机信息（兼容单打印机模式）
        /// </summary>
        public class ServerPrinterInfo
        {
            public string Hostname { get; set; }
            public string Version { get; set; }
            public int TcpPort { get; set; }
            public int ApiPort { get; set; }
            public int PrinterCount { get; set; }
            public string PrinterName { get; set; }
            public string DriverName { get; set; }
            public string DriverVersion { get; set; }
            public string DriverDate { get; set; }
            public string Manufacturer { get; set; }
            public bool HasDriver { get; set; }
            public int DriverFileCount { get; set; }
            public string DriverSize { get; set; }
            // 多打印机列表
            public List<PrinterItemInfo> Printers { get; set; }

            public ServerPrinterInfo()
            {
                Printers = new List<PrinterItemInfo>();
            }
        }

        /// <summary>
        /// 列表中单个打印机信息
        /// </summary>
        public class PrinterItemInfo
        {
            public int Index { get; set; }
            public string Name { get; set; }
            public int Port { get; set; }
            public string DriverName { get; set; }
            public string DriverVersion { get; set; }
            public string DriverDate { get; set; }
            public string Manufacturer { get; set; }
            public bool HasDriver { get; set; }
            public int DriverFileCount { get; set; }
            public string DriverSize { get; set; }
        }

        /// <summary>
        /// 测试与服务器的连接
        /// </summary>
        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(5) })
                {
                    var response = await client.GetAsync(_serverBaseUrl + "/api/test");
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 获取服务器上的打印机信息（兼容新旧API格式）
        /// </summary>
        public async Task<ServerPrinterInfo> GetPrinterInfoAsync()
        {
            try
            {
                using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(10) })
                {
                    var response = await client.GetAsync(_serverBaseUrl + "/api/info");
                    response.EnsureSuccessStatusCode();

                    string json = await response.Content.ReadAsStringAsync();
                    var serializer = new JavaScriptSerializer();
                    var data = serializer.Deserialize<dynamic>(json);

                    var info = new ServerPrinterInfo();

                    try { info.Hostname = data["server"]["hostname"]; } catch { }
                    try { info.Version = data["server"]["version"]; } catch { }
                    try { info.ApiPort = Convert.ToInt32(data["server"]["apiPort"]); } catch { }
                    try { info.PrinterCount = Convert.ToInt32(data["server"]["printerCount"]); } catch { }

                    // 兼容旧版API：顶层printer字段
                    try
                    {
                        var printer = data["printer"];
                        if (printer != null)
                        {
                            try { info.PrinterName = printer["name"]; } catch { }
                            try { info.TcpPort = Convert.ToInt32(printer["tcpPort"]); } catch { }
                            try { info.DriverName = printer["driverName"]; } catch { }
                            try { info.DriverVersion = printer["driverVersion"]; } catch { }
                            try { info.DriverDate = printer["driverDate"]; } catch { }
                            try { info.Manufacturer = printer["manufacturer"]; } catch { }
                            try { info.HasDriver = Convert.ToBoolean(printer["hasDriver"]); } catch { }
                            try { info.DriverFileCount = Convert.ToInt32(printer["driverFileCount"]); } catch { }
                            try { info.DriverSize = printer["driverSizeFormatted"]; } catch { }
                        }
                    }
                    catch { }

                    // 新版API：printers数组
                    try
                    {
                        var printers = data["printers"];
                        if (printers != null && printers is Array)
                        {
                            foreach (var p in (Array)printers)
                            {
                                var item = serializer.Deserialize<Dictionary<string, object>>(
                                    serializer.Serialize(p));
                                var pi = new PrinterItemInfo();
                                try { pi.Index = Convert.ToInt32(item["index"]); } catch { }
                                try { pi.Name = Convert.ToString(item["name"]); } catch { }
                                try { pi.Port = Convert.ToInt32(item["port"]); } catch { }
                                try { pi.DriverName = Convert.ToString(item["driverName"]); } catch { }
                                try { pi.DriverVersion = Convert.ToString(item["driverVersion"]); } catch { }
                                try { pi.DriverDate = Convert.ToString(item["driverDate"]); } catch { }
                                try { pi.Manufacturer = Convert.ToString(item["manufacturer"]); } catch { }
                                try { pi.HasDriver = Convert.ToBoolean(item["hasDriver"]); } catch { }
                                try { pi.DriverFileCount = Convert.ToInt32(item["driverFileCount"]); } catch { }
                                try { pi.DriverSize = Convert.ToString(item["driverSizeFormatted"]); } catch { }
                                info.Printers.Add(pi);
                            }
                        }
                    }
                    catch { }

                    // 如果printers为空但printer存在，用printer构建列表
                    if (info.Printers.Count == 0 && !string.IsNullOrEmpty(info.PrinterName))
                    {
                        info.Printers.Add(new PrinterItemInfo
                        {
                            Index = 0,
                            Name = info.PrinterName,
                            Port = info.TcpPort,
                            DriverName = info.DriverName,
                            DriverVersion = info.DriverVersion,
                            DriverDate = info.DriverDate,
                            Manufacturer = info.Manufacturer,
                            HasDriver = info.HasDriver,
                            DriverFileCount = info.DriverFileCount,
                            DriverSize = info.DriverSize
                        });
                        info.PrinterCount = 1;
                    }

                    return info;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("获取打印机信息失败: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// 下载指定打印机的驱动包
        /// </summary>
        public async Task<string> DownloadDriverAsync(string saveDirectory, int printerIndex = 0, IProgress<int> progress = null)
        {
            try
            {
                if (!Directory.Exists(saveDirectory))
                    Directory.CreateDirectory(saveDirectory);

                string zipPath = Path.Combine(saveDirectory, "printer_driver.zip");
                string url = _serverBaseUrl + "/api/driver";
                if (printerIndex > 0)
                    url += "?id=" + printerIndex;

                using (var client = new HttpClient { Timeout = TimeSpan.FromMinutes(5) })
                {
                    var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead);
                    response.EnsureSuccessStatusCode();

                    long totalBytes = response.Content.Headers.ContentLength ?? -1;
                    long receivedBytes = 0;

                    using (var fileStream = new FileStream(zipPath, FileMode.Create, FileAccess.Write, FileShare.None))
                    using (var httpStream = await response.Content.ReadAsStreamAsync())
                    {
                        byte[] buffer = new byte[8192];
                        int bytesRead;
                        while ((bytesRead = await httpStream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                        {
                            await fileStream.WriteAsync(buffer, 0, bytesRead);
                            receivedBytes += bytesRead;

                            if (progress != null && totalBytes > 0)
                            {
                                int percent = (int)(receivedBytes * 100 / totalBytes);
                                progress.Report(percent);
                            }
                        }
                    }

                    return zipPath;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("下载驱动失败: " + ex.Message, ex);
            }
        }

        /// <summary>
        /// 解压驱动包
        /// </summary>
        public static string ExtractDriver(string zipPath, string extractDir)
        {
            try
            {
                if (Directory.Exists(extractDir))
                    Directory.Delete(extractDir, true);

                System.IO.Compression.ZipFile.ExtractToDirectory(zipPath, extractDir);
                return extractDir;
            }
            catch (Exception ex)
            {
                throw new Exception("解压驱动失败: " + ex.Message, ex);
            }
        }
    }
}
