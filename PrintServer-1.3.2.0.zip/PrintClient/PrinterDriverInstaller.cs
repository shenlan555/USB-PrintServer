using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;

namespace PrintClient
{
    /// <summary>
    /// 打印机驱动安装器 - 在客户端安装打印机驱动并创建网络打印机
    /// </summary>
    public class PrinterDriverInstaller
    {
        #region Win32 API

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool AddPrinterDriverEx(
            string pName,
            uint Level,
            ref DRIVER_INFO_3 pDriverInfo,
            uint dwFileCopyFlags);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool AddPrinter(
            string pName,
            uint Level,
            ref PRINTER_INFO_2 pPrinter);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool OpenPrinter(
            string pPrinterName,
            out IntPtr phPrinter,
            IntPtr pDefault);

        [DllImport("winspool.drv", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool ClosePrinter(IntPtr hPrinter);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct DRIVER_INFO_3
        {
            public uint cVersion;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pEnvironment;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDriverPath;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDataFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pConfigFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pHelpFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDependentFiles;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pMonitorName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDefaultDataType;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        private struct PRINTER_INFO_2
        {
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pServerName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pPrinterName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pShareName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pPortName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDriverName;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pComment;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pLocation;
            public IntPtr pDevMode;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pSepFile;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pPrintProcessor;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pDatatype;
            [MarshalAs(UnmanagedType.LPTStr)]
            public string pParameters;
            public IntPtr pSecurityDescriptor;
            public uint Attributes;
            public uint Priority;
            public uint DefaultPriority;
            public uint StartTime;
            public uint UntilTime;
            public uint Status;
            public uint cJobs;
            public uint AveragePPM;
        }

        // 打印机驱动安装标志
        private const uint APD_STRICT_UPGRADE = 0x00000001;
        private const uint APD_STRICT_DOWNGRADE = 0x00000002;
        private const uint APD_COPY_ALL_FILES = 0x00000004;
        private const uint APD_COPY_NEW_FILES = 0x00000008;
        private const uint APD_COPY_FROM_DIRECTORY = 0x00000010;

        // 端口监视器
        private const string STANDARD_TCPIP_PORT_MONITOR = "Standard TCP/IP Port";
        private const string MONITOR_DLL = "tcpmon.dll";

        #endregion

        /// <summary>
        /// 安装结果
        /// </summary>
        public class InstallResult
        {
            public bool Success { get; set; }
            public string Message { get; set; }
            public string PrinterName { get; set; }
            public string PortName { get; set; }
            public string DriverName { get; set; }
            public List<string> Steps { get; set; }

            public InstallResult()
            {
                Steps = new List<string>();
            }
        }

        /// <summary>
        /// 安装打印机驱动并创建网络打印机
        /// </summary>
        public static InstallResult InstallPrinter(
            string driverDirectory,
            string serverHost,
            int serverPort,
            string printerName,
            string driverName,
            IProgress<string> progress = null)
        {
            var result = new InstallResult();

            try
            {
                // 步骤1：查找驱动 INF 文件
                ReportProgress(progress, "正在查找驱动 INF 文件...");
                string infPath = FindInfFile(driverDirectory);
                if (string.IsNullOrEmpty(infPath))
                {
                    result.Message = "未在驱动包中找到 INF 文件";
                    result.Steps.Add("❌ 查找 INF 文件失败");
                    return result;
                }
                result.Steps.Add("✅ 找到 INF 文件: " + Path.GetFileName(infPath));

                // 从 INF 文件中读取真实驱动名
                string realDriverName = ReadDriverNameFromInf(infPath);
                if (!string.IsNullOrEmpty(realDriverName))
                {
                    driverName = realDriverName;
                    ReportProgress(progress, "INF中的驱动名: " + driverName);
                }

                // 步骤2：创建 TCP/IP 打印端口
                string portName = string.Format("PS_{0}_{1}", serverHost, serverPort);
                ReportProgress(progress, "正在创建打印端口...");
                bool portCreated = CreateTcpIpPort(serverHost, serverPort, portName, progress);
                if (!portCreated)
                {
                    result.Message = "创建打印端口失败";
                    result.Steps.Add("❌ 创建端口失败");
                    return result;
                }
                result.Steps.Add("✅ 打印端口已创建: " + portName);
                result.PortName = portName;

                // 步骤3：安装驱动 + 创建打印机
                ReportProgress(progress, "正在安装驱动并创建打印机...");
                bool installed = false;

                // 先装驱动
                bool driverOk = InstallDriverViaPrintUI(infPath, driverName, progress)
                    || InstallDriverViaPnpUtil(infPath, progress)
                    || InstallDriverViaApi(driverDirectory, driverName, infPath, progress);

                if (driverOk)
                {
                    // PowerShell 创建打印机最可靠
                    installed = CreatePrinterViaPowerShell(printerName, portName, driverName, progress)
                        || CreatePrinterViaPrintUI(printerName, portName, driverName, infPath, progress)
                        || CreatePrinter(printerName, portName, driverName, progress);
                }

                if (!installed)
                {
                    // 最后兜底：一步法
                    ReportProgress(progress, "尝试一步安装...");
                    installed = InstallDriverAndPrinter(infPath, driverName, printerName, portName, progress);
                }

                RestartSpooler();
                System.Threading.Thread.Sleep(2000);

                bool exists = PrinterExists(printerName);
                if (!exists)
                {
                    result.Message = "打印机创建失败，请检查驱动是否兼容当前Windows版本";
                    result.Steps.Add("❌ 打印机未在系统中出现");
                    return result;
                }

                result.Steps.Add("✅ 驱动已安装到系统");
                result.Steps.Add("✅ 打印机已创建: " + printerName);
                result.PrinterName = printerName;
                result.DriverName = driverName;

                result.Success = true;
                result.Message = "打印机安装成功！";
                result.Steps.Add("🎉 全部完成！打印机 " + printerName + " 已就绪");
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.Message = "安装过程中发生错误: " + ex.Message;
                result.Steps.Add("❌ 错误: " + ex.Message);
            }

            return result;
        }

        /// <summary>
        /// 在目录中查找 INF 文件
        /// </summary>
        private static string FindInfFile(string directory)
        {
            try
            {
                foreach (string file in Directory.GetFiles(directory, "*.inf", SearchOption.AllDirectories))
                {
                    // 优先查找非 setup.inf 的驱动 INF
                    string fileName = Path.GetFileName(file).ToLowerInvariant();
                    if (fileName != "setup.inf")
                        return file;
                }
                // 如果没有其他 INF 文件，就用第一个找到的
                var infFiles = Directory.GetFiles(directory, "*.inf", SearchOption.AllDirectories);
                if (infFiles.Length > 0)
                    return infFiles[0];
            }
            catch { }
            return null;
        }

        /// <summary>
        /// 从 INF 文件中读取驱动名称（打印机型号名）
        /// </summary>
        private static string ReadDriverNameFromInf(string infPath)
        {
            try
            {
                string content = File.ReadAllText(infPath, Encoding.Unicode);
                var lines = content.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

                // 策略1：在 Manufacturer 节下面找模型名
                // 格式: "Model Name" = INSTALL_SECTION, ...
                bool inModelsSection = false;
                foreach (string line in lines)
                {
                    string trimmed = line.Trim();

                    // 检测进入模型定义节（[ManufacturerName.NTamd64] 等）
                    if (trimmed.StartsWith("[", StringComparison.Ordinal) &&
                        trimmed.EndsWith("]", StringComparison.Ordinal))
                    {
                        string section = trimmed.Trim('[', ']');
                        // 跳过 [Manufacturer] 自身, 进入具体的架构节
                        if (section.IndexOf("NT", StringComparison.OrdinalIgnoreCase) >= 0 &&
                            trimmed.IndexOf("Strings", StringComparison.OrdinalIgnoreCase) < 0)
                        {
                            inModelsSection = true;
                            continue;
                        }
                        if (trimmed.IndexOf("Strings", StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            inModelsSection = false;
                            continue;
                        }
                        // 其他非模型节
                        if (!section.Contains("."))
                            inModelsSection = false;
                        continue;
                    }

                    if (!inModelsSection) continue;
                    if (!trimmed.StartsWith("\"")) continue;

                    // 提取模型名: "Lenovo M7298W Series" = INSTALL, ...
                    int eqIdx = trimmed.IndexOf('=');
                    if (eqIdx <= 0) continue;

                    string modelName = trimmed.Substring(1, eqIdx - 1).Trim().Trim('"').Trim();
                    // 模型名至少3个字符
                    if (modelName.Length >= 3)
                        return modelName;
                }

                // 策略2：回退 - 在任意节中找 "ModelName" =
                foreach (string line in lines)
                {
                    string trimmed = line.Trim();
                    if (!trimmed.StartsWith("\"")) continue;
                    int eqIdx = trimmed.IndexOf('=');
                    if (eqIdx <= 0) continue;
                    string right = trimmed.Substring(eqIdx + 1).Trim().Trim('"');
                    // 排除太短的、包含 DISK 的、以及纯数字的
                    if (right.Length >= 3 && right.IndexOf("DISK", StringComparison.OrdinalIgnoreCase) < 0
                        && !right.All(char.IsDigit))
                    {
                        return right;
                    }
                }
            }
            catch { }
            return null;
        }

        /// <summary>
        /// 一步完成：安装驱动 + 创建打印机（printui.dll /if）
        /// </summary>
        private static bool InstallDriverAndPrinter(string infPath, string driverName,
            string printerName, string portName, IProgress<string> progress)
        {
            try
            {
                ReportProgress(progress, "正在一步安装驱动和打印机...");

                // printui.dll /if = 安装驱动(/f) 并创建打印机(/b 名称 /r 端口 /m 驱动名)
                string args = string.Format(
                    "printui.dll,PrintUIEntry /if /b \"{0}\" /f \"{1}\" /r \"{2}\" /m \"{3}\" /q",
                    printerName, infPath, portName, driverName);

                var psi = new ProcessStartInfo
                {
                    FileName = "rundll32.exe",
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    if (process == null) return false;
                    process.WaitForExit(120000);
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    ReportProgress(progress, "printui /if 退出码: " + process.ExitCode);

                    if (process.ExitCode != 0)
                    {
                        ReportProgress(progress, "输出: " + (output + error).Trim());
                    }

                    return process.ExitCode == 0;
                }
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "一步安装异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 重启 Print Spooler 服务
        /// </summary>
        private static void RestartSpooler()
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = "net",
                    Arguments = "stop spooler",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using (var p = Process.Start(psi))
                {
                    if (p != null) p.WaitForExit(10000);
                }

                System.Threading.Thread.Sleep(1000);

                psi.Arguments = "start spooler";
                using (var p = Process.Start(psi))
                {
                    if (p != null) p.WaitForExit(10000);
                }
            }
            catch { }
        }

        /// <summary>
        /// 检查打印机是否已存在
        /// </summary>
        private static bool PrinterExists(string printerName)
        {
            try
            {
                string escaped = printerName.Replace("\\", "\\\\").Replace("'", "''");
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT Name FROM Win32_Printer WHERE Name = '" + escaped + "'"))
                {
                    foreach (var obj in searcher.Get())
                        return true;
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 使用 printui.dll 安装驱动（Windows 标准方式，最可靠）
        /// rundll32 printui.dll,PrintUIEntry /ia /m "DriverName" /f "infpath"
        /// </summary>
        private static bool InstallDriverViaPrintUI(string infPath, string driverName, IProgress<string> progress)
        {
            try
            {
                ReportProgress(progress, "正在使用 printui.dll 安装驱动...");

                string args = string.Format(
                    "printui.dll,PrintUIEntry /ia /m \"{0}\" /f \"{1}\" /h \"x64\" /q",
                    driverName, infPath);

                var psi = new ProcessStartInfo
                {
                    FileName = "rundll32.exe",
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    if (process == null) return false;
                    process.WaitForExit(120000); // 2分钟超时
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    if (process.ExitCode == 0)
                    {
                        ReportProgress(progress, "printui.dll 驱动安装成功");
                        return true;
                    }

                    ReportProgress(progress, "printui.dll 输出: " + (output + error).Trim());
                }

                return false;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "printui.dll 安装异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 使用 printui.dll 创建打印机
        /// rundll32 printui.dll,PrintUIEntry /if /b "PrinterName" /f "infpath" /r "PortName" /m "DriverName"
        /// </summary>
        private static bool CreatePrinterViaPrintUI(string printerName, string portName,
            string driverName, string infPath, IProgress<string> progress)
        {
            try
            {
                ReportProgress(progress, "正在使用 printui.dll 创建打印机...");

                string args = string.Format(
                    "printui.dll,PrintUIEntry /if /b \"{0}\" /f \"{1}\" /r \"{2}\" /m \"{3}\" /q",
                    printerName, infPath, portName, driverName);

                var psi = new ProcessStartInfo
                {
                    FileName = "rundll32.exe",
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    if (process == null) return false;
                    process.WaitForExit(120000);
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    if (process.ExitCode == 0)
                    {
                        ReportProgress(progress, "printui.dll 打印机创建成功");
                        return true;
                    }

                    ReportProgress(progress, "printui.dll 创建输出: " + (output + error).Trim());

                    // 即使 exit code 非零，有时打印机也已经创建了
                    // 检查打印机是否存在
                    try
                    {
                        using (var searcher = new ManagementObjectSearcher(
                            "SELECT * FROM Win32_Printer WHERE Name = '" + printerName.Replace("'", "''") + "'"))
                        {
                            foreach (var obj in searcher.Get())
                                return true;
                        }
                    }
                    catch { }
                }

                return false;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "printui.dll 创建打印机异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 使用 pnputil 安装驱动
        /// </summary>
        private static bool InstallDriverViaPnpUtil(string infPath, IProgress<string> progress)
        {
            try
            {
                ReportProgress(progress, "正在使用 pnputil 安装驱动...");

                var psi = new ProcessStartInfo
                {
                    FileName = "pnputil.exe",
                    Arguments = string.Format("/add-driver \"{0}\" /install", infPath),
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true,
                    Verb = "runas" // 请求管理员权限
                };

                Process process = null;
                try
                {
                    process = Process.Start(psi);
                    if (process == null)
                    {
                        // 尝试不使用 Verb runas
                        psi.Verb = "";
                        process = Process.Start(psi);
                    }

                    if (process == null)
                        return false;

                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();
                    process.WaitForExit();

                    string combined = output + error;
                    bool success = combined.IndexOf("Driver package added", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   combined.IndexOf("successfully", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   process.ExitCode == 0;

                    if (!success)
                        ReportProgress(progress, "pnputil 输出: " + combined.Trim());

                    return success;
                }
                finally
                {
                    if (process != null)
                        process.Dispose();
                }
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "pnputil 安装失败: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 使用 Win32 API 安装驱动
        /// </summary>
        private static bool InstallDriverViaApi(string driverDir, string driverName, string infPath, IProgress<string> progress)
        {
            try
            {
                ReportProgress(progress, "正在使用 API 安装驱动...");

                // 收集驱动文件
                var driverFiles = Directory.GetFiles(driverDir, "*.*", SearchOption.AllDirectories)
                    .Select(f => Path.GetFullPath(f))
                    .ToList();

                string driverFile = driverFiles.FirstOrDefault(f =>
                    f.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) &&
                    !f.EndsWith("ui.dll", StringComparison.OrdinalIgnoreCase)) ?? "";
                string configFile = driverFiles.FirstOrDefault(f =>
                    f.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)) ?? "";
                string dataFile = driverFiles.FirstOrDefault(f =>
                    f.EndsWith(".ppd", StringComparison.OrdinalIgnoreCase) ||
                    f.EndsWith(".gpd", StringComparison.OrdinalIgnoreCase)) ?? "";
                string helpFile = driverFiles.FirstOrDefault(f =>
                    f.EndsWith(".hlp", StringComparison.OrdinalIgnoreCase) ||
                    f.EndsWith(".chm", StringComparison.OrdinalIgnoreCase)) ?? "";

                string dependentFiles = string.Join("\0", driverFiles) + "\0";

                var driverInfo = new DRIVER_INFO_3
                {
                    cVersion = 3,
                    pName = driverName,
                    pEnvironment = "Windows x64",
                    pDriverPath = driverFile,
                    pDataFile = dataFile,
                    pConfigFile = configFile,
                    pHelpFile = helpFile,
                    pDependentFiles = dependentFiles,
                    pMonitorName = null,
                    pDefaultDataType = "RAW"
                };

                bool success = AddPrinterDriverEx(null, 3, ref driverInfo,
                    APD_COPY_ALL_FILES | APD_COPY_FROM_DIRECTORY);

                if (!success)
                {
                    int error = Marshal.GetLastWin32Error();
                    ReportProgress(progress, "API 安装驱动失败，错误代码: " + error);
                }

                return success;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "API 安装驱动异常: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 创建 TCP/IP 打印端口
        /// </summary>
        private static bool CreateTcpIpPort(string host, int port, string portName, IProgress<string> progress)
        {
            try
            {
                // 方法1：使用 WMI 创建 TCP/IP 打印机端口
                return CreatePortViaWmi(host, port, portName, progress);
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "WMI 创建端口失败: " + ex.Message);

                // 方法2：使用 prnport.vbs / rundll32
                return CreatePortViaPrintUI(host, port, portName, progress);
            }
        }

        /// <summary>
        /// 通过 WMI 创建 TCP/IP 打印端口
        /// </summary>
        private static bool CreatePortViaWmi(string host, int port, string portName, IProgress<string> progress)
        {
            try
            {
                var scope = new ManagementScope(@"\\.\root\cimv2");
                scope.Connect();

                // 先确保端口监视器存在
                var monitorClass = new ManagementClass(scope,
                    new ManagementPath("Win32_TCPIPPrinterPort"), null);

                // 获取端口
                var portObject = monitorClass.CreateInstance();

                portObject["Name"] = portName;
                portObject["Protocol"] = 1; // 1 = RAW
                portObject["HostAddress"] = host;
                portObject["PortNumber"] = port;
                portObject["SNMPEnabled"] = false;

                var putOptions = new PutOptions { Type = PutType.CreateOnly };
                portObject.Put(putOptions);

                ReportProgress(progress, "WMI 端口创建成功");
                return true;
            }
            catch (ManagementException mex)
            {
                // 端口可能已存在
                if (mex.ErrorCode == ManagementStatus.AlreadyExists)
                {
                    ReportProgress(progress, "端口已存在，将直接使用");
                    return true;
                }
                ReportProgress(progress, "WMI 端口创建失败: " + mex.Message);
                return false;
            }
        }

        /// <summary>
        /// 通过 printui.dll 创建端口（备用方案）
        /// </summary>
        private static bool CreatePortViaPrintUI(string host, int port, string portName, IProgress<string> progress)
        {
            try
            {
                // 使用 PowerShell 添加打印机端口
                string psCommand = string.Format(
                    "Add-PrinterPort -Name '{0}' -PrinterHostAddress '{1}' -PortNumber {2}",
                    portName.Replace("'", "''"), host.Replace("'", "''"), port);

                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-NoProfile -Command \"" + psCommand + "\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    process.WaitForExit(15000);
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    if (process.ExitCode == 0)
                    {
                        ReportProgress(progress, "PowerShell 端口创建成功");
                        return true;
                    }

                    ReportProgress(progress, "PowerShell 端口创建输出: " + (output + error).Trim());
                }

                return false;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "printui 创建端口失败: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 创建打印机
        /// </summary>
        private static bool CreatePrinter(string printerName, string portName, string driverName, IProgress<string> progress)
        {
            try
            {
                // 方法1：使用 PowerShell Add-Printer
                return CreatePrinterViaPowerShell(printerName, portName, driverName, progress);
            }
            catch
            {
                // 方法2：使用 Win32 API
                return CreatePrinterViaApi(printerName, portName, driverName, progress);
            }
        }

        /// <summary>
        /// 通过 PowerShell 创建打印机
        /// </summary>
        private static bool CreatePrinterViaPowerShell(string printerName, string portName, string driverName, IProgress<string> progress)
        {
            try
            {
                // 使用单引号避免双引号嵌套冲突，内部单引号转义为 ''
                string psCommand = string.Format(
                    "Add-Printer -Name '{0}' -DriverName '{1}' -PortName '{2}'",
                    printerName.Replace("'", "''"),
                    driverName.Replace("'", "''"),
                    portName.Replace("'", "''"));

                var psi = new ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = "-NoProfile -Command \"" + psCommand + "\"",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(psi))
                {
                    process.WaitForExit(30000);
                    string output = process.StandardOutput.ReadToEnd();
                    string error = process.StandardError.ReadToEnd();

                    if (process.ExitCode == 0)
                    {
                        ReportProgress(progress, "PowerShell 打印机创建成功");
                        return true;
                    }

                    ReportProgress(progress, "PowerShell 输出: " + (output + error).Trim());
                }

                return false;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "PowerShell 创建打印机失败: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// 通过 Win32 API 创建打印机
        /// </summary>
        private static bool CreatePrinterViaApi(string printerName, string portName, string driverName, IProgress<string> progress)
        {
            try
            {
                var printerInfo = new PRINTER_INFO_2
                {
                    pPrinterName = printerName,
                    pPortName = portName,
                    pDriverName = driverName,
                    pPrintProcessor = "WinPrint",
                    pDatatype = "RAW",
                    pShareName = "",
                    pComment = "网络打印客户端 - 连接到打印服务器",
                    pLocation = "",
                    pSepFile = "",
                    pParameters = "",
                    Attributes = 0,
                    Priority = 1,
                    DefaultPriority = 1,
                    StartTime = 0,
                    UntilTime = 0,
                    Status = 0,
                    cJobs = 0,
                    AveragePPM = 0
                };

                bool success = AddPrinter(null, 2, ref printerInfo);

                if (!success)
                {
                    int error = Marshal.GetLastWin32Error();
                    ReportProgress(progress, "API 创建打印机失败，错误代码: " + error);
                }

                return success;
            }
            catch (Exception ex)
            {
                ReportProgress(progress, "API 创建打印机异常: " + ex.Message);
                return false;
            }
        }

        private static void ReportProgress(IProgress<string> progress, string message)
        {
            if (progress != null)
                progress.Report(message);
        }
    }
}
