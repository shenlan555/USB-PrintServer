using System;
using System.Collections.Generic;
using System.Drawing;
using System.Management;
using System.Windows.Forms;
using System.Drawing.Printing;
using System.IO;
using System.Linq;

namespace PrintServer
{
    public class PrintServerForm : Form
    {
        private Button btnStartStop;
        private Button btnInstallService;
        private Button btnUninstallService;
        private Button btnStartService;
        private Button btnStopService;
        private DataGridView dgvPrinters;
        private NumericUpDown nudApiPort;
        private TextBox txtLog;
        private Label lblStatus;
        private Label lblRunMode;
        private Label lblHostName;
        private Label lblIPAddress;
        private Button btnClearLog;
        private Label lblLicenseStatus;
        private Label lblLicenseExpiry;

        private List<PrintServerService> _servers = new List<PrintServerService>();
        private HttpApiService _apiServer;
        private bool isRunning = false;

        public PrintServerForm()
        {
            InitializeComponent();
            LoadPrinters();
            LoadSavedSettings();
            UpdateNetworkInfo();
            UpdateServiceStatus();
            LoadExistingLog();
            UpdateLicenseStatus();
        }

        private void InitializeComponent()
        {
            // 从 AssemblyInfo.cs 读取版本信息
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            string productName = "";
            string companyName = "";

            object[] productAttrs = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyProductAttribute), false);
            if (productAttrs.Length > 0)
                productName = ((System.Reflection.AssemblyProductAttribute)productAttrs[0]).Product;

            object[] companyAttrs = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyCompanyAttribute), false);
            if (companyAttrs.Length > 0)
                companyName = ((System.Reflection.AssemblyCompanyAttribute)companyAttrs[0]).Company;

            string version = assembly.GetName().Version.ToString();

            // 读取 AssemblyDescription
            string description = "";
            object[] descAttrs = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyDescriptionAttribute), false);
            if (descAttrs.Length > 0)
                description = ((System.Reflection.AssemblyDescriptionAttribute)descAttrs[0]).Description;

            this.Text = string.Format("{0} - v{1} - By：{2}", productName, version, companyName);
            this.Size = new Size(600, 670);
            var asm = System.Reflection.Assembly.GetExecutingAssembly();
            using (var stream = asm.GetManifestResourceStream("PrintServer.appicon.ico"))
            {
                if (stream != null)
                    this.Icon = new System.Drawing.Icon(stream);
            }
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.FormClosing += PrintServerForm_FormClosing;

            Font baseFont = new Font("微软雅黑", 9F, FontStyle.Regular);
            Font boldFont = new Font("微软雅黑", 9F, FontStyle.Bold);

            // ========== 顶部标题栏 ==========
            Panel pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(600, 48),
                BackColor = Color.FromArgb(30, 60, 120)
            };

            Label lblTitle = new Label()
            {
                Text = string.Format("🖨️  {0} v{1}", productName, version),
                Location = new Point(16, 10),
                AutoSize = true,
                Font = new Font("微软雅黑", 12F, FontStyle.Bold),
                ForeColor = Color.White
            };

            Label lblCompany = new Label()
            {
                Text = description,
                Location = new Point(16, 30),
                AutoSize = true,
                Font = new Font("微软雅黑", 7.5F),
                ForeColor = Color.FromArgb(160, 190, 220)
            };
            pnlHeader.Controls.AddRange(new Control[] { lblTitle, lblCompany });

            // ========== 授权信息组 ==========
            GroupBox gbLicense = new GroupBox()
            {
                Text = "  授权信息",
                Location = new Point(12, 56),
                Size = new Size(560, 52),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            lblLicenseStatus = new Label()
            {
                Text = "⏳ 验证中...",
                Location = new Point(14, 20),
                Size = new Size(260, 20),
                Font = boldFont,
                ForeColor = Color.FromArgb(120, 120, 140)
            };

            lblLicenseExpiry = new Label()
            {
                Text = "",
                Location = new Point(284, 20),
                Size = new Size(262, 20),
                Font = boldFont,
                ForeColor = Color.FromArgb(120, 120, 140)
            };

            gbLicense.Controls.AddRange(new Control[] { lblLicenseStatus, lblLicenseExpiry });

            // ========== 打印机设置组 ==========
            GroupBox gbPrinter = new GroupBox()
            {
                Text = "  ⚙️  打印机设置",
                Location = new Point(12, 116),
                Size = new Size(560, 175),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            dgvPrinters = new DataGridView()
            {
                Location = new Point(14, 22),
                Size = new Size(420, 143),
                Font = new Font("微软雅黑", 9F),
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight = 24,
                RowTemplate = { Height = 22 }
            };

            // 列定义：勾选 | 打印机名称 | 端口
            var colCheck = new DataGridViewCheckBoxColumn()
            {
                Name = "colCheck",
                HeaderText = "",
                Width = 28,
                FillWeight = 5,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.None,
                Resizable = DataGridViewTriState.False
            };
            dgvPrinters.Columns.Add(colCheck);
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colName",
                HeaderText = "打印机名称",
                FillWeight = 55,
                MinimumWidth = 120,
                ReadOnly = true
            });
            dgvPrinters.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "colPort",
                HeaderText = "端口",
                FillWeight = 20,
                MinimumWidth = 55,
                DefaultCellStyle = { Alignment = DataGridViewContentAlignment.MiddleCenter }
            });

            dgvPrinters.EnableHeadersVisualStyles = false;
            dgvPrinters.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(240, 242, 245);
            dgvPrinters.ColumnHeadersDefaultCellStyle.ForeColor = Color.FromArgb(50, 50, 80);
            dgvPrinters.ColumnHeadersDefaultCellStyle.Font = new Font("微软雅黑", 9F, FontStyle.Bold);
            dgvPrinters.DefaultCellStyle.SelectionBackColor = Color.White;
            dgvPrinters.DefaultCellStyle.SelectionForeColor = Color.Black;

            dgvPrinters.CurrentCellDirtyStateChanged += (s, e) => {
                if (dgvPrinters.IsCurrentCellDirty)
                    dgvPrinters.CommitEdit(DataGridViewDataErrorContexts.Commit);
            };
            dgvPrinters.CellValueChanged += DgvPrinters_CellValueChanged;

            Label lblApiPort = new Label()
            {
                Text = "API端口:",
                Location = new Point(442, 24),
                AutoSize = true,
                Font = baseFont
            };

            nudApiPort = new NumericUpDown()
            {
                Location = new Point(442, 42),
                Size = new Size(80, 24),
                Minimum = 1,
                Maximum = 65535,
                Value = 9180,
                Font = baseFont
            };

            var btnRefreshPrinters = new Button()
            {
                Text = "🔄 刷新",
                Location = new Point(442, 76),
                Size = new Size(80, 28),
                Font = new Font("微软雅黑", 8F),
                BackColor = Color.FromArgb(120, 140, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnRefreshPrinters.FlatAppearance.BorderSize = 0;
            btnRefreshPrinters.Click += (s, e) => { RefreshPrinterList(); };

            var btnSelectAll = new Button()
            {
                Text = "全选",
                Location = new Point(442, 110),
                Size = new Size(38, 24),
                Font = new Font("微软雅黑", 7F),
                BackColor = Color.FromArgb(160, 180, 200),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnSelectAll.FlatAppearance.BorderSize = 0;
            btnSelectAll.Click += (s, e) => {
                for (int i = 0; i < dgvPrinters.Rows.Count; i++)
                    dgvPrinters.Rows[i].Cells[0].Value = true;
            };

            var btnDeselectAll = new Button()
            {
                Text = "取消",
                Location = new Point(484, 110),
                Size = new Size(38, 24),
                Font = new Font("微软雅黑", 7F),
                BackColor = Color.FromArgb(180, 160, 150),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnDeselectAll.FlatAppearance.BorderSize = 0;
            btnDeselectAll.Click += (s, e) => {
                for (int i = 0; i < dgvPrinters.Rows.Count; i++)
                    dgvPrinters.Rows[i].Cells[0].Value = false;
            };

            gbPrinter.Controls.AddRange(new Control[] {
                dgvPrinters, lblApiPort, nudApiPort, btnRefreshPrinters, btnSelectAll, btnDeselectAll
            });

            // ========== 服务器信息组 ==========
            GroupBox gbServerInfo = new GroupBox()
            {
                Text = "  📡  服务器信息",
                Location = new Point(12, 299),
                Size = new Size(560, 52),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            lblHostName = new Label()
            {
                Text = "主机名: ",
                Location = new Point(14, 22),
                Size = new Size(180, 18),
                Font = boldFont
            };

            lblIPAddress = new Label()
            {
                Text = "IP: ",
                Location = new Point(200, 22),
                Size = new Size(200, 18),
                Font = boldFont
            };

            gbServerInfo.Controls.AddRange(new Control[] { lblHostName, lblIPAddress });

            // ========== 服务管理组 ==========
            GroupBox gbService = new GroupBox()
            {
                Text = "  🔧  服务管理",
                Location = new Point(12, 359),
                Size = new Size(560, 55),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            btnInstallService = CreateButton("安装服务", 14, Color.FromArgb(120, 140, 180), Color.White);
            btnInstallService.Click += BtnInstallService_Click;

            btnUninstallService = CreateButton("卸载服务", 120, Color.FromArgb(160, 120, 100), Color.White);
            btnUninstallService.Click += BtnUninstallService_Click;

            btnStartService = CreateButton("启动服务", 226, Color.FromArgb(60, 160, 80), Color.White);
            btnStartService.Click += BtnStartService_Click;

            btnStopService = CreateButton("停止服务", 332, Color.FromArgb(200, 80, 70), Color.White);
            btnStopService.Click += BtnStopService_Click;

            btnStartStop = CreateButton("启动服务器", 438, Color.FromArgb(40, 140, 200), Color.White);
            btnStartStop.Click += BtnStartStop_Click;

            gbService.Controls.AddRange(new Control[] { btnInstallService, btnUninstallService, btnStartService, btnStopService, btnStartStop });

            // ========== 运行状态组 ==========
            GroupBox gbStatus = new GroupBox()
            {
                Text = "  📊  运行状态",
                Location = new Point(12, 422),
                Size = new Size(560, 50),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            lblStatus = new Label()
            {
                Text = "● 已停止",
                Location = new Point(14, 20),
                Size = new Size(160, 20),
                ForeColor = Color.FromArgb(200, 60, 50),
                Font = new Font("微软雅黑", 10F, FontStyle.Bold)
            };

            lblRunMode = new Label()
            {
                Text = "模式: -",
                Location = new Point(180, 20),
                Size = new Size(220, 20),
                ForeColor = Color.FromArgb(120, 120, 140),
                Font = new Font("微软雅黑", 10F, FontStyle.Bold)
            };

            btnClearLog = new Button()
            {
                Text = "🗑️ 清空日志",
                Location = new Point(406, 18),
                Size = new Size(80, 24),
                Font = new Font("微软雅黑", 8F),
                BackColor = Color.FromArgb(180, 100, 90),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnClearLog.FlatAppearance.BorderSize = 0;
            btnClearLog.Click += (s, e) => { txtLog.Clear(); };

            gbStatus.Controls.AddRange(new Control[] { lblStatus, lblRunMode, btnClearLog });

            // ========== 日志组 ==========
            GroupBox gbLog = new GroupBox()
            {
                Text = "  📝  运行日志",
                Location = new Point(12, 480),
                Size = new Size(560, 140),
                Font = new Font("微软雅黑", 9F, FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 80)
            };

            txtLog = new TextBox()
            {
                Location = new Point(14, 22),
                Size = new Size(532, 106),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                ReadOnly = true,
                BackColor = Color.FromArgb(30, 32, 38),
                ForeColor = Color.FromArgb(180, 220, 180),
                Font = new Font("Consolas", 8.5F),
                BorderStyle = BorderStyle.None
            };

            gbLog.Controls.Add(txtLog);

            // 添加到窗体
            this.Controls.AddRange(new Control[] {
                pnlHeader, gbLicense, gbPrinter, gbServerInfo, gbService, gbStatus, gbLog
            });

            Timer timer = new Timer();
            timer.Interval = 3000;
            timer.Tick += (s, e) => {
                UpdateServiceStatus();
                AutoRefreshServiceLog();
            };
            timer.Start();
        }

        /// <summary>
        /// 更新授权状态显示
        /// </summary>
        private void UpdateLicenseStatus()
        {
            try
            {
                var status = LicenseHelper.CurrentStatus;
                string statusText = LicenseHelper.GetStatusText();

                switch (status)
                {
                    case LicenseHelper.LicenseStatus.Licensed:
                        lblLicenseStatus.Text = statusText;
                        lblLicenseStatus.ForeColor = Color.Green;
                        // 更新有效期显示
                        UpdateExpiryLabel();
                        break;

                    case LicenseHelper.LicenseStatus.Unlicensed:
                        lblLicenseStatus.Text = "❌ 未授权";
                        lblLicenseStatus.ForeColor = Color.Red;
                        lblLicenseExpiry.Text = "";
                        break;

                    case LicenseHelper.LicenseStatus.Expired:
                        lblLicenseStatus.Text = "⌛ 授权已过期";
                        lblLicenseStatus.ForeColor = Color.OrangeRed;
                        lblLicenseExpiry.Text = LicenseHelper.GetLicenseExpiryText();
                        lblLicenseExpiry.ForeColor = Color.OrangeRed;
                        break;

                    case LicenseHelper.LicenseStatus.Disabled:
                        lblLicenseStatus.Text = "🚫 授权已被禁用";
                        lblLicenseStatus.ForeColor = Color.Red;
                        lblLicenseExpiry.Text = LicenseHelper.GetLicenseExpiryText();
                        lblLicenseExpiry.ForeColor = Color.Red;
                        break;

                    case LicenseHelper.LicenseStatus.NetworkError:
                        lblLicenseStatus.Text = "⚠ 网络错误，授权验证失败";
                        lblLicenseStatus.ForeColor = Color.Orange;
                        lblLicenseExpiry.Text = LicenseHelper.GetLicenseExpiryText();
                        lblLicenseExpiry.ForeColor = Color.Orange;
                        break;

                    default:
                        lblLicenseStatus.Text = "⏳ 验证中...";
                        lblLicenseStatus.ForeColor = Color.Gray;
                        lblLicenseExpiry.Text = "";
                        break;
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[UI] 更新授权状态异常: " + ex.Message);
                lblLicenseStatus.Text = "⏳ 授权系统初始化中...";
                lblLicenseStatus.ForeColor = Color.Gray;
                lblLicenseExpiry.Text = "";
            }
        }

        /// <summary>
        /// 更新有效期标签显示
        /// </summary>
        private void UpdateExpiryLabel()
        {
            string expiryText = LicenseHelper.GetLicenseExpiryText();
            lblLicenseExpiry.Text = expiryText;

            if (expiryText.Contains("永不过期"))
            {
                lblLicenseExpiry.ForeColor = Color.Green;
            }
            else if (expiryText.Contains("已过期"))
            {
                lblLicenseExpiry.ForeColor = Color.OrangeRed;
            }
            else
            {
                // 检查剩余天数，临近过期显示橙色
                int remainingDays = LicenseHelper.GetExpiryRemainingDays();
                if (remainingDays >= 0 && remainingDays <= 7)
                {
                    lblLicenseExpiry.ForeColor = Color.Orange;
                }
                else
                {
                    lblLicenseExpiry.ForeColor = Color.Green;
                }
            }
        }


        private Button CreateButton(string text, int x, Color backColor, Color foreColor)
        {
            var btn = new Button()
            {
                Text = text,
                Location = new Point(x, 17),
                Size = new Size(100, 28),
                Font = new Font("微软雅黑", 9F),
                BackColor = backColor,
                ForeColor = foreColor,
                FlatStyle = FlatStyle.Flat
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void LoadPrinters()
        {
            RefreshPrinterList();
        }

        /// <summary>
        /// 刷新打印机列表（DataGridView），保留端口配置
        /// </summary>
        private void RefreshPrinterList()
        {
            var physicalPrinters = new List<string>();

            try
            {
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT Name, PortName FROM Win32_Printer"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        string name = (obj["Name"] != null) ? obj["Name"].ToString().Trim() : "";
                        string portName = (obj["PortName"] != null) ? obj["PortName"].ToString() : "";
                        if (!string.IsNullOrEmpty(name) && !IsVirtualPrinter(name, portName))
                            physicalPrinters.Add(name);
                    }
                }
            }
            catch
            {
                foreach (string printer in PrinterSettings.InstalledPrinters)
                {
                    string trimmed = (printer != null) ? printer.Trim() : "";
                    if (!string.IsNullOrEmpty(trimmed))
                        physicalPrinters.Add(trimmed);
                }
            }

            // 回退
            if (physicalPrinters.Count == 0)
            {
                foreach (string printer in PrinterSettings.InstalledPrinters)
                {
                    string trimmed = (printer != null) ? printer.Trim() : "";
                    if (!string.IsNullOrEmpty(trimmed))
                        physicalPrinters.Add(trimmed);
                }
            }

            // 保存当前勾选状态和端口
            var checkedSet = new HashSet<string>();
            var portMap = new Dictionary<string, string>();
            for (int i = 0; i < dgvPrinters.Rows.Count; i++)
            {
                if (dgvPrinters.Rows[i].IsNewRow) continue;
                string name = (dgvPrinters.Rows[i].Cells["colName"].Value != null)
                    ? dgvPrinters.Rows[i].Cells["colName"].Value.ToString() : "";
                if (Convert.ToBoolean(dgvPrinters.Rows[i].Cells["colCheck"].Value ?? false))
                    checkedSet.Add(name);
                string port = (dgvPrinters.Rows[i].Cells["colPort"].Value != null)
                    ? dgvPrinters.Rows[i].Cells["colPort"].Value.ToString() : "";
                if (!string.IsNullOrEmpty(port))
                    portMap[name] = port;
            }

            // 合并config中的端口配置（优先保留）
            var savedConfigs = ConfigurationHelper.GetPrinterConfigs();
            foreach (var cfg in savedConfigs)
            {
                if (!portMap.ContainsKey(cfg.Name))
                    portMap[cfg.Name] = cfg.Port.ToString();
            }

            dgvPrinters.Rows.Clear();

            foreach (string name in physicalPrinters)
            {
                string portStr = "";
                if (portMap.ContainsKey(name))
                    portStr = portMap[name];

                bool isChecked = checkedSet.Contains(name);
                // 未勾选且无历史端口 → 不显示端口
                if (!isChecked && !portMap.ContainsKey(name))
                    portStr = "";

                dgvPrinters.Rows.Add(isChecked, name, portStr);
            }
        }

        /// <summary>
        /// 勾选状态或端口变更时，更新端口分配
        /// </summary>
        private void DgvPrinters_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            // 如果是勾选列变化，重新分配所有勾选行的端口
            if (e.ColumnIndex == 0)
            {
                int basePort = 9100;
                int checkedIdx = 0;
                for (int i = 0; i < dgvPrinters.Rows.Count; i++)
                {
                    bool isChecked = Convert.ToBoolean(dgvPrinters.Rows[i].Cells["colCheck"].Value ?? false);
                    if (isChecked)
                    {
                        string currentPort = (dgvPrinters.Rows[i].Cells["colPort"].Value != null)
                            ? dgvPrinters.Rows[i].Cells["colPort"].Value.ToString() : "";
                        int currentPortNum;
                        if (!int.TryParse(currentPort, out currentPortNum) || currentPortNum < 9100)
                            dgvPrinters.Rows[i].Cells["colPort"].Value = (basePort + checkedIdx).ToString();
                        checkedIdx++;
                    }
                    else
                    {
                        dgvPrinters.Rows[i].Cells["colPort"].Value = "";
                    }
                }
            }
        }

        /// <summary>
        /// 获取当前勾选的打印机配置列表
        /// </summary>
        private List<PrinterConfig> GetCheckedPrinterConfigs()
        {
            var configs = new List<PrinterConfig>();
            for (int i = 0; i < dgvPrinters.Rows.Count; i++)
            {
                if (dgvPrinters.Rows[i].IsNewRow) continue;
                bool isChecked = Convert.ToBoolean(dgvPrinters.Rows[i].Cells["colCheck"].Value ?? false);
                if (!isChecked) continue;

                string name = (dgvPrinters.Rows[i].Cells["colName"].Value != null)
                    ? dgvPrinters.Rows[i].Cells["colName"].Value.ToString().Trim() : "";
                string portStr = (dgvPrinters.Rows[i].Cells["colPort"].Value != null)
                    ? dgvPrinters.Rows[i].Cells["colPort"].Value.ToString() : "9100";
                int port;
                if (!int.TryParse(portStr, out port))
                    port = 9100 + configs.Count;

                configs.Add(new PrinterConfig { Name = name, Port = port, Enabled = true, Index = configs.Count });
            }
            return configs;
        }

        /// <summary>
        /// 判断是否为虚拟打印机
        /// </summary>
        private static bool IsVirtualPrinter(string printerName, string portName)
        {
            // 1. 通过端口判断：虚拟打印机通常使用这些端口
            string portUpper = (portName ?? "").ToUpperInvariant();
            if (portUpper.StartsWith("PORTPROMPT:") ||  // Microsoft Print to PDF 等
                portUpper.StartsWith("FILE:") ||         // 打印到文件
                portUpper == "NUL:" ||                   // 空端口
                portUpper.StartsWith("SHRFAX:") ||       // 传真
                portUpper.Contains("PROMPT"))            // 其他提示型端口
            {
                return true;
            }

            // 2. 通过名称判断：常见虚拟打印机名称特征
            string nameUpper = (printerName ?? "").ToUpperInvariant();
            string[] virtualKeywords = {
                "PRINT TO PDF", "PRINT TO FILE",
                "MICROSOFT PDF", "MICROSOFT PRINT TO PDF",
                "MICROSOFT XPS", "XPS DOCUMENT",
                "FAX", "传真",
                "ONENOTE", "SEND TO ONENOTE",
                "MICROSOFT TO PDF",
            };

            foreach (string keyword in virtualKeywords)
            {
                if (nameUpper.Contains(keyword))
                    return true;
            }

            return false;
        }

        private void LoadSavedSettings()
        {
            try
            {
                string savedApiPort = ConfigurationHelper.GetSetting("ApiPort", "9180");
                int apiPort;
                if (int.TryParse(savedApiPort, out apiPort))
                    nudApiPort.Value = apiPort;

                // 恢复上次勾选的打印机和端口
                var savedConfigs = ConfigurationHelper.GetPrinterConfigs();
                if (savedConfigs.Count > 0)
                {
                    var configMap = new Dictionary<string, PrinterConfig>();
                    foreach (var cfg in savedConfigs)
                        configMap[cfg.Name] = cfg;

                    for (int i = 0; i < dgvPrinters.Rows.Count; i++)
                    {
                        string name = (dgvPrinters.Rows[i].Cells["colName"].Value != null)
                            ? dgvPrinters.Rows[i].Cells["colName"].Value.ToString().Trim() : "";
                        if (configMap.ContainsKey(name))
                        {
                            dgvPrinters.Rows[i].Cells["colCheck"].Value = true;
                            dgvPrinters.Rows[i].Cells["colPort"].Value = configMap[name].Port.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[UI] 加载保存设置异常: " + ex.Message);
            }
        }

        private void UpdateNetworkInfo()
        {
            List<string> addresses = NetworkHelper.GetAllNetworkAddresses();
            string computerName = Environment.MachineName;

            lblHostName.Text = "主机名: " + computerName;
            lblIPAddress.Text = "IP: " + string.Join(", ", addresses);
        }

        private string lastLogFileContent = "";

        private void LoadExistingLog()
        {
            try
            {
                string[] lines = LogHelper.GetRecentLogLines(500);
                int lineCount = LogHelper.GetTodayLogLineCount();

                if (lines.Length > 0)
                {
                    for (int i = 0; i < lines.Length; i++)
                    {
                        txtLog.AppendText(lines[i] + Environment.NewLine);
                    }
                }

                if (lineCount > 0)
                {
                    txtLog.AppendText("[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] --- 已加载今日日志，共 " + lineCount + " 行 ---" + Environment.NewLine);
                }

                lastLogFileContent = LogHelper.ReadTodayLog();
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[UI] 加载已有日志异常: " + ex.Message);
            }
        }

        private void AutoRefreshServiceLog()
        {
            try
            {
                if (isRunning)
                    return;

                string result = RunCmd("sc", "query PrintServer", false);
                if (!result.Contains("RUNNING"))
                    return;

                string currentContent = LogHelper.ReadTodayLog();

                // 基于文本内容比较，找出真正新增的部分
                if (currentContent.Length > lastLogFileContent.Length &&
                    currentContent.StartsWith(lastLogFileContent))
                {
                    // 只有新增内容
                    string newContent = currentContent.Substring(lastLogFileContent.Length).Trim();
                    if (!string.IsNullOrEmpty(newContent))
                    {
                        txtLog.AppendText(newContent + Environment.NewLine);
                    }
                }
                else if (!string.IsNullOrEmpty(currentContent) && currentContent != lastLogFileContent)
                {
                    // 文件被重写或清空过，追加全部
                    txtLog.AppendText(currentContent + Environment.NewLine);
                }

                lastLogFileContent = currentContent;
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[UI] 自动刷新服务日志异常: " + ex.Message);
            }
        }

        private void UpdateServiceStatus()
        {
            try
            {
                string result = RunCmd("sc", "query PrintServer", false);

                if (result.Contains("RUNNING"))
                {
                    if (!isRunning)
                    {
                        lblStatus.Text = "● 运行中";
                        lblStatus.ForeColor = Color.Green;
                        lblRunMode.Text = "模式: Windows 服务";
                        lblRunMode.ForeColor = Color.DarkBlue;
                        btnStartStop.Enabled = false; // 服务运行中禁用启动服务器
                    }
                }
                else if (result.Contains("STOPPED"))
                {
                    if (!isRunning)
                    {
                        lblStatus.Text = "● 已停止";
                        lblStatus.ForeColor = Color.OrangeRed;
                        lblRunMode.Text = "模式: Windows 服务 (未运行)";
                        lblRunMode.ForeColor = Color.Gray;
                        btnStartStop.Enabled = true; // 服务已停止恢复启用
                    }
                }
                else if (result.Contains("1060"))
                {
                    if (!isRunning)
                    {
                        lblStatus.Text = "● 已停止";
                        lblStatus.ForeColor = Color.Red;
                        lblRunMode.Text = "模式: -";
                        lblRunMode.ForeColor = Color.Gray;
                        btnStartStop.Enabled = true; // 服务未安装恢复启用
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[UI] 更新服务状态异常: " + ex.Message);
            }
        }

        private void BtnStartStop_Click(object sender, EventArgs e)
        {
            if (!isRunning)
            {
                StartServer();
            }
            else
            {
                StopServer();
            }
        }

        private void BtnInstallService_Click(object sender, EventArgs e)
        {
            try
            {
                // 检查服务是否已存在
                string checkResult = RunCmd("sc", "query PrintServer", false);
                if (!checkResult.Contains("1060"))
                {
                    LogToTextBox("服务已存在，无需重复安装");
                    MessageBox.Show("PrintServer 服务已存在，无需重复安装。\n如需重新安装请先卸载。",
                        "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                SaveSettings();

                string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location;

                LogToTextBox("执行: sc create PrintServer");
                string createArgs = "create PrintServer binPath= \"\\\"" + exePath + "\\\" /service\" start= auto DisplayName= \"网络打印服务器\"";
                string result = RunCmd("sc", createArgs, false);

                if (result.Contains("成功") || result.Contains("success"))
                {
                    LogToTextBox("返回: sc create PrintServer 成功");
                    LogToTextBox("执行: 设置服务描述和故障恢复");
                    RunCmd("sc", "description PrintServer \"将本地打印机共享为网络打印机\"", false);
                    RunCmd("sc", "failure PrintServer reset= 86400 actions= restart/60000/restart/60000/restart/60000", false);

                    LogToTextBox("执行: sc start PrintServer");
                    System.Threading.Thread.Sleep(500);
                    string startResult = RunCmd("sc", "start PrintServer", false);
                    if (startResult.Contains("START_PENDING") || startResult.Contains("RUNNING") || startResult.Contains("1056"))
                    {
                        LogToTextBox("返回: sc start PrintServer 成功");
                    }

                    LogToTextBox("Windows服务安装并启动成功");
                    UpdateServiceStatus();
                    var configs = GetCheckedPrinterConfigs();
                    string printerList = "";
                    foreach (var cfg in configs)
                        printerList += cfg.Name + " (端口" + cfg.Port + ")\n";
                    if (string.IsNullOrEmpty(printerList))
                        printerList = "未设置\n";
                    string msg = "服务安装成功已启动！\n\n" +
                        "配置详情\n" +
                        "服务名称: PrintServer\n" +
                        "启动方式: 自动\n" +
                        "显示名称: 网络打印服务器\n" +
                        "打印机:\n" + printerList +
                        "API端口: " + nudApiPort.Value.ToString();
                    MessageBox.Show(msg, "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    LogToTextBox("安装失败");
                    MessageBox.Show("安装失败，请以管理员身份运行！\n\n" + result,
                        "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                LogToTextBox("安装异常: " + ex.Message);
                MessageBox.Show("安装服务时出错：" + ex.Message,
                    "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnUninstallService_Click(object sender, EventArgs e)
        {
            try
            {
                LogToTextBox("执行: sc stop PrintServer");
                string stopResult = RunCmd("sc", "stop PrintServer", false);
                if (stopResult.Contains("STOP_PENDING") || stopResult.Contains("STOPPED") || stopResult.Contains("1062"))
                {
                    LogToTextBox("返回: sc stop PrintServer 成功");
                    LogToTextBox("Windows服务停止成功");
                }
                System.Threading.Thread.Sleep(1000);

                LogToTextBox("执行: sc delete PrintServer");
                string result = RunCmd("sc", "delete PrintServer", false);

                if (result.Contains("成功") || result.Contains("success"))
                {
                    LogToTextBox("返回: sc delete PrintServer 成功");
                    UpdateServiceStatus();
                    MessageBox.Show("服务卸载成功！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (result.Contains("1060"))
                {
                    LogToTextBox("服务未安装");
                    MessageBox.Show("服务未安装", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    LogToTextBox("卸载结果: " + result);
                    MessageBox.Show("卸载结果: " + result, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                LogToTextBox("卸载异常: " + ex.Message);
                MessageBox.Show("卸载服务时出错：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnStartService_Click(object sender, EventArgs e)
        {
            try
            {
                // 检查服务是否已在运行
                string checkResult = RunCmd("sc", "query PrintServer", false);
                if (checkResult.Contains("RUNNING"))
                {
                    LogToTextBox("服务已在运行中，无需重复启动");
                    MessageBox.Show("服务已在运行中！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                SaveSettings();

                LogToTextBox("执行: sc start PrintServer");
                string result = RunCmd("sc", "start PrintServer", false);

                if (result.Contains("START_PENDING") || result.Contains("RUNNING") || result.Contains("1056"))
                {
                    LogToTextBox("返回: sc start PrintServer 成功");
                    LogToTextBox("Windows服务启动成功");
                    UpdateServiceStatus();
                    string msg = "服务状态：启动成功\n\n" +
                        "服务名称：PrintServer\n" +
                        "启动方式：自动\n" +
                        "显示名称：网络打印服务器";
                    MessageBox.Show(msg, "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (result.Contains("1060"))
                {
                    LogToTextBox("服务未安装，请先安装服务");
                    MessageBox.Show("服务未安装，请先点击\"安装服务\"！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    LogToTextBox("启动结果: " + result);
                    MessageBox.Show("启动结果: " + result, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                LogToTextBox("启动异常: " + ex.Message);
                MessageBox.Show("启动服务失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnStopService_Click(object sender, EventArgs e)
        {
            try
            {
                LogToTextBox("执行: sc stop PrintServer");
                string result = RunCmd("sc", "stop PrintServer", false);

                if (result.Contains("STOP_PENDING") || result.Contains("STOPPED"))
                {
                    LogToTextBox("返回: sc stop PrintServer 成功");
                    LogToTextBox("Windows服务停止成功");
                    UpdateServiceStatus();
                    string msg = "服务状态：停止成功\n\n" +
                        "服务名称：PrintServer\n" +
                        "启动方式：自动\n" +
                        "显示名称：网络打印服务器";
                    MessageBox.Show(msg, "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (result.Contains("1060"))
                {
                    LogToTextBox("服务未安装");
                    MessageBox.Show("服务未安装！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (result.Contains("1062"))
                {
                    LogToTextBox("服务未在运行");
                    MessageBox.Show("服务未在运行中！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    LogToTextBox("停止结果: " + result);
                    MessageBox.Show("停止结果: " + result, "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                LogToTextBox("停止异常: " + ex.Message);
                MessageBox.Show("停止服务失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveSettings()
        {
            try
            {
                var config = System.Configuration.ConfigurationManager.OpenExeConfiguration(
                    System.Configuration.ConfigurationUserLevel.None);

                var configs = GetCheckedPrinterConfigs();
                string apiPort = nudApiPort.Value.ToString();

                // 设置公共配置
                SetConfigValue(config, "ApiPort", apiPort);
                SetConfigValue(config, "PrinterCount", configs.Count.ToString());

                // 保存多打印机配置
                for (int i = 0; i < 20; i++)
                {
                    // 清理旧配置
                    if (config.AppSettings.Settings["Printer" + i + "_Name"] != null)
                        config.AppSettings.Settings["Printer" + i + "_Name"].Value = "";
                    if (config.AppSettings.Settings["Printer" + i + "_Port"] != null)
                        config.AppSettings.Settings["Printer" + i + "_Port"].Value = "";
                    if (config.AppSettings.Settings["Printer" + i + "_Enabled"] != null)
                        config.AppSettings.Settings["Printer" + i + "_Enabled"].Value = "false";
                }

                // 写入当前选中的打印机
                for (int i = 0; i < configs.Count; i++)
                {
                    SetConfigValue(config, "Printer" + i + "_Name", configs[i].Name);
                    SetConfigValue(config, "Printer" + i + "_Port", configs[i].Port.ToString());
                    SetConfigValue(config, "Printer" + i + "_Enabled", "true");
                }

                // 兼容旧配置
                SetConfigValue(config, "PrinterName", configs.Count > 0 ? configs[0].Name : "");
                SetConfigValue(config, "Port", configs.Count > 0 ? configs[0].Port.ToString() : "9100");

                config.Save(System.Configuration.ConfigurationSaveMode.Modified);
                System.Configuration.ConfigurationManager.RefreshSection("appSettings");
            }
            catch (Exception ex)
            {
                LogToTextBox("保存配置失败: " + ex.Message);
            }
        }

        private void SetConfigValue(System.Configuration.Configuration config, string key, string value)
        {
            if (config.AppSettings.Settings[key] != null)
                config.AppSettings.Settings[key].Value = value;
            else
                config.AppSettings.Settings.Add(key, value);
        }

        private string RunCmd(string fileName, string arguments, bool showLog)
        {
            try
            {
                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = fileName;
                process.StartInfo.Arguments = arguments;
                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                process.StartInfo.CreateNoWindow = true;
                process.Start();

                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                string result = output + error;
                if (showLog)
                {
                    LogToTextBox("执行: " + fileName + " " + arguments);
                    if (!string.IsNullOrEmpty(result.Trim()))
                    {
                        LogToTextBox("返回: " + result.Trim());
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                return "异常: " + ex.Message;
            }
        }

        private void StartServer()
        {
            var configs = GetCheckedPrinterConfigs();
            if (configs.Count == 0)
            {
                MessageBox.Show("请至少勾选一台打印机！", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                SaveSettings();

                LogToTextBox("正在启动 " + configs.Count + " 台打印机...");

                foreach (var cfg in configs)
                {
                    var server = new PrintServerService(cfg.Name, cfg.Port);
                    server.OnLog += Server_OnLog;
                    server.OnClientCountChanged += Server_OnClientCountChanged;
                    server.Start();
                    _servers.Add(server);
                    LogToTextBox("✅ " + cfg.Name + " → 端口 " + cfg.Port);
                }

                // 启动 HTTP API 服务
                int apiPort = (int)nudApiPort.Value;
                _apiServer = new HttpApiService(configs, apiPort);
                _apiServer.OnLog += Server_OnLog;
                _apiServer.Start();

                isRunning = true;
                btnStartStop.Text = "停止服务器";
                btnStartStop.BackColor = Color.FromArgb(200, 80, 70);
                dgvPrinters.Enabled = false;
                nudApiPort.Enabled = false;
                btnInstallService.Enabled = false;
                btnUninstallService.Enabled = false;
                btnStartService.Enabled = false;
                btnStopService.Enabled = false;
                lblStatus.Text = "● 运行中 (" + configs.Count + "台打印机)";
                lblStatus.ForeColor = Color.Green;
                lblRunMode.Text = "模式: 应用程序";
                lblRunMode.ForeColor = Color.DarkGreen;

                System.Media.SystemSounds.Beep.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("启动失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void StopServer()
        {
            try
            {
                if (_apiServer != null)
                {
                    _apiServer.Stop();
                    _apiServer = null;
                }
                foreach (var server in _servers)
                {
                    try { server.Stop(); } catch { }
                }
                _servers.Clear();

                isRunning = false;
                btnStartStop.Text = "启动服务器";
                btnStartStop.BackColor = Color.FromArgb(40, 140, 200);
                dgvPrinters.Enabled = true;
                nudApiPort.Enabled = true;
                btnInstallService.Enabled = true;
                btnUninstallService.Enabled = true;
                btnStartService.Enabled = true;
                btnStopService.Enabled = true;
                lblStatus.Text = "● 已停止";
                lblStatus.ForeColor = Color.OrangeRed;
                lblRunMode.Text = "模式: -";
                lblRunMode.ForeColor = Color.Gray;

                LogToTextBox("所有打印服务已停止");
                System.Media.SystemSounds.Asterisk.Play();
            }
            catch (Exception ex)
            {
                MessageBox.Show("停止失败：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void PrintServerForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isRunning)
            {
                var result = MessageBox.Show("服务器正在运行，关闭窗口将停止服务。\n是否继续？",
                    "确认", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result == DialogResult.Yes)
                {
                    StopServer();
                }
                else
                {
                    e.Cancel = true;
                }
            }
        }

        private void WriteLogToFile(string message)
        {
            LogHelper.WriteLog(message);
        }

        private void Server_OnLog(string message)
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action<string>(Server_OnLog), message);
                return;
            }

            txtLog.AppendText(message + Environment.NewLine);
            WriteLogToFile(message);
            lastLogFileContent = LogHelper.ReadTodayLog();

            if (txtLog.Lines.Length > 1000)
            {
                string[] lines = txtLog.Lines;
                string[] newLines = new string[500];
                Array.Copy(lines, lines.Length - 500, newLines, 0, 500);
                txtLog.Lines = newLines;
            }
        }

        private void Server_OnClientCountChanged(int count)
        {
            // 不再显示连接数
        }

        private void LogToTextBox(string message)
        {
            string logMessage = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " + message;
            txtLog.AppendText(logMessage + Environment.NewLine);
            WriteLogToFile(logMessage);
            lastLogFileContent = LogHelper.ReadTodayLog();
        }
    }
}
