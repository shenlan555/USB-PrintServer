using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace PrintServer
{
    public static class LogHelper
    {
        private static readonly string LogDirectory;
        private static readonly object LockObject = new object();

        static LogHelper()
        {
            LogDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log");
            try
            {
                Directory.CreateDirectory(LogDirectory);
                CleanupOldLogs();
            }
            catch
            {
            }
        }

        /// <summary>
        /// 获取今天的日志文件路径（按天分割）
        /// </summary>
        public static string GetTodayLogPath()
        {
            return Path.Combine(LogDirectory, string.Format("printserver-{0}.log", DateTime.Now.ToString("yyyy-MM-dd")));
        }

        /// <summary>
        /// 根据日期获取历史日志文件路径
        /// </summary>
        public static string GetLogPathByDate(DateTime date)
        {
            return Path.Combine(LogDirectory, string.Format("printserver-{0}.log", date.ToString("yyyy-MM-dd")));
        }

        /// <summary>
        /// 写入日志（线程安全）
        /// </summary>
        public static void WriteLog(string message)
        {
            lock (LockObject)
            {
                try
                {
                    string logPath = GetTodayLogPath();
                    File.AppendAllText(logPath, message + Environment.NewLine, Encoding.UTF8);
                }
                catch
                {
                }
            }
        }

        /// <summary>
        /// 读取今天的日志全部内容
        /// </summary>
        public static string ReadTodayLog()
        {
            try
            {
                string logPath = GetTodayLogPath();
                if (File.Exists(logPath))
                    return File.ReadAllText(logPath, Encoding.UTF8).Trim();
            }
            catch
            {
            }
            return string.Empty;
        }

        /// <summary>
        /// 获取今天的日志行数
        /// </summary>
        public static int GetTodayLogLineCount()
        {
            try
            {
                string content = ReadTodayLog();
                if (string.IsNullOrEmpty(content))
                    return 0;
                return content.Split(new[] { Environment.NewLine }, StringSplitOptions.None).Length;
            }
            catch
            {
                return 0;
            }
        }

        /// <summary>
        /// 获取最近 N 行日志
        /// </summary>
        public static string[] GetRecentLogLines(int maxLines)
        {
            try
            {
                string content = ReadTodayLog();
                if (string.IsNullOrEmpty(content))
                    return new string[0];

                string[] lines = content.Split(new[] { Environment.NewLine }, StringSplitOptions.None);
                if (lines.Length <= maxLines)
                    return lines;

                string[] result = new string[maxLines];
                Array.Copy(lines, lines.Length - maxLines, result, 0, maxLines);
                return result;
            }
            catch
            {
                return new string[0];
            }
        }

        /// <summary>
        /// 获取所有日志文件列表（按日期排序）
        /// </summary>
        public static List<string> GetAllLogFiles()
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo(LogDirectory);
                FileInfo[] files = dir.GetFiles("printserver-*.log");
                Array.Sort(files, (a, b) => a.Name.CompareTo(b.Name));
                List<string> result = new List<string>();
                foreach (var f in files)
                    result.Add(f.FullName);
                return result;
            }
            catch
            {
                return new List<string>();
            }
        }

        /// <summary>
        /// 清理超过指定天数的日志文件（从配置文件 LogRetentionDays 读取，默认15天）
        /// </summary>
        public static void CleanupOldLogs()
        {
            try
            {
                int retentionDays = 15;
                try
                {
                    string val = System.Configuration.ConfigurationManager.AppSettings["LogRetentionDays"];
                    if (!string.IsNullOrEmpty(val))
                        retentionDays = int.Parse(val);
                }
                catch { }

                DirectoryInfo dir = new DirectoryInfo(LogDirectory);
                if (!dir.Exists) return;

                DateTime cutoff = DateTime.Now.AddDays(-retentionDays);
                foreach (FileInfo file in dir.GetFiles("printserver-*.log"))
                {
                    // 从文件名解析日期：printserver-2026-05-03.log
                    string name = file.Name;
                    if (name.Length >= 22) // "printserver-YYYY-MM-DD.log" = 26 chars
                    {
                        string datePart = name.Substring(12, 10); // "YYYY-MM-DD"
                        DateTime fileDate;
                        if (DateTime.TryParse(datePart, out fileDate))
                        {
                            if (fileDate < cutoff)
                            {
                                file.Delete();
                            }
                        }
                        else
                        {
                            // 如果文件名解析失败，按最后修改时间判断
                            if (file.LastWriteTime < cutoff)
                            {
                                file.Delete();
                            }
                        }
                    }
                    else
                    {
                        // 不符合命名规则的旧日志文件也按最后修改时间清理
                        if (file.LastWriteTime < cutoff)
                        {
                            file.Delete();
                        }
                    }
                }
            }
            catch
            {
            }
        }
    }
}
