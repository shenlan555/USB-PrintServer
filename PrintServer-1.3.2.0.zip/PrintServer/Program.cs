using System;
using System.ServiceProcess;
using System.Windows.Forms;

namespace PrintServer
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            // 初始化反调试系统（检查注册表黑名单 + 启动守护线程）
            AntiDebug.Initialize();

            // 反调试检测点 1：程序入口
            AntiDebug.Checkpoint("MainEntry");

            // 初始化授权系统
            LicenseHelper.Initialize();
            LicenseHelper.StatusChanged += OnLicenseStatusChanged;

            // 处理命令行参数
            if (args.Length > 0)
            {
                switch (args[0].ToLower())
                {
                    case "/service":
                    case "-service":
                    case "/s":
                        // 服务模式：启动服务
                        ServiceBase[] ServicesToRun;
                        ServicesToRun = new ServiceBase[]
                        {
                            new PrintServerWindowsService()
                        };
                        ServiceBase.Run(ServicesToRun);
                        return;

                    case "/install":
                    case "-install":
                        InstallService();
                        return;

                    case "/uninstall":
                    case "-uninstall":
                        UninstallService();
                        return;
                }
            }

            // GUI 模式：强制授权校验
            RunGUI();
        }

        /// <summary>
        /// 授权状态变更回调
        /// </summary>
        private static void OnLicenseStatusChanged(object sender, LicenseStatusEventArgs e)
        {
            // 状态变更时的处理（可用于日志记录）
        }

        /// <summary>
        /// GUI 模式启动
        /// </summary>
        private static void RunGUI()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            bool createdNew;
            using (System.Threading.Mutex mutex = new System.Threading.Mutex(true, "PrintServer_Mutex", out createdNew))
            {
                if (!createdNew)
                {
                    MessageBox.Show("打印服务器已经在运行中！", "提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // 强制授权验证
                if (!CheckLicense())
                    return;

                Application.Run(new PrintServerForm());
            }
        }

        /// <summary>
        /// 强制授权验证
        /// 未授权 → 弹出 LicenseForm 阻止使用
        /// 修复Bug1：删除 license.dat 后，不自动联网重生，强制弹出授权窗口
        /// </summary>
        private static bool CheckLicense()
        {
            // 修复Bug1：如果本地授权文件不存在，跳过联网验证直接弹出授权窗口
            // 防止 ValidateWithServerSync() 自动重生存档导致授权绕过
            if (!LicenseHelper.HasLocalLicenseFile)
            {
                LicenseHelper.ForceLicenseReactivation();

                using (LicenseForm licenseForm = new LicenseForm())
                {
                    DialogResult result = licenseForm.ShowDialog();

                    if (result != DialogResult.OK)
                    {
                        return false;
                    }

                    if (LicenseHelper.CurrentStatus != LicenseHelper.LicenseStatus.Licensed)
                    {
                        MessageBox.Show("授权验证失败，程序无法启动", "授权失败",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false;
                    }
                }
            }
            else
            {
                // license.dat 存在，正常联网验证
                bool valid = LicenseHelper.StartValidation();

                if (!valid)
                {
                    using (LicenseForm licenseForm = new LicenseForm())
                    {
                        DialogResult result = licenseForm.ShowDialog();

                        if (result != DialogResult.OK)
                        {
                            return false;
                        }

                        if (LicenseHelper.CurrentStatus != LicenseHelper.LicenseStatus.Licensed)
                        {
                            MessageBox.Show("授权验证失败，程序无法启动", "授权失败",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return false;
                        }
                    }
                }
            }

            // 反调试检测点 2：授权通过后
            AntiDebug.Checkpoint("AfterLicense");

            return true;
        }

        private static void InstallService()
        {
            try
            {
                string path = System.Reflection.Assembly.GetExecutingAssembly().Location;

                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = "sc";
                process.StartInfo.Arguments = string.Format("create PrintServer binPath= \"\\\"{0}\\\" /service\" start= auto DisplayName= \"网络打印服务器\"", path);
                process.StartInfo.Verb = "runas";
                process.StartInfo.UseShellExecute = true;
                process.Start();
                process.WaitForExit();

                if (process.ExitCode == 0)
                {
                    System.Diagnostics.Process.Start("sc", "description PrintServer \"将本地打印机共享为网络打印机\"").WaitForExit();
                    System.Diagnostics.Process.Start("sc", "start PrintServer").WaitForExit();

                    MessageBox.Show("服务安装成功并已启动！", "成功",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("服务安装失败，请以管理员身份运行！", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("安装服务时出错：{0}", ex.Message), "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private static void UninstallService()
        {
            try
            {
                System.Diagnostics.Process.Start("sc", "stop PrintServer").WaitForExit();

                System.Diagnostics.Process process = new System.Diagnostics.Process();
                process.StartInfo.FileName = "sc";
                process.StartInfo.Arguments = "delete PrintServer";
                process.StartInfo.Verb = "runas";
                process.StartInfo.UseShellExecute = true;
                process.Start();
                process.WaitForExit();

                if (process.ExitCode == 0)
                {
                    MessageBox.Show("服务卸载成功！", "成功",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("服务卸载失败，请以管理员身份运行！", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Format("卸载服务时出错：{0}", ex.Message), "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
