using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Threading;
using System.Drawing.Printing;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace PrintServer
{
    public class PrintServerWindowsService : ServiceBase
    {
        private List<PrintServerService> _servers = new List<PrintServerService>();
        private HttpApiService _apiServer;
        private EventLog serviceEventLog;

        public PrintServerWindowsService()
        {
            this.ServiceName = "PrintServer";
            this.CanStop = true;
            this.CanPauseAndContinue = false;
            this.AutoLog = true;

            serviceEventLog = new EventLog();
            serviceEventLog.Source = "PrintServer";
            serviceEventLog.Log = "Application";

            LicenseHelper.Initialize();
            AntiDebug.Checkpoint("ServiceInit");
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                bool licensed = LicenseHelper.StartValidation();
                if (!licensed)
                {
                    string statusText = LicenseHelper.GetStatusText();
                    string errorMsg = string.Format("授权验证失败，服务启动被阻止。状态: {0}", statusText);
                    serviceEventLog.WriteEntry(errorMsg, EventLogEntryType.Error);
                    LogHelper.WriteLog("[授权] " + errorMsg);
                    this.ExitCode = 1066;
                    this.Stop();
                    return;
                }

                AntiDebug.Checkpoint("ServiceStart");

                // 获取所有启用的打印机配置
                var configs = ConfigurationHelper.GetPrinterConfigs();
                if (configs.Count == 0)
                {
                    string errorMsg = "没有配置任何打印机，服务启动失败";
                    serviceEventLog.WriteEntry(errorMsg, EventLogEntryType.Error);
                    LogHelper.WriteLog("[服务] " + errorMsg);
                    this.ExitCode = 1066;
                    this.Stop();
                    return;
                }

                LogHelper.WriteLog("[授权] 服务启动，授权验证通过 - " + LicenseHelper.CurrentLicenseKey);
                LogHelper.WriteLog("[服务] 开始启动 " + configs.Count + " 台打印机...");

                // 启动所有打印机监听
                foreach (var config in configs)
                {
                    var server = new PrintServerService(config.Name, config.Port);
                    server.OnLog += Server_OnLog;
                    Thread serviceThread = new Thread(new ThreadStart(server.Start));
                    serviceThread.IsBackground = true;
                    serviceThread.Start();
                    _servers.Add(server);
                    LogHelper.WriteLog("[服务] 已启动: " + config.Name + " (端口 " + config.Port + ")");
                }

                // 启动 HTTP API 服务
                int apiPort = int.Parse(ConfigurationHelper.GetSetting("ApiPort", "9180"));
                _apiServer = new HttpApiService(configs, apiPort);
                _apiServer.OnLog += Server_OnLog;
                _apiServer.Start();
            }
            catch (Exception ex)
            {
                string errorMsg = "服务启动失败: " + ex.Message;
                serviceEventLog.WriteEntry(errorMsg, EventLogEntryType.Error);
                LogHelper.WriteLog("[服务] " + errorMsg);
                throw;
            }
        }

        private void Server_OnLog(string message)
        {
            try
            {
                if (!EventLog.SourceExists("PrintServer"))
                    EventLog.CreateEventSource("PrintServer", "Application");
                serviceEventLog.WriteEntry(message, EventLogEntryType.Information);
            }
            catch { }
            LogHelper.WriteLog(message);
        }

        protected override void OnStop()
        {
            if (_apiServer != null)
                _apiServer.Stop();
            foreach (var server in _servers)
            {
                try { server.Stop(); } catch { }
            }
            _servers.Clear();
        }
    }

    public class PrintServerService
    {
        private TcpListener listener;
        private string printerName;
        private int port;
        private bool isRunning;
        private List<TcpClient> activeClients = new List<TcpClient>();
        private object lockObject = new object();

        public event Action<string> OnLog;
        public event Action<int> OnClientCountChanged;

        public bool IsRunning { get { return isRunning; } }

        public PrintServerService(string printerName, int port = 9100)
        {
            this.printerName = printerName;
            this.port = port;
        }

        public void Start()
        {
            try
            {
                // 监听所有网络接口，包括来自主机名和IP的访问
                listener = new TcpListener(IPAddress.IPv6Any, port);
                listener.Server.SetSocketOption(SocketOptionLevel.IPv6, SocketOptionName.IPv6Only, false);
                listener.Start();
                isRunning = true;

                string serverInfo = GetServerInfo();
                Log("打印服务器启动成功");
                Log("监听地址: 0.0.0.0 (所有网络接口)");
                Log("访问方式:");
                Log("主机名: " + Environment.MachineName);
                Log("IP地址: " + string.Join(", ", NetworkHelper.GetAllNetworkAddresses()));
                Log("打印机: " + printerName);
                Log("端口: " + port);

                Thread listenThread = new Thread(new ThreadStart(ListenForClients));
                listenThread.IsBackground = true;
                listenThread.Start();
            }
            catch (Exception ex)
            {
                Log("启动失败: " + ex.Message);
                throw;
            }
        }

        private string GetServerInfo()
        {
            List<string> addresses = NetworkHelper.GetAllNetworkAddresses();
            string computerName = Environment.MachineName;

            string info = "计算机名: " + computerName + ", IP: " + string.Join(", ", addresses);
            return info;
        }

        private void ListenForClients()
        {
            while (isRunning)
            {
                try
                {
                    TcpClient client = listener.AcceptTcpClient();

                    lock (lockObject)
                    {
                        activeClients.Add(client);
                        if (OnClientCountChanged != null)
                            OnClientCountChanged(activeClients.Count);
                    }

                    Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClient));
                    clientThread.IsBackground = true;
                    clientThread.Start(client);
                }
                catch (SocketException)
                {
                    if (isRunning)
                    {
                        Log("监听Socket异常");
                    }
                }
                catch (Exception ex)
                {
                    Log("监听异常: " + ex.Message);
                }
            }
        }

        private void HandleClient(object obj)
        {
            TcpClient client = (TcpClient)obj;
            string clientAddress = "";

            try
            {
                clientAddress = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
                string clientName = NetworkHelper.GetHostName(clientAddress);

                Log("收到连接: " + clientName + " (" + clientAddress + ")");

                using (client)
                using (NetworkStream stream = client.GetStream())
                {
                    string tempFile = Path.GetTempFileName() + ".prn";

                    // 从配置文件读取接收超时（秒），默认30秒
                    int timeoutSec = 30;
                    try
                    {
                        string val = System.Configuration.ConfigurationManager.AppSettings["ReceiveTimeout"];
                        if (!string.IsNullOrEmpty(val))
                            timeoutSec = int.Parse(val);
                    }
                    catch { }

                    using (FileStream fs = new FileStream(tempFile, FileMode.Create, FileAccess.Write))
                    {
                        byte[] buffer = new byte[8192];
                        int bytesRead;
                        int totalBytes = 0;

                        stream.ReadTimeout = timeoutSec * 1000;
                        client.ReceiveTimeout = timeoutSec * 1000;

                        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            fs.Write(buffer, 0, bytesRead);
                            totalBytes += bytesRead;
                        }

                        Log("接收数据: " + FormatSize(totalBytes) + " 来自 " + clientName);
                    }

                    PrintDocumentFile(tempFile);

                    Log("打印完成: " + clientName);

                    try { File.Delete(tempFile); } catch { }
                }
            }
            catch (Exception ex)
            {
                Log("处理客户端 " + clientAddress + " 错误: " + ex.Message);
            }
            finally
            {
                lock (lockObject)
                {
                    activeClients.Remove(client);
                    if (OnClientCountChanged != null)
                        OnClientCountChanged(activeClients.Count);
                }
            }
        }

        private void PrintDocumentFile(string filePath)
        {
            try
            {
                using (FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                {
                    byte[] fileData = new byte[fs.Length];
                    fs.Read(fileData, 0, fileData.Length);

                    RawPrinterHelper.SendBytesToPrinter(printerName, fileData);
                }
            }
            catch (Exception ex)
            {
                Log("打印失败: " + ex.Message);
                throw;
            }
        }

        private void Log(string message)
        {
            string logMessage = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] " + message;

            if (OnLog != null)
                OnLog(logMessage);
        }

        private string FormatSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double size = bytes;

            while (size >= 1024 && order < sizes.Length - 1)
            {
                order++;
                size /= 1024;
            }

            return string.Format("{0:0.##} {1}", size, sizes[order]);
        }

        public void Stop()
        {
            isRunning = false;

            lock (lockObject)
            {
                foreach (var client in activeClients)
                {
                    try { client.Close(); } catch { }
                }
                activeClients.Clear();
            }

            try
            {
                listener.Stop();
                Log("打印服务器已停止");
            }
            catch { }
        }
    }

    public static class NetworkHelper
    {
        public static List<string> GetAllNetworkAddresses()
        {
            List<string> addresses = new List<string>();

            try
            {
                string hostName = Dns.GetHostName();
                IPHostEntry hostEntry = Dns.GetHostEntry(hostName);

                foreach (IPAddress ip in hostEntry.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        addresses.Add(ip.ToString());
                    }
                }
            }
            catch
            {
                addresses.Add("127.0.0.1");
            }

            return addresses;
        }

        public static string GetHostName(string ipAddress)
        {
            try
            {
                IPHostEntry entry = Dns.GetHostEntry(ipAddress);
                return entry.HostName;
            }
            catch
            {
                return ipAddress;
            }
        }

        public static bool ResolveHostName(string hostName, out List<string> ipAddresses)
        {
            ipAddresses = new List<string>();

            try
            {
                IPHostEntry entry = Dns.GetHostEntry(hostName);

                foreach (IPAddress ip in entry.AddressList)
                {
                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                    {
                        ipAddresses.Add(ip.ToString());
                    }
                }

                return ipAddresses.Count > 0;
            }
            catch
            {
                return false;
            }
        }
    }

    /// <summary>
    /// 打印机配置
    /// </summary>
    public class PrinterConfig
    {
        public string Name { get; set; }
        public int Port { get; set; }
        public bool Enabled { get; set; }
        public int Index { get; set; }
    }

    public static class ConfigurationHelper
    {
        public static string GetSetting(string key, string defaultValue)
        {
            try
            {
                string value = System.Configuration.ConfigurationManager.AppSettings[key];
                return string.IsNullOrEmpty(value) ? defaultValue : value;
            }
            catch
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// 获取所有打印机配置列表
        /// PrinterCount=0 时回退到单打印机模式
        /// </summary>
        public static List<PrinterConfig> GetPrinterConfigs()
        {
            var configs = new List<PrinterConfig>();

            try
            {
                int count = 0;
                int.TryParse(GetSetting("PrinterCount", "0"), out count);

                if (count <= 0)
                {
                    // 兼容旧单打印机模式
                    string name = GetSetting("PrinterName", "");
                    if (!string.IsNullOrEmpty(name))
                    {
                        int port = 9100;
                        int.TryParse(GetSetting("Port", "9100"), out port);
                        configs.Add(new PrinterConfig
                        {
                            Name = name,
                            Port = port,
                            Enabled = true,
                            Index = 0
                        });
                    }
                }
                else
                {
                    // 多打印机模式
                    for (int i = 0; i < count; i++)
                    {
                        string name = GetSetting("Printer" + i + "_Name", "");
                        if (string.IsNullOrEmpty(name))
                            continue;

                        string enabledStr = GetSetting("Printer" + i + "_Enabled", "false");
                        bool enabled = enabledStr.ToLower() == "true" || enabledStr == "1";

                        if (!enabled)
                            continue;

                        int port = 9100 + i;
                        int.TryParse(GetSetting("Printer" + i + "_Port", (9100 + i).ToString()), out port);

                        configs.Add(new PrinterConfig
                        {
                            Name = name,
                            Port = port,
                            Enabled = true,
                            Index = i
                        });
                    }
                }
            }
            catch { }

            return configs;
        }
    }

    public static class RawPrinterHelper
    {
        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool OpenPrinter(string pPrinterName, out IntPtr phPrinter, IntPtr pDefault);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool ClosePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool StartDocPrinter(IntPtr hPrinter, int Level, [In] ref DOC_INFO_1 pDocInfo);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool EndDocPrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool StartPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool EndPagePrinter(IntPtr hPrinter);

        [DllImport("winspool.Drv", SetLastError = true)]
        private static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);

        [StructLayout(LayoutKind.Sequential)]
        private struct DOC_INFO_1
        {
            public string pDocName;
            public string pOutputFile;
            public string pDataType;
        }

        public static bool SendBytesToPrinter(string printerName, byte[] bytes)
        {
            IntPtr hPrinter = IntPtr.Zero;
            DOC_INFO_1 docInfo = new DOC_INFO_1
            {
                pDocName = "网络打印作业",
                pOutputFile = null,
                pDataType = "RAW"
            };

            try
            {
                if (!OpenPrinter(printerName, out hPrinter, IntPtr.Zero))
                    return false;

                if (!StartDocPrinter(hPrinter, 1, ref docInfo))
                    return false;

                if (!StartPagePrinter(hPrinter))
                {
                    EndDocPrinter(hPrinter);
                    return false;
                }

                int bytesWritten;
                IntPtr pBytes = Marshal.AllocHGlobal(bytes.Length);
                Marshal.Copy(bytes, 0, pBytes, bytes.Length);

                bool result = WritePrinter(hPrinter, pBytes, bytes.Length, out bytesWritten);

                Marshal.FreeHGlobal(pBytes);

                EndPagePrinter(hPrinter);
                EndDocPrinter(hPrinter);

                return result;
            }
            catch
            {
                return false;
            }
            finally
            {
                if (hPrinter != IntPtr.Zero)
                    ClosePrinter(hPrinter);
            }
        }
    }
}
