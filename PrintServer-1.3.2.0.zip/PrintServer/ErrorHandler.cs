using System;

namespace PrintServer
{
    /// <summary>
    /// 统一错误处理辅助类
    /// 提供标准化的异常日志记录和安全的代码执行包装
    /// </summary>
    public static class ErrorHandler
    {
        /// <summary>
        /// 安全执行 Action，自动捕获异常并记录日志
        /// </summary>
        /// <param name="action">要执行的代码</param>
        /// <param name="context">上下文描述（如方法名）</param>
        /// <returns>是否执行成功</returns>
        public static bool SafeExecute(Action action, string context)
        {
            try
            {
                action();
                return true;
            }
            catch (Exception ex)
            {
                LogException(ex, context);
                return false;
            }
        }

        /// <summary>
        /// 安全执行 Func，自动捕获异常并记录日志
        /// </summary>
        /// <typeparam name="T">返回值类型</typeparam>
        /// <param name="func">要执行的函数</param>
        /// <param name="context">上下文描述</param>
        /// <param name="defaultValue">出错时的默认返回值</param>
        /// <returns>执行结果或默认值</returns>
        public static T SafeExecute<T>(Func<T> func, string context, T defaultValue)
        {
            try
            {
                return func();
            }
            catch (Exception ex)
            {
                LogException(ex, context);
                return defaultValue;
            }
        }

        /// <summary>
        /// 安全执行 Func（使用默认值）
        /// </summary>
        public static T SafeExecute<T>(Func<T> func, string context)
        {
            return SafeExecute(func, context, default(T));
        }

        /// <summary>
        /// 记录异常到统一日志
        /// </summary>
        /// <param name="ex">异常对象</param>
        /// <param name="context">上下文描述</param>
        public static void LogException(Exception ex, string context)
        {
            string message = string.Format(
                "[错误] 上下文: {0} | 类型: {1} | 消息: {2} | 堆栈: {3}",
                context,
                ex.GetType().Name,
                ex.Message,
                ex.StackTrace ?? "(无堆栈)"
            );
            LogHelper.WriteLog(message);
        }

        /// <summary>
        /// 格式化异常信息用于显示
        /// </summary>
        /// <param name="ex">异常对象</param>
        /// <returns>用户友好的错误消息</returns>
        public static string GetUserFriendlyMessage(Exception ex)
        {
            if (ex is System.Net.Sockets.SocketException)
                return "网络连接失败，请检查网络设置";
            if (ex is System.Net.Http.HttpRequestException)
                return "HTTP 请求失败，请检查服务器地址和端口";
            if (ex is System.Net.WebException)
                return "网络请求超时，请检查网络连接";
            if (ex is System.UnauthorizedAccessException)
                return "权限不足，请以管理员身份运行";
            if (ex is System.IO.IOException)
                return "文件读写失败: " + ex.Message;
            if (ex is System.TimeoutException)
                return "操作超时，请重试";
            return ex.Message;
        }
    }
}
