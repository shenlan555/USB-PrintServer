using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;

namespace PrintServer
{
    /// <summary>
    /// 内置 HTTP API 服务
    /// 为客户端提供打印机列表查询和驱动文件下载
    /// 支持多打印机模式
    /// </summary>
    public class HttpApiService
    {
        private HttpListener _listener;
        private Thread _listenThread;
        private bool _isRunning;
        private readonly List<PrinterConfig> _printers;
        private readonly int _port;

        public event Action<string> OnLog;
        public bool IsRunning { get { return _isRunning; } }

        /// <summary>
        /// 多打印机模式构造函数
        /// </summary>
        public HttpApiService(List<PrinterConfig> printers, int port = 9180)
        {
            _printers = printers ?? new List<PrinterConfig>();
            _port = port;
        }

        public void Start()
        {
            try
            {
                _listener = new HttpListener();
                _listener.Prefixes.Add(string.Format("http://+:{0}/", _port));
                _listener.Start();
                _isRunning = true;

                _listenThread = new Thread(ListenLoop);
                _listenThread.IsBackground = true;
                _listenThread.Start();

                Log("HTTP API 服务已启动，端口: " + _port);
            }
            catch (Exception ex)
            {
                Log("HTTP API 启动失败: " + ex.Message);
                // 尝试仅监听 localhost
                try
                {
                    _listener = new HttpListener();
                    _listener.Prefixes.Add(string.Format("http://localhost:{0}/", _port));
                    _listener.Prefixes.Add(string.Format("http://127.0.0.1:{0}/", _port));
                    _listener.Start();
                    _isRunning = true;
                    _listenThread = new Thread(ListenLoop);
                    _listenThread.IsBackground = true;
                    _listenThread.Start();
                    Log("HTTP API 已降级启动（仅本机），端口: " + _port);
                }
                catch (Exception ex2)
                {
                    Log("HTTP API 降级启动也失败: " + ex2.Message);
                    _isRunning = false;
                }
            }
        }

        public void Stop()
        {
            _isRunning = false;
            try
            {
                if (_listener != null)
                {
                    _listener.Stop();
                    _listener.Close();
                }
            }
            catch { }
            Log("HTTP API 服务已停止");
        }

        private void ListenLoop()
        {
            while (_isRunning)
            {
                try
                {
                    var context = _listener.GetContext();
                    ThreadPool.QueueUserWorkItem(HandleRequest, context);
                }
                catch (HttpListenerException)
                {
                    if (_isRunning)
                        Log("HTTP 监听异常");
                }
                catch (Exception ex)
                {
                    if (_isRunning)
                        Log("HTTP 处理异常: " + ex.Message);
                }
            }
        }

        private void HandleRequest(object state)
        {
            var context = (HttpListenerContext)state;
            var request = context.Request;
            var response = context.Response;

            try
            {
                string path = request.Url.AbsolutePath.ToLowerInvariant();
                string clientIp = "未知";
                if (request.RemoteEndPoint != null && request.RemoteEndPoint.Address != null)
                    clientIp = request.RemoteEndPoint.Address.ToString();

                Log(string.Format("API请求: {0} {1} 来自 {2}", request.HttpMethod, path, clientIp));

                // 添加 CORS 头
                response.AddHeader("Access-Control-Allow-Origin", "*");
                response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

                if (request.HttpMethod == "OPTIONS")
                {
                    response.StatusCode = 200;
                    response.Close();
                    return;
                }

                switch (path)
                {
                    case "/api/info":
                        HandleInfoRequest(context);
                        break;
                    case "/api/driver":
                        HandleDriverRequest(context);
                        break;
                    case "/api/test":
                        HandleTestRequest(context);
                        break;
                    default:
                        SendJsonResponse(response, 404, new { error = "未知的API端点", path = path });
                        break;
                }
            }
            catch (Exception ex)
            {
                try
                {
                    SendJsonResponse(response, 500, new { error = "服务器内部错误: " + ex.Message });
                }
                catch { }
            }
            finally
            {
                try { response.Close(); } catch { }
            }
        }

        /// <summary>
        /// GET /api/info - 返回所有打印机列表
        /// 兼容旧版单打印机格式：顶层包含 printer 字段
        /// 新版多打印机格式：顶层包含 printers 数组
        /// </summary>
        private void HandleInfoRequest(HttpListenerContext context)
        {
            var response = context.Response;

            try
            {
                var printerList = new List<object>();
                foreach (var cfg in _printers)
                {
                    var driverInfo = DriverPackager.GetPrinterDriverInfo(cfg.Name);
                    printerList.Add(new
                    {
                        index = cfg.Index,
                        name = cfg.Name,
                        port = cfg.Port,
                        driverName = driverInfo.DriverName,
                        driverVersion = driverInfo.DriverVersion,
                        driverDate = driverInfo.DriverDate,
                        manufacturer = driverInfo.Manufacturer,
                        hasDriver = driverInfo.HasDriverFiles,
                        driverFileCount = driverInfo.DriverFileCount,
                        driverSizeBytes = driverInfo.DriverPackageSize,
                        driverSizeFormatted = FormatSize(driverInfo.DriverPackageSize)
                    });
                }

                // 获取第一台打印机信息用于兼容旧客户端
                var firstDriver = (printerList.Count > 0)
                    ? DriverPackager.GetPrinterDriverInfo(_printers[0].Name)
                    : null;
                var firstPrinter = (printerList.Count > 0) ? _printers[0] : null;

                var info = new
                {
                    server = new
                    {
                        hostname = Environment.MachineName,
                        version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                        apiPort = _port,
                        printerCount = _printers.Count
                    },
                    // 兼容旧版：第一台打印机信息
                    printer = (firstPrinter != null && firstDriver != null) ? new
                    {
                        name = firstPrinter.Name,
                        tcpPort = firstPrinter.Port,
                        driverName = firstDriver.DriverName,
                        driverVersion = firstDriver.DriverVersion,
                        driverDate = firstDriver.DriverDate,
                        manufacturer = firstDriver.Manufacturer,
                        hasDriver = firstDriver.HasDriverFiles,
                        driverFileCount = firstDriver.DriverFileCount,
                        driverSizeBytes = firstDriver.DriverPackageSize,
                        driverSizeFormatted = FormatSize(firstDriver.DriverPackageSize)
                    } : null,
                    // 新版：所有打印机列表
                    printers = printerList
                };

                SendJsonResponse(response, 200, info);
            }
            catch (Exception ex)
            {
                SendJsonResponse(response, 500, new { error = "获取打印机信息失败: " + ex.Message });
            }
        }

        /// <summary>
        /// GET /api/driver?id=N - 下载指定打印机的驱动包（ZIP）
        /// 不带 id 参数时下载第一台打印机驱动（兼容旧客户端）
        /// </summary>
        private void HandleDriverRequest(HttpListenerContext context)
        {
            var response = context.Response;

            try
            {
                // 获取打印机索引
                int printerIndex = 0;
                string idParam = context.Request.QueryString["id"];
                if (!string.IsNullOrEmpty(idParam))
                {
                    int.TryParse(idParam, out printerIndex);
                }

                if (_printers.Count == 0)
                {
                    SendJsonResponse(response, 404, new { error = "没有可用的打印机" });
                    return;
                }

                // 限幅
                if (printerIndex < 0 || printerIndex >= _printers.Count)
                    printerIndex = 0;

                string printerName = _printers[printerIndex].Name;
                byte[] zipData = DriverPackager.PackageDriverFiles(printerName);

                if (zipData == null || zipData.Length == 0)
                {
                    SendJsonResponse(response, 404, new { error = "无法获取打印机驱动文件: " + printerName });
                    return;
                }

                response.StatusCode = 200;
                response.ContentType = "application/zip";
                response.ContentLength64 = zipData.Length;
                response.AddHeader("Content-Disposition",
                    string.Format("attachment; filename=\"{0}_driver.zip\"",
                        SanitizeFileName(printerName)));

                response.OutputStream.Write(zipData, 0, zipData.Length);
                response.OutputStream.Flush();

                Log(string.Format("驱动下载: {0} ({1})", printerName, FormatSize(zipData.Length)));
            }
            catch (Exception ex)
            {
                SendJsonResponse(response, 500, new { error = "打包驱动失败: " + ex.Message });
            }
        }

        /// <summary>
        /// GET /api/test - 测试连接
        /// </summary>
        private void HandleTestRequest(HttpListenerContext context)
        {
            var printerNames = new List<string>();
            foreach (var cfg in _printers)
                printerNames.Add(cfg.Name);

            SendJsonResponse(context.Response, 200, new
            {
                status = "ok",
                serverTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"),
                printerCount = _printers.Count,
                printerNames = printerNames
            });
        }

        private void SendJsonResponse(HttpListenerResponse response, int statusCode, object data)
        {
            response.StatusCode = statusCode;
            response.ContentType = "application/json; charset=utf-8";

            string json;
            try
            {
                json = new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(data);
            }
            catch
            {
                json = "{}";
            }

            byte[] bytes = Encoding.UTF8.GetBytes(json);
            response.ContentLength64 = bytes.Length;
            response.OutputStream.Write(bytes, 0, bytes.Length);
            response.OutputStream.Flush();
        }

        private string SanitizeFileName(string name)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                name = name.Replace(c, '_');
            return name;
        }

        private string FormatSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double size = bytes;
            while (size >= 1024 && order < sizes.Length - 1)
            {
                order++;
                size /= 1024;
            }
            return string.Format("{0:0.##} {1}", size, sizes[order]);
        }

        private void Log(string message)
        {
            string logMsg = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] [HTTP-API] " + message;
            if (OnLog != null)
                OnLog(logMsg);
        }
    }
}
