using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Management;
using System.Text;

namespace PrintServer
{
    /// <summary>
    /// 打印机驱动打包器
    /// 查找打印机驱动文件，打包为 ZIP 供客户端下载
    /// </summary>
    public class DriverPackager
    {
        /// <summary>
        /// 打印机驱动信息
        /// </summary>
        public class PrinterDriverInfo
        {
            public string DriverName { get; set; }
            public string DriverVersion { get; set; }
            public string DriverDate { get; set; }
            public string Manufacturer { get; set; }
            public string InfPath { get; set; }
            public string DriverStorePath { get; set; }
            public bool HasDriverFiles { get; set; }
            public int DriverFileCount { get; set; }
            public long DriverPackageSize { get; set; }
            public List<string> DriverFiles { get; set; }

            public PrinterDriverInfo()
            {
                DriverName = "";
                DriverVersion = "";
                DriverDate = "";
                Manufacturer = "";
                InfPath = "";
                DriverStorePath = "";
                DriverFiles = new List<string>();
            }
        }

        /// <summary>
        /// 获取打印机驱动信息
        /// </summary>
        public static PrinterDriverInfo GetPrinterDriverInfo(string printerName)
        {
            var info = new PrinterDriverInfo();

            try
            {
                // 通过 WMI 获取打印机信息
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_Printer WHERE Name = '" + printerName.Replace("'", "''") + "'"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        info.DriverName = (obj["DriverName"] != null) ? obj["DriverName"].ToString() : "";
                        break;
                    }
                }

                if (string.IsNullOrEmpty(info.DriverName))
                {
                    // 回退：直接使用打印机名称
                    info.DriverName = printerName;
                }

                // 通过 WMI 获取驱动详细信息
                using (var searcher = new ManagementObjectSearcher(
                    "SELECT * FROM Win32_PrinterDriver WHERE Name = '" + info.DriverName.Replace("'", "''") + "'"))
                {
                    foreach (var obj in searcher.Get())
                    {
                        info.DriverVersion = (obj["DriverVersion"] != null) ? obj["DriverVersion"].ToString() : "";
                        info.DriverDate = (obj["DriverDate"] != null) ? obj["DriverDate"].ToString() : "";
                        info.Manufacturer = (obj["ManufacturerName"] != null) ? obj["ManufacturerName"].ToString() : "";
                        info.InfPath = (obj["InfName"] != null) ? obj["InfName"].ToString() : "";
                        break;
                    }
                }

                // 查找驱动文件
                info.DriverFiles = FindDriverFiles(info.DriverName, info.InfPath);
                info.DriverFileCount = info.DriverFiles.Count;
                info.HasDriverFiles = info.DriverFileCount > 0;

                // 计算打包大小
                if (info.HasDriverFiles)
                {
                    long totalSize = 0;
                    foreach (string file in info.DriverFiles)
                    {
                        try
                        {
                            totalSize += new FileInfo(file).Length;
                        }
                        catch { }
                    }
                    info.DriverPackageSize = totalSize;
                }
            }
            catch (Exception)
            {
                // 出错时返回基本信息
                info.DriverName = printerName;
                info.HasDriverFiles = false;
            }

            return info;
        }

        /// <summary>
        /// 查找打印机驱动所依赖的所有文件
        /// </summary>
        private static List<string> FindDriverFiles(string driverName, string infPath)
        {
            var files = new List<string>();
            var foundFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var searchedKeys = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            try
            {
                string windowsDir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                string system32 = Path.Combine(windowsDir, "System32");
                string spoolDrivers = Path.Combine(system32, "spool", "drivers", "x64");
                string driverStore = Path.Combine(system32, "DriverStore", "FileRepository");

                // 方法1：遍历注册表的 Version-3 和 Version-4
                string[] driverVersions = { "Version-3", "Version-4" };
                string baseRegPath = @"SYSTEM\CurrentControlSet\Control\Print\Environments\Windows x64\Drivers\";

                foreach (string ver in driverVersions)
                {
                    string regPath = baseRegPath + ver;
                    using (var verKey = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(regPath))
                    {
                        if (verKey == null) continue;

                        foreach (string subKeyName in verKey.GetSubKeyNames())
                        {
                            if (!searchedKeys.Add(subKeyName)) continue;

                            // 匹配：子键名包含 driverName 或 driverName 包含子键名
                            bool match = subKeyName.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                         driverName.IndexOf(subKeyName, StringComparison.OrdinalIgnoreCase) >= 0;
                            if (!match) continue;

                            using (var driverKey = verKey.OpenSubKey(subKeyName))
                            {
                                if (driverKey == null) continue;

                                // 读取核心驱动文件路径
                                string[] valueNames = { "DriverFile", "DataFile", "ConfigFile", "HelpFile" };
                                foreach (string valName in valueNames)
                                {
                                    string val = driverKey.GetValue(valName) as string;
                                    if (!string.IsNullOrEmpty(val))
                                    {
                                        AddFile(files, foundFiles, val);
                                    }
                                }

                                // 读取 DependantFiles（多字符串）
                                var dependantFiles = driverKey.GetValue("DependantFiles") as string[];
                                if (dependantFiles != null)
                                {
                                    foreach (string depFile in dependantFiles)
                                    {
                                        if (!string.IsNullOrEmpty(depFile))
                                            AddFile(files, foundFiles, depFile);
                                    }
                                }

                                // 也检查 HelpFile 等值名
                                string helpFile = driverKey.GetValue("HelpFile") as string;
                                if (!string.IsNullOrEmpty(helpFile))
                                    AddFile(files, foundFiles, helpFile);
                            }
                        }
                    }
                }

                // 方法2：直接扫描 spool\drivers\x64 目录（最可靠）
                if (Directory.Exists(spoolDrivers))
                {
                    // 在 3 和 PCC 子目录中查找与驱动名匹配的文件
                    foreach (string subDir in Directory.GetDirectories(spoolDrivers))
                    {
                        string subDirName = Path.GetFileName(subDir);
                        // 子目录名通常是驱动版本号如 "3" 或 "PCC"
                        foreach (string file in Directory.GetFiles(subDir, "*.*"))
                        {
                            string fileName = Path.GetFileNameWithoutExtension(file);
                            // 检查文件名是否与驱动相关
                            if (fileName.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                driverName.IndexOf(fileName, StringComparison.OrdinalIgnoreCase) >= 0 ||
                                IsDriverRelatedFile(file, driverName))
                            {
                                AddFile(files, foundFiles, file);
                            }
                        }

                        // 如果子目录中有子目录，也扫描
                        foreach (string file in Directory.GetFiles(subDir, "*.*", SearchOption.AllDirectories))
                        {
                            string fileName = Path.GetFileNameWithoutExtension(file);
                            if (fileName.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0)
                                AddFile(files, foundFiles, file);
                        }
                    }

                    // 如果上面方法没找到，获取所有 DLL 文件（驱动核心文件都在这里）
                    if (files.Count == 0)
                    {
                        foreach (string subDir in Directory.GetDirectories(spoolDrivers))
                        {
                            foreach (string file in Directory.GetFiles(subDir, "*.dll"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.ppd"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.gpd"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.dat"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.ini"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.cat"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                            foreach (string file in Directory.GetFiles(subDir, "*.inf"))
                            {
                                AddFile(files, foundFiles, file);
                            }
                        }
                    }
                }

                // 方法3：通过 INF 文件查找
                if (!string.IsNullOrEmpty(infPath))
                {
                    string systemInf = Path.Combine(windowsDir, "INF", infPath);
                    if (File.Exists(systemInf))
                    {
                        AddFile(files, foundFiles, systemInf);
                    }
                }

                // 方法4：DriverStore 中搜索
                if (Directory.Exists(driverStore))
                {
                    foreach (string dir in Directory.GetDirectories(driverStore))
                    {
                        string dirName = Path.GetFileName(dir);
                        if (dirName.StartsWith(driverName, StringComparison.OrdinalIgnoreCase) ||
                            dirName.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            foreach (string file in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories))
                            {
                                AddFile(files, foundFiles, file);
                            }
                        }
                    }
                }

                // 方法5：WMI Win32_PrinterDriver 获取 DependentFiles
                try
                {
                    string escapedName = driverName.Replace("\\", "\\\\").Replace("'", "''");
                    string wmiQuery = "SELECT * FROM Win32_PrinterDriver WHERE Name LIKE '%" + escapedName + "%'";
                    using (var searcher = new ManagementObjectSearcher(wmiQuery))
                    {
                        foreach (var obj in searcher.Get())
                        {
                            var dependentFiles = obj["DependentFiles"] as string[];
                            if (dependentFiles != null)
                            {
                                foreach (string depFile in dependentFiles)
                                {
                                    if (!string.IsNullOrEmpty(depFile))
                                        AddFile(files, foundFiles, depFile);
                                }
                            }

                            // 也读取单个文件属性
                            string driverPath = (obj["DriverPath"] != null) ? obj["DriverPath"].ToString() : "";
                            string dataFile = (obj["DataFile"] != null) ? obj["DataFile"].ToString() : "";
                            string configFile = (obj["ConfigFile"] != null) ? obj["ConfigFile"].ToString() : "";

                            if (!string.IsNullOrEmpty(driverPath)) AddFile(files, foundFiles, driverPath);
                            if (!string.IsNullOrEmpty(dataFile)) AddFile(files, foundFiles, dataFile);
                            if (!string.IsNullOrEmpty(configFile)) AddFile(files, foundFiles, configFile);
                        }
                    }
                }
                catch { }
            }
            catch (Exception)
            {
                // 发生异常时返回已找到的文件
            }

            return files;
        }

        /// <summary>
        /// 添加文件（去重 + 存在性检查）
        /// </summary>
        private static void AddFile(List<string> files, HashSet<string> foundFiles, string filePath)
        {
            try
            {
                if (string.IsNullOrEmpty(filePath)) return;

                // 处理可能的环境变量路径
                string normalized = filePath;
                if (!Path.IsPathRooted(filePath))
                {
                    // 尝试在 System32\spool\drivers\x64\ 下查找
                    string spoolPath = Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                        "System32", "spool", "drivers", "x64", "3", filePath);
                    if (File.Exists(spoolPath))
                        normalized = spoolPath;
                    else
                        return;
                }

                normalized = Path.GetFullPath(normalized);
                if (File.Exists(normalized) && foundFiles.Add(normalized))
                {
                    files.Add(normalized);
                }
            }
            catch { }
        }

        /// <summary>
        /// 判断文件是否与驱动相关（通过检查文件内容或名称匹配）
        /// </summary>
        private static bool IsDriverRelatedFile(string filePath, string driverName)
        {
            try
            {
                string content = File.ReadAllText(filePath, System.Text.Encoding.Unicode);
                return content.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 打包驱动文件为 ZIP
        /// </summary>
        public static byte[] PackageDriverFiles(string printerName)
        {
            string tempDir = null;
            try
            {
                // 方法1：从 DriverStore 查找并打包（文件不被 spooler 锁定）
                string windowsDir = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
                string driverStore = Path.Combine(windowsDir, "System32", "DriverStore", "FileRepository");

                // 先获取驱动名
                string driverName = printerName;
                try
                {
                    using (var searcher = new ManagementObjectSearcher(
                        "SELECT * FROM Win32_Printer WHERE Name = '" + printerName.Replace("'", "''") + "'"))
                    {
                        foreach (var obj in searcher.Get())
                        {
                            driverName = (obj["DriverName"] != null) ? obj["DriverName"].ToString() : printerName;
                            break;
                        }
                    }
                }
                catch { }

                // 在 DriverStore 中搜索匹配的驱动目录
                string matchedStoreDir = null;
                if (Directory.Exists(driverStore))
                {
                    foreach (string dir in Directory.GetDirectories(driverStore))
                    {
                        string dirName = Path.GetFileName(dir);
                        if (dirName.StartsWith(driverName, StringComparison.OrdinalIgnoreCase) ||
                            dirName.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0)
                        {
                            matchedStoreDir = dir;
                            break;
                        }
                    }

                    // 如果没精确匹配，搜索 INF 内容
                    if (matchedStoreDir == null)
                    {
                        foreach (string dir in Directory.GetDirectories(driverStore))
                        {
                            try
                            {
                                foreach (string infFile in Directory.GetFiles(dir, "*.inf", SearchOption.AllDirectories))
                                {
                                    string content = File.ReadAllText(infFile, Encoding.Unicode);
                                    if (content.IndexOf(driverName, StringComparison.OrdinalIgnoreCase) >= 0)
                                    {
                                        matchedStoreDir = dir;
                                        break;
                                    }
                                }
                            }
                            catch { }
                            if (matchedStoreDir != null) break;
                        }
                    }
                }

                // 如果找到 DriverStore 目录，直接打包
                if (matchedStoreDir != null)
                {
                    return ZipDirectory(matchedStoreDir);
                }

                // 方法2：从 spool drivers 目录收集文件
                string spoolDir = Path.Combine(windowsDir, "System32", "spool", "drivers", "x64");
                if (Directory.Exists(spoolDir))
                {
                    tempDir = Path.Combine(Path.GetTempPath(), "PrintServer_Driver_" + Guid.NewGuid().ToString("N").Substring(0, 8));
                    Directory.CreateDirectory(tempDir);

                    int copiedCount = CopyDriverFiles(spoolDir, tempDir);
                    copiedCount += CopyMatchingInfFiles(windowsDir, driverName, tempDir);

                    if (copiedCount > 0)
                    {
                        return ZipDirectory(tempDir);
                    }
                }

                // 方法3：回退到原有的 DriverFiles 列表
                var info = GetPrinterDriverInfo(printerName);
                if (info.HasDriverFiles && info.DriverFiles.Count > 0)
                {
                    if (tempDir == null)
                    {
                        tempDir = Path.Combine(Path.GetTempPath(), "PrintServer_Driver_" + Guid.NewGuid().ToString("N").Substring(0, 8));
                        Directory.CreateDirectory(tempDir);
                    }

                    int copiedCount = CopySpecificFiles(info.DriverFiles, tempDir);
                    copiedCount += CopyMatchingInfFiles(windowsDir, driverName, tempDir);

                    if (copiedCount > 0)
                    {
                        return ZipDirectory(tempDir);
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[DriverPackager] 打包失败: " + ex.Message);
                return null;
            }
            finally
            {
                if (tempDir != null)
                {
                    try { Directory.Delete(tempDir, true); } catch { }
                }
            }
        }

        /// <summary>
        /// 复制 spool drivers 目录下的驱动文件到临时目录
        /// </summary>
        private static int CopyDriverFiles(string spoolDir, string tempDir)
        {
            int copiedCount = 0;
            string[] validExts = { ".dll", ".ppd", ".gpd", ".inf", ".cat", ".dat",
                                   ".ini", ".xml", ".cab", ".mui", ".chm", ".hlp", ".sys" };

            foreach (string versionDir in Directory.GetDirectories(spoolDir))
            {
                foreach (string file in Directory.GetFiles(versionDir, "*.*", SearchOption.AllDirectories))
                {
                    try
                    {
                        string ext = Path.GetExtension(file).ToLowerInvariant();
                        bool isValid = false;
                        foreach (string ve in validExts)
                        {
                            if (ext == ve) { isValid = true; break; }
                        }
                        if (!isValid) continue;

                        string destFile = Path.Combine(tempDir, Path.GetFileName(file));
                        using (var src = new FileStream(file, FileMode.Open, FileAccess.Read,
                            FileShare.ReadWrite | FileShare.Delete))
                        {
                            using (var dst = new FileStream(destFile, FileMode.Create, FileAccess.Write))
                            {
                                src.CopyTo(dst);
                            }
                        }
                        copiedCount++;
                    }
                    catch { }
                }
            }
            return copiedCount;
        }

        /// <summary>
        /// 复制指定文件列表到临时目录
        /// </summary>
        private static int CopySpecificFiles(List<string> fileList, string tempDir)
        {
            int copiedCount = 0;
            foreach (string filePath in fileList)
            {
                try
                {
                    string destFile = Path.Combine(tempDir, Path.GetFileName(filePath));
                    using (var src = new FileStream(filePath, FileMode.Open, FileAccess.Read,
                        FileShare.ReadWrite | FileShare.Delete))
                    {
                        using (var dst = new FileStream(destFile, FileMode.Create, FileAccess.Write))
                        {
                            src.CopyTo(dst);
                        }
                    }
                    copiedCount++;
                }
                catch { }
            }
            return copiedCount;
        }

        /// <summary>
        /// 从 C:\Windows\INF\ 搜索匹配的 oem*.inf 文件并复制
        /// </summary>
        private static int CopyMatchingInfFiles(string windowsDir, string driverName, string tempDir)
        {
            int copiedCount = 0;
            try
            {
                string infDir = Path.Combine(windowsDir, "INF");
                if (!Directory.Exists(infDir))
                {
                    LogHelper.WriteLog("[DriverPackager] INF目录不存在: " + infDir);
                    return 0;
                }

                string[] oemFiles = Directory.GetFiles(infDir, "oem*.inf");
                LogHelper.WriteLog(string.Format("[DriverPackager] INF搜索: driverName='{0}', 共{1}个oem*.inf文件",
                    driverName, oemFiles.Length));

                // 准备搜索关键词：驱动名 + 拆分后的各部分
                var keywords = new List<string>();
                keywords.Add(driverName);

                // 拆分驱动名：Lenovo M7298W-00000 → Lenovo, M7298W, 00000, M7298W-00000
                string[] parts = driverName.Split(new char[] { ' ', '-', '_', ',' },
                    StringSplitOptions.RemoveEmptyEntries);
                foreach (string part in parts)
                {
                    if (part.Length >= 4)
                        keywords.Add(part);
                }
                // 也加入双词组合
                if (parts.Length >= 2)
                {
                    for (int i = 0; i < parts.Length - 1; i++)
                    {
                        keywords.Add(parts[i] + " " + parts[i + 1]);
                    }
                }

                LogHelper.WriteLog(string.Format("[DriverPackager] INF搜索关键词: {0}",
                    string.Join(", ", keywords.Distinct())));

                // 第一轮：精确匹配
                foreach (string infFile in oemFiles)
                {
                    try
                    {
                        string content = File.ReadAllText(infFile, Encoding.Unicode);
                        foreach (string keyword in keywords.Distinct())
                        {
                            if (content.IndexOf(keyword, StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                string destFile = Path.Combine(tempDir, Path.GetFileName(infFile));
                                File.Copy(infFile, destFile, true);
                                copiedCount++;
                                LogHelper.WriteLog("[DriverPackager] 匹配INF: " + Path.GetFileName(infFile) +
                                    " (关键词: " + keyword + ")");

                                // 同时复制 .PNF 预编译文件
                                string pnfFile = Path.ChangeExtension(infFile, ".PNF");
                                if (File.Exists(pnfFile))
                                {
                                    File.Copy(pnfFile, Path.Combine(tempDir, Path.GetFileName(pnfFile)), true);
                                }
                                break;
                            }
                        }
                    }
                    catch { }
                }

                // 第二轮：如果没找到，把最近修改的5个 oem*.inf 都复制（兜底）
                if (copiedCount == 0)
                {
                    LogHelper.WriteLog("[DriverPackager] 未找到精确匹配INF，使用兜底策略复制最近修改的INF");
                    var recentInfs = oemFiles
                        .Select(f => new { Path = f, Time = File.GetLastWriteTime(f) })
                        .OrderByDescending(x => x.Time)
                        .Take(5);

                    foreach (var inf in recentInfs)
                    {
                        try
                        {
                            string destFile = Path.Combine(tempDir, Path.GetFileName(inf.Path));
                            File.Copy(inf.Path, destFile, true);
                            copiedCount++;
                            LogHelper.WriteLog("[DriverPackager] 兜底INF: " + Path.GetFileName(inf.Path));
                        }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.WriteLog("[DriverPackager] INF搜索异常: " + ex.Message);
            }

            LogHelper.WriteLog(string.Format("[DriverPackager] INF搜索完成: 复制了{0}个INF文件", copiedCount));
            return copiedCount;
        }

        /// <summary>
        /// 将目录打包为 ZIP 字节数组
        /// </summary>
        private static byte[] ZipDirectory(string dirPath)
        {
            using (var ms = new MemoryStream())
            {
                using (var archive = new ZipArchive(ms, ZipArchiveMode.Create, true))
                {
                    foreach (string file in Directory.GetFiles(dirPath, "*.*", SearchOption.AllDirectories))
                    {
                        try
                        {
                            string entryName = file.Substring(dirPath.Length).TrimStart('\\', '/');
                            var entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
                            using (var entryStream = entry.Open())
                            using (var fileStream = new FileStream(file, FileMode.Open, FileAccess.Read,
                                FileShare.ReadWrite | FileShare.Delete))
                            {
                                fileStream.CopyTo(entryStream);
                            }
                        }
                        catch { }
                    }
                }

                return ms.ToArray();
            }
        }
    }
}
