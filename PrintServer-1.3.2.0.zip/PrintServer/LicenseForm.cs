using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace PrintServer
{
    /// <summary>
    /// 授权管理窗口
    /// 提供在线激活、离线激活、机器码显示、信息上报、检查授权功能
    /// 未授权/授权失效时强制显示，不提供任何服务
    /// </summary>
    public partial class LicenseForm : Form
    {
        private TabControl tabControl;
        private TabPage tabOnline;
        private TabPage tabOffline;
        private TextBox txtLicenseKey;
        private Button btnActivateOnline;
        private Label lblOnlineStatus;
        private Button btnSelectLicFile;
        private Button btnActivateOffline;
        private Label lblOfflineStatus;
        private TextBox txtMachineCode;
        private Button btnCopyMachineCode;
        private Button btnReportMachine;
        private Button btnCheckLicense;
        private Label lblReportStatus;
        private Label lblTitle;
        private Label lblSubtitle;

        private string _selectedLicFilePath = "";

        /// <summary>
        /// 缓存机器码，确保显示和复制的内容完全一致
        /// </summary>
        private string _cachedMachineCode = "";

        /// <summary>
        /// 标记外网授权服务器是否可达
        /// </summary>
        private bool _isServerReachable = false;

        public LicenseForm()
        {
            InitializeComponent();
            LoadMachineCode();
            CenterToScreen();
            TopMost = true;

            // 窗体加载时同步检测外网授权服务器是否可达
            // 如果可达，禁用离线激活，强制使用在线激活
            CheckServerReachability();
        }

        /// <summary>
        /// 同步检测外网授权服务器是否可达
        /// 如果可达，禁用离线激活选项卡
        /// 使用同步方式确保在用户操作前完成检测
        /// 使用与 LicenseHelper 相同的 HttpClient 和 POST 方式
        /// </summary>
        private void CheckServerReachability()
        {
            try
            {
                string serverUrl = CryptoHelper.DecodeLicenseUrl();
                if (!serverUrl.EndsWith("/"))
                    serverUrl += "/";

                // 使用与 LicenseHelper 相同的 HttpClient 和 POST 方式
                // 发送一个简单的 validate 请求到服务器
                // 这样能确保检测结果与实际的在线激活能力完全一致
                var data = new System.Collections.Generic.Dictionary<string, string>
                {
                    { "machine_code", _cachedMachineCode }
                };
                var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                string json = serializer.Serialize(data);
                var content = new System.Net.Http.StringContent(json, Encoding.UTF8, "application/json");
                
                // 使用 Task.Run 同步调用，与 LicenseHelper.HttpPost 方法一致
                var task = System.Threading.Tasks.Task.Run(async () =>
                {
                    using (var httpClient = new System.Net.Http.HttpClient())
                    {
                        httpClient.Timeout = TimeSpan.FromSeconds(5);
                        var response = await httpClient.PostAsync(serverUrl + "validate", content);
                        // 只要服务器有响应（无论 HTTP 状态码是什么），就说明服务器可达
                        return true;
                    }
                });

                _isServerReachable = task.Result;
            }
            catch
            {
                // 网络不可达，允许离线激活
                _isServerReachable = false;
            }

            if (_isServerReachable)
            {
                // 外网授权服务器可达，禁用离线激活
                tabOffline.Enabled = false;
                tabOffline.Text = "📄 离线激活 (不可用)";
                btnSelectLicFile.Enabled = false;
                btnActivateOffline.Enabled = false;
                lblOfflineStatus.Text = "⚠ 检测到外网授权服务器可达，请使用在线激活";
                lblOfflineStatus.ForeColor = System.Drawing.Color.Orange;

                // 如果当前在离线选项卡，切换到在线选项卡
                if (tabControl.SelectedTab == tabOffline)
                {
                    tabControl.SelectedTab = tabOnline;
                }
            }
        }

        private void InitializeComponent()
        {
            this.Text = "PrintServer 授权激活";
            this.Size = new Size(560, 510);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.White;
            this.ShowIcon = true;
            this.ShowInTaskbar = true;

            // 标题
            lblTitle = new Label
            {
                Text = "网络打印服务器",
                Font = new Font("微软雅黑", 18, FontStyle.Bold),
                ForeColor = Color.FromArgb(33, 150, 243),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 15),
                Size = new Size(545, 40)
            };

            // 副标题
            lblSubtitle = new Label
            {
                Text = "⚠ 本软件需要授权后才能使用",
                Font = new Font("微软雅黑", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(244, 67, 54),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 55),
                Size = new Size(545, 25)
            };

            // === 机器码区域（放在 Tab 上方，两个选项卡都能看到） ===
            Label lblMcLabel = new Label
            {
                Text = "本机机器码",
                Font = new Font("微软雅黑", 9, FontStyle.Bold),
                ForeColor = Color.FromArgb(33, 150, 243),
                Location = new Point(15, 88),
                Size = new Size(70, 18)
            };

            // 使用只读 TextBox 显示机器码，可以完整显示64位，且用户可手动选中复制
            txtMachineCode = new TextBox
            {
                Text = "",
                Font = new Font("Consolas", 11, FontStyle.Regular),
                ForeColor = Color.FromArgb(66, 66, 66),
                BackColor = Color.FromArgb(245, 245, 245),
                Location = new Point(15, 108),
                Size = new Size(525, 24),
                TextAlign = HorizontalAlignment.Center,
                ReadOnly = true,
                BorderStyle = BorderStyle.FixedSingle,
                TabStop = false
            };

            btnCopyMachineCode = new Button
            {
                Text = "复制机器码",
                Font = new Font("微软雅黑", 9, FontStyle.Bold),
                BackColor = Color.FromArgb(33, 150, 243),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(240, 138),
                Size = new Size(90, 26)
            };
            btnCopyMachineCode.FlatAppearance.BorderSize = 0;
            btnCopyMachineCode.Click += (s, e) =>
            {
                Clipboard.SetText(_cachedMachineCode);
                MessageBox.Show("机器码已复制到剪贴板", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            // Tab 控件 - 高度缩小给底部留空间
            tabControl = new TabControl
            {
                Location = new Point(15, 172),
                Size = new Size(525, 280),
                Font = new Font("微软雅黑", 10)
            };

            // === 在线激活选项卡（含上报 + 检查授权） ===
            tabOnline = new TabPage("🌐 在线激活");

            // --- 授权码激活部分 ---
            Label lblOnlineHint = new Label
            {
                Text = "① 输入管理员提供的授权码，点击激活",
                Font = new Font("微软雅黑", 9),
                ForeColor = Color.Gray,
                Location = new Point(20, 18),
                Size = new Size(460, 20)
            };

            Label lblKey = new Label
            {
                Text = "授权码:",
                Font = new Font("微软雅黑", 10),
                Location = new Point(20, 48),
                Size = new Size(70, 25)
            };

            txtLicenseKey = new TextBox
            {
                Font = new Font("Consolas", 14, FontStyle.Bold),
                Location = new Point(95, 45),
                Size = new Size(280, 32),
                Text = "",
                MaxLength = 64
            };

            btnActivateOnline = new Button
            {
                Text = "激  活",
                Font = new Font("微软雅黑", 10, FontStyle.Bold),
                BackColor = Color.FromArgb(33, 150, 243),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(385, 45),
                Size = new Size(100, 30)
            };
            btnActivateOnline.FlatAppearance.BorderSize = 0;
            btnActivateOnline.Click += BtnActivateOnline_Click;

            lblOnlineStatus = new Label
            {
                Text = "",
                Font = new Font("微软雅黑", 9),
                Location = new Point(20, 85),
                Size = new Size(475, 35)
            };

            // --- 上报 + 检查授权 ---
            Label lblOnlineHint2 = new Label
            {
                Text = "② 上报本机信息 → 管理员后台授权 → 检查激活",
                Font = new Font("微软雅黑", 9),
                ForeColor = Color.Gray,
                Location = new Point(20, 125),
                Size = new Size(480, 20)
            };

            btnReportMachine = new Button
            {
                Text = "📤 上报本机信息",
                Font = new Font("微软雅黑", 9, FontStyle.Bold),
                BackColor = Color.FromArgb(255, 152, 0),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(20, 150),
                Size = new Size(140, 30)
            };
            btnReportMachine.FlatAppearance.BorderSize = 0;
            btnReportMachine.Click += BtnReportMachine_Click;

            btnCheckLicense = new Button
            {
                Text = "🔍 检查授权",
                Font = new Font("微软雅黑", 9, FontStyle.Bold),
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(170, 150),
                Size = new Size(140, 30)
            };
            btnCheckLicense.FlatAppearance.BorderSize = 0;
            btnCheckLicense.Click += BtnCheckLicense_Click;

            lblReportStatus = new Label
            {
                Text = "",
                Font = new Font("微软雅黑", 8),
                ForeColor = Color.Gray,
                Location = new Point(20, 185),
                Size = new Size(475, 40)
            };

            tabOnline.Controls.AddRange(new Control[] {
                lblOnlineHint, lblKey, txtLicenseKey, btnActivateOnline, lblOnlineStatus,
                lblOnlineHint2, btnReportMachine, btnCheckLicense, lblReportStatus
            });

            // === 离线激活选项卡 ===
            tabOffline = new TabPage("📄 离线激活");

            Label lblOfflineHint = new Label
            {
                Text = "选择管理员提供的 .lic 授权文件导入激活",
                Font = new Font("微软雅黑", 9),
                ForeColor = Color.Gray,
                Location = new Point(20, 20),
                Size = new Size(460, 20)
            };

            btnSelectLicFile = new Button
            {
                Text = "选择 .lic 文件",
                Font = new Font("微软雅黑", 10),
                Location = new Point(20, 55),
                Size = new Size(130, 30)
            };
            btnSelectLicFile.Click += BtnSelectLicFile_Click;

            lblOfflineStatus = new Label
            {
                Text = "未选择文件",
                Font = new Font("微软雅黑", 9),
                ForeColor = Color.Gray,
                Location = new Point(160, 60),
                Size = new Size(320, 20)
            };

            btnActivateOffline = new Button
            {
                Text = "导入激活",
                Font = new Font("微软雅黑", 10, FontStyle.Bold),
                BackColor = Color.FromArgb(76, 175, 80),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Enabled = false,
                Location = new Point(20, 100),
                Size = new Size(130, 30)
            };
            btnActivateOffline.FlatAppearance.BorderSize = 0;
            btnActivateOffline.Click += BtnActivateOffline_Click;

            tabOffline.Controls.AddRange(new Control[] {
                lblOfflineHint, btnSelectLicFile, lblOfflineStatus, btnActivateOffline
            });

            tabControl.Controls.Add(tabOnline);
            tabControl.Controls.Add(tabOffline);

            // 控件添加到窗体（底部按钮已移除，全部放入在线选项卡）
            this.Controls.AddRange(new Control[] {
                lblTitle, lblSubtitle,
                lblMcLabel, txtMachineCode, btnCopyMachineCode,
                tabControl
            });

            // 关闭事件
            this.FormClosing += LicenseForm_FormClosing;
        }

        /// <summary>
        /// 加载并显示机器码（缓存值，确保显示和复制完全一致）
        /// </summary>
        private void LoadMachineCode()
        {
            try
            {
                _cachedMachineCode = MachineCodeHelper.GenerateMachineCode();
                txtMachineCode.Text = _cachedMachineCode;
            }
            catch
            {
                _cachedMachineCode = "获取失败";
                txtMachineCode.Text = "获取失败";
            }
        }

        /// <summary>
        /// 在线激活
        /// </summary>
        private async void BtnActivateOnline_Click(object sender, EventArgs e)
        {
            string licenseKey = txtLicenseKey.Text.Trim();
            if (string.IsNullOrEmpty(licenseKey))
            {
                lblOnlineStatus.Text = "❌ 请输入授权码";
                lblOnlineStatus.ForeColor = Color.Red;
                return;
            }

            btnActivateOnline.Enabled = false;
            btnActivateOnline.Text = "激活中...";
            lblOnlineStatus.Text = "⏳ 正在向授权服务器发送请求...";
            lblOnlineStatus.ForeColor = Color.Orange;

            try
            {
                var result = await System.Threading.Tasks.Task.Run(() =>
                    LicenseHelper.ActivateOnline(licenseKey));

                if (result.Success)
                {
                    lblOnlineStatus.Text = "✅ " + result.Message;
                    lblOnlineStatus.ForeColor = Color.Green;
                    btnActivateOnline.Text = "✓ 激活成功";

                    // 延迟后关闭窗口
                    System.Threading.Thread.Sleep(800);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    lblOnlineStatus.Text = "❌ " + result.Message;
                    lblOnlineStatus.ForeColor = Color.Red;
                    btnActivateOnline.Enabled = true;
                    btnActivateOnline.Text = "激  活";
                }
            }
            catch (Exception ex)
            {
                lblOnlineStatus.Text = "❌ 网络错误: " + ex.Message;
                lblOnlineStatus.ForeColor = Color.Red;
                btnActivateOnline.Enabled = true;
                btnActivateOnline.Text = "激  活";
            }
        }

        /// <summary>
        /// 选择 .lic 文件
        /// </summary>
        private void BtnSelectLicFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dialog = new OpenFileDialog())
            {
                dialog.Filter = "授权文件 (*.lic)|*.lic|所有文件 (*.*)|*.*";
                dialog.Title = "选择离线授权文件";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    _selectedLicFilePath = dialog.FileName;
                    lblOfflineStatus.Text = "已选择: " + Path.GetFileName(dialog.FileName);
                    lblOfflineStatus.ForeColor = Color.Green;
                    btnActivateOffline.Enabled = true;
                }
            }
        }

        /// <summary>
        /// 离线激活
        /// </summary>
        private async void BtnActivateOffline_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(_selectedLicFilePath) || !File.Exists(_selectedLicFilePath))
            {
                MessageBox.Show("请先选择有效的 .lic 授权文件", "提示",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            btnActivateOffline.Enabled = false;
            btnActivateOffline.Text = "导入中...";

            try
            {
                var result = await System.Threading.Tasks.Task.Run(() =>
                    LicenseHelper.ActivateOffline(_selectedLicFilePath));

                if (result.Success)
                {
                    lblOfflineStatus.Text = "✅ " + result.Message;
                    lblOfflineStatus.ForeColor = Color.Green;
                    btnActivateOffline.Text = "✓ 激活成功";

                    System.Threading.Thread.Sleep(800);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    MessageBox.Show(result.Message, "激活失败",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    lblOfflineStatus.Text = "❌ " + result.Message;
                    lblOfflineStatus.ForeColor = Color.Red;
                    btnActivateOffline.Enabled = true;
                    btnActivateOffline.Text = "导入激活";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("读取授权文件失败: " + ex.Message, "错误",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                btnActivateOffline.Enabled = true;
                btnActivateOffline.Text = "导入激活";
            }
        }

        /// <summary>
        /// 上报机器信息
        /// </summary>
        private async void BtnReportMachine_Click(object sender, EventArgs e)
        {
            btnReportMachine.Enabled = false;
            btnReportMachine.Text = "上报中...";
            lblReportStatus.Text = "⏳ 正在向授权服务器上报本机信息...";
            lblReportStatus.ForeColor = Color.Orange;

            try
            {
                bool success = await System.Threading.Tasks.Task.Run(() =>
                    LicenseHelper.ReportMachine());

                if (success)
                {
                    lblReportStatus.Text = "✅ 上报成功！管理员处理授权后，点击【检查授权】即可激活";
                    lblReportStatus.ForeColor = Color.Green;
                    btnReportMachine.Text = "✓ 已上报";
                }
                else
                {
                    lblReportStatus.Text = "❌ 上报失败，请检查网络连接后重试";
                    lblReportStatus.ForeColor = Color.Red;
                    btnReportMachine.Enabled = true;
                    btnReportMachine.Text = "📤 上报本机信息";
                }
            }
            catch
            {
                lblReportStatus.Text = "❌ 网络错误，请检查网络连接";
                lblReportStatus.ForeColor = Color.Red;
                btnReportMachine.Enabled = true;
                btnReportMachine.Text = "📤 上报本机信息";
            }
        }

        /// <summary>
        /// 检查授权按钮点击 - 联网验证授权状态
        /// </summary>
        private async void BtnCheckLicense_Click(object sender, EventArgs e)
        {
            btnCheckLicense.Enabled = false;
            btnCheckLicense.Text = "验证中...";
            lblReportStatus.Text = "⏳ 正在联网验证授权...";
            lblReportStatus.ForeColor = Color.Orange;

            try
            {
                bool valid = await System.Threading.Tasks.Task.Run(() =>
                    LicenseHelper.ManualCheck());

                if (valid)
                {
                    lblReportStatus.Text = "✅ 授权有效！即将进入程序...";
                    lblReportStatus.ForeColor = Color.Green;
                    btnCheckLicense.Text = "✓ 授权有效";

                    System.Threading.Thread.Sleep(800);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    var status = LicenseHelper.CurrentStatus;
                    if (status == LicenseHelper.LicenseStatus.NetworkError)
                    {
                        lblReportStatus.Text = "⚠ 网络异常，请稍后重试或使用离线激活";
                        lblReportStatus.ForeColor = Color.Orange;
                    }
                    else
                    {
                        lblReportStatus.Text = "❌ 未检测到有效授权，请联系管理员处理";
                        lblReportStatus.ForeColor = Color.Red;
                    }
                    btnCheckLicense.Enabled = true;
                    btnCheckLicense.Text = "🔍 检查授权";
                }
            }
            catch (Exception ex)
            {
                lblReportStatus.Text = "❌ 验证失败: " + ex.Message;
                lblReportStatus.ForeColor = Color.Red;
                btnCheckLicense.Enabled = true;
                btnCheckLicense.Text = "🔍 检查授权";
            }
        }

        /// <summary>
        /// 关闭窗口 → 退出程序（未授权状态下）
        /// </summary>
        private void LicenseForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (LicenseHelper.CurrentStatus != LicenseHelper.LicenseStatus.Licensed)
            {
                if (e.CloseReason == CloseReason.UserClosing)
                {
                    DialogResult result = MessageBox.Show(
                        "本软件需要授权才能使用，确定要退出吗？",
                        "退出确认",
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
            }
        }

        /// <summary>
        /// 检查授权状态（如果从外部调用发现授权已生效，可自动关闭）
        /// </summary>
        public void CheckAndClose()
        {
            if (LicenseHelper.CurrentStatus == LicenseHelper.LicenseStatus.Licensed)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }
    }
}
