using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// 有关程序集的常规信息通过以下
// 特性集控制。更改这些特性值可修改
// 与程序集关联的信息。
[assembly: AssemblyTitle("网络打印服务器")]
[assembly: AssemblyDescription("将本地打印机共享为网络打印机的服务程序")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("浪里个浪")]
[assembly: AssemblyProduct("网络打印服务器")]
[assembly: AssemblyCopyright("Copyright © 2026 挨踢日记")]

// 将 ComVisible 设置为 false 使此程序集中的类型
// 对 COM 组件不可见。如果需要从 COM 访问此程序集中的类型，
// 则将该类型上的 ComVisible 特性设置为 true。
[assembly: ComVisible(false)]

// 如果此项目向 COM 公开，则下列 GUID 用于类型库的 ID
[assembly: Guid("E1F2A3B4-C5D6-7890-ABCD-EF1234567890")]

// 程序集的版本信息由下面四个值组成:
//
//      主版本
//      次版本 
//      内部版本号
//      修订号
//
// 可以指定所有这些值，也可以使用"内部版本号"和"修订号"的默认值，
// 方法是按如下所示使用"*":
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.3.2.0")]
[assembly: AssemblyFileVersion("1.3.2.0")]

// 授权配置（编译时固定，不可通过配置文件修改）
// LicenseValidationInterval: 授权验证间隔（小时），默认3小时
[assembly: PrintServer.AssemblyLicenseValidationInterval(1)]

// 授权服务器 API 地址（编译时固定，不可通过配置文件修改）
[assembly: PrintServer.AssemblyLicenseUrl("https://ps.itlog.vip/api/ps/v1/")]

// 授权加密密钥（编译时固定，不可通过配置文件修改）
[assembly: PrintServer.AssemblySecretKey("mBnmlmCBkJuDmAOG6MhxLUUPJ3euL1CE5xT6Hf99zCbZMGPwzGKm5eBUcN4jBxJDBa2kgLscyqf0vdHK9H8gFzXIlJ2GfdE5kSAtyct8SEWUWUmBv5F3FmA2mTdOW4ej")]
