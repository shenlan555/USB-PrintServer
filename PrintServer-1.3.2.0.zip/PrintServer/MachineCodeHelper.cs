using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;

namespace PrintServer
{
    /// <summary>
    /// 硬件指纹采集类
    /// 采集 CPU、主板、系统盘、MAC 地址 → SHA256 机器码
    /// 排除 BIOS（BIOS 更新不影响授权）
    /// </summary>
    public static class MachineCodeHelper
    {
        /// <summary>
        /// 生成机器码（SHA256 硬件指纹）
        /// </summary>
        public static string GenerateMachineCode()
        {
            string cpuId = GetCpuId();
            if (cpuId == null) cpuId = "UNKNOWN_CPU";
            string boardSn = GetMotherboardSerial();
            if (boardSn == null) boardSn = "UNKNOWN_BOARD";
            string diskSn = GetSystemDiskSerial();
            if (diskSn == null) diskSn = "UNKNOWN_DISK";
            string mac = GetPhysicalMac();
            if (mac == null) mac = "UNKNOWN_MAC";

            string raw = (cpuId + boardSn + diskSn + mac).ToUpperInvariant();

            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(raw));
                return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
            }
        }

        /// <summary>
        /// 获取机器码摘要（前 16 位 + 后 16 位）
        /// </summary>
        public static string GetMachineCodeShort()
        {
            string code = GenerateMachineCode();
            if (code.Length >= 32)
                return code.Substring(0, 16) + "..." + code.Substring(code.Length - 16);
            return code;
        }

        /// <summary>
        /// 获取当前所有物理网卡的 MAC 地址列表（用于部分匹配验证）
        /// 只包含真正的物理网卡，排除虚拟网卡
        /// </summary>
        public static List<string> GetPhysicalMacList()
        {
            try
            {
                // 优先使用 WMI PhysicalAdapter 属性
                List<string> macList = GetPhysicalMacListFromWmi();
                if (macList != null && macList.Count > 0)
                    return macList;

                // 回退到 NetworkInterface API
                macList = GetPhysicalMacListFromNetInterface();
                if (macList != null && macList.Count > 0)
                    return macList;
            }
            catch
            {
            }
            return new List<string>();
        }

        /// <summary>
        /// 获取 CPU 序列号
        /// </summary>
        public static string GetCpuId()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT ProcessorId FROM Win32_Processor"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object val = obj["ProcessorId"];
                        string id = (val != null) ? val.ToString().Trim() : null;
                        if (!string.IsNullOrEmpty(id))
                            return id;
                    }
                }
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// 获取 CPU 型号名称
        /// </summary>
        public static string GetCpuName()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT Name FROM Win32_Processor"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object val = obj["Name"];
                        string name = (val != null) ? val.ToString().Trim() : null;
                        if (!string.IsNullOrEmpty(name))
                            return name;
                    }
                }
            }
            catch
            {
            }
            return "未知";
        }

        /// <summary>
        /// 获取主板序列号
        /// </summary>
        public static string GetMotherboardSerial()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT SerialNumber FROM Win32_BaseBoard"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object val = obj["SerialNumber"];
                        string sn = (val != null) ? val.ToString().Trim() : null;
                        if (!string.IsNullOrEmpty(sn) && sn != "To be filled by O.E.M.")
                            return sn;
                    }
                }
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// 获取主板型号
        /// </summary>
        public static string GetMotherboardModel()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT Product FROM Win32_BaseBoard"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object val = obj["Product"];
                        string model = (val != null) ? val.ToString().Trim() : null;
                        if (!string.IsNullOrEmpty(model))
                            return model;
                    }
                }
            }
            catch
            {
            }
            return "未知";
        }

        /// <summary>
        /// 获取系统盘序列号（Index=0 的磁盘）
        /// </summary>
        public static string GetSystemDiskSerial()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT SerialNumber, Index FROM Win32_DiskDrive"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object indexObj = obj["Index"];
                        string index = (indexObj != null) ? indexObj.ToString().Trim() : "";
                        if (index == "0")
                        {
                            object val = obj["SerialNumber"];
                            string sn = (val != null) ? val.ToString().Trim() : null;
                            if (!string.IsNullOrEmpty(sn))
                                return sn;
                        }
                    }
                }
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// 获取系统盘型号
        /// </summary>
        public static string GetSystemDiskModel()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT Model, Index FROM Win32_DiskDrive"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object indexObj = obj["Index"];
                        string index = (indexObj != null) ? indexObj.ToString().Trim() : "";
                        if (index == "0")
                        {
                            object val = obj["Model"];
                            string model = (val != null) ? val.ToString().Trim() : null;
                            if (!string.IsNullOrEmpty(model))
                                return model;
                        }
                    }
                }
            }
            catch
            {
            }
            return "未知";
        }

        /// <summary>
        /// 获取物理网卡 MAC 地址（所有物理网卡排序后拼接）
        /// 只采纳真正的物理网卡，排除虚拟网卡
        /// 
        /// 修复Bug：电脑启动后虚拟网卡（WSL、Hyper-V、Docker等）可能变化，
        /// 导致机器码变动，但物理网卡MAC从未改变。
        /// 
        /// 解决方案：
        /// 1. 使用 Win32_NetworkAdapter 的 PhysicalAdapter 属性（Windows 8+/Server 2012+）
        ///    只获取真正的物理网卡（有线+无线），排除所有虚拟网卡
        /// 2. 如果 PhysicalAdapter 属性不可用（旧系统），则回退到 NetworkInterface
        ///    的 NetworkInterfaceType 过滤 + 关键词排除虚拟网卡
        /// 3. 收集所有物理网卡的 MAC，排序后拼接为固定字符串
        ///    无论插不插网线、用有线还是无线，只要物理网卡没换，结果永远固定
        /// </summary>
        public static string GetPhysicalMac()
        {
            List<string> macList = GetPhysicalMacList();
            if (macList.Count > 0)
            {
                macList.Sort(StringComparer.Ordinal);
                return string.Join("-", macList);
            }
            return null;
        }

        /// <summary>
        /// 通过 WMI Win32_NetworkAdapter 获取物理网卡 MAC 列表
        /// 使用 PhysicalAdapter=True 过滤，只保留真正的物理网卡
        /// 额外通过 Name/Description 排除系统生成的网卡
        /// </summary>
        private static List<string> GetPhysicalMacListFromWmi()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT MACAddress, Name, Description, NetEnabled, PhysicalAdapter FROM Win32_NetworkAdapter"))
                {
                    List<string> macList = new List<string>();

                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object macObj = obj["MACAddress"];
                        string mac = (macObj != null) ? macObj.ToString().Trim() : null;

                        if (string.IsNullOrEmpty(mac))
                            continue;

                        object nameObj = obj["Name"];
                        string name = (nameObj != null) ? nameObj.ToString() : "";
                        object descObj = obj["Description"];
                        string desc = (descObj != null) ? descObj.ToString() : "";
                        string fullDesc = desc + " " + name;

                        // 检查 PhysicalAdapter 属性
                        // 注意：PhysicalAdapter 在 Windows 7 及以下可能为 null
                        object physicalObj = obj["PhysicalAdapter"];
                        bool isPhysical = false;
                        if (physicalObj != null)
                        {
                            isPhysical = Convert.ToBoolean(physicalObj);
                        }

                        // 如果不是物理网卡，跳过（排除 WSL、Hyper-V、Docker、VPN 等虚拟网卡）
                        if (!isPhysical)
                            continue;

                        // 额外排除系统生成的网卡（即使 PhysicalAdapter=True 也可能误判）
                        if (IsSystemGeneratedAdapter(fullDesc))
                            continue;

                        // 统一格式：去掉分隔符、大写
                        mac = mac.Replace("-", "").Replace(":", "").ToUpperInvariant();

                        // 收集所有物理网卡（无论是否启用）
                        // 因为物理网卡的 MAC 是硬件固化的，即使禁用也存在
                        if (!macList.Contains(mac))
                        {
                            macList.Add(mac);
                        }
                    }

                    return macList;
                }
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// 通过 NetworkInterface API 获取物理网卡 MAC 列表（回退方案）
        /// 只获取 Ethernet 类型且非虚拟/非系统生成的网卡
        /// </summary>
        private static List<string> GetPhysicalMacListFromNetInterface()
        {
            try
            {
                List<string> macList = new List<string>();

                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    // 只取 Ethernet 类型（排除无线、隧道、虚拟等）
                    if (ni.NetworkInterfaceType != NetworkInterfaceType.Ethernet)
                        continue;

                    string desc = ni.Description ?? "";

                    // 排除虚拟网卡
                    if (IsVirtualAdapter(desc))
                        continue;

                    // 排除系统生成的网卡
                    if (IsSystemGeneratedAdapter(desc))
                        continue;

                    PhysicalAddress address = ni.GetPhysicalAddress();
                    if (address == null)
                        continue;

                    string mac = address.ToString();
                    if (string.IsNullOrEmpty(mac))
                        continue;

                    mac = mac.ToUpperInvariant();

                    if (!macList.Contains(mac))
                    {
                        macList.Add(mac);
                    }
                }

                return macList;
            }
            catch
            {
            }
            return null;
        }

        /// <summary>
        /// 获取所有硬件信息（用于上报服务端）
        /// </summary>
        public static Dictionary<string, string> GetHardwareInfo()
        {
            var info = new Dictionary<string, string>
            {
                { "machine_code", GenerateMachineCode() },
                { "cpu_id", GetCpuId() ?? "" },
                { "cpu_name", GetCpuName() },
                { "motherboard_sn", GetMotherboardSerial() ?? "" },
                { "motherboard_model", GetMotherboardModel() },
                { "disk_sn", GetSystemDiskSerial() ?? "" },
                { "disk_model", GetSystemDiskModel() },
                { "mac_address", GetPhysicalMac() ?? "" },
                { "hostname", Environment.MachineName },
                { "os_version", GetOsVersion() },
                { "dotnet_version", GetDotNetVersion() }
            };
            return info;
        }

        /// <summary>
        /// 获取操作系统版本
        /// </summary>
        public static string GetOsVersion()
        {
            try
            {
                using (ManagementObjectSearcher searcher = new ManagementObjectSearcher(
                    "SELECT Caption, Version FROM Win32_OperatingSystem"))
                {
                    foreach (ManagementObject obj in searcher.Get())
                    {
                        object captionObj = obj["Caption"];
                        string caption = (captionObj != null) ? captionObj.ToString().Trim() : "";
                        object verObj = obj["Version"];
                        string ver = (verObj != null) ? verObj.ToString().Trim() : "";
                        return string.Format("{0} {1}", caption, ver).Trim();
                    }
                }
            }
            catch
            {
            }
            return Environment.OSVersion.ToString();
        }

        /// <summary>
        /// 获取 .NET 版本
        /// </summary>
        public static string GetDotNetVersion()
        {
            try
            {
                return Environment.Version.ToString();
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 判断是否为虚拟网卡
        /// </summary>
        private static bool IsVirtualAdapter(string description)
        {
            string lower = description.ToLowerInvariant();
            string[] virtualKeywords = {
                "virtual", "vmware", "virtualbox", "hyper-v", "hyperv",
                "vpn", "tap", "tun", "ndis", "pseudo", "loopback",
                "bluetooth", "wsl", "docker", "hamachi", "openvpn"
            };

            return virtualKeywords.Any(keyword => lower.Contains(keyword));
        }

        /// <summary>
        /// 判断是否为系统生成的网卡（非真正的物理网卡）
        /// 这些网卡虽然可能被标记为 PhysicalAdapter，但实际上是系统软件生成的
        /// </summary>
        private static bool IsSystemGeneratedAdapter(string description)
        {
            string lower = description.ToLowerInvariant();
            string[] systemKeywords = {
                "wi-fi direct", "wifi direct", "wireless direct",
                "teredo", "isatap", "6to4",
                "wan miniport", "wan mini-port",
                "kernel debug", "kdnic",
                "microsoft hosted network", "hosted network",
                "microsoft wi-fi", "microsoft wifi",
                "ras sync", "pppoe", "pptp", "l2tp", "sstp",
                "microsoft network adapter multiplexor",
                "microsoft hyper-v network", "hyper-v network",
                "bridge", "bridge port"
            };

            return systemKeywords.Any(keyword => lower.Contains(keyword));
        }
    }
}
