using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace PrintServer
{
    /// <summary>
    /// 授权核心逻辑类
    /// 管理授权状态、联网验证、本地缓存、定时校验
    /// </summary>
    public static class LicenseHelper
    {
        // 授权相关常量 - 保存到程序所在目录
        private static readonly string LicenseFileDir;

        private static readonly string LicenseFilePath;
        private static readonly string PendingReportFile;

        /// <summary>
        /// 静态构造函数：初始化授权文件路径到程序所在目录
        /// </summary>
        static LicenseHelper()
        {
            string exeDir = Path.GetDirectoryName(
                System.Reflection.Assembly.GetExecutingAssembly().Location);
            LicenseFileDir = exeDir;
            if (string.IsNullOrEmpty(LicenseFileDir))
                LicenseFileDir = ".";
            LicenseFilePath = Path.Combine(LicenseFileDir, "license.dat");
            PendingReportFile = Path.Combine(LicenseFileDir, ".pending_report");
        }

        // 授权服务器 URL（编译时硬编码，运行时不可修改）
        private static string _serverBaseUrl = "";

        // 状态
        private static LicenseStatus _currentStatus = LicenseStatus.Unknown;
        private static string _currentLicenseKey = "";
        private static string _machineCode = "";
        private static string _expiresAt = ""; // 授权过期时间
        private static System.Threading.Timer _validationTimer;
        private static bool _isChecking = false;

        // 共享 HttpClient（推荐单例模式）
        private static readonly HttpClient _httpClient = new HttpClient();

        /// <summary>
        /// 从 Assembly 属性读取加密密钥
        /// 与服务端 get_option('psl_secret_key', 'printserver-license-secret') 一致
        /// </summary>
        private static string GetDefaultSecretKey()
        {
            try
            {
                var assembly = System.Reflection.Assembly.GetExecutingAssembly();
                var attributes = assembly.GetCustomAttributes(typeof(AssemblySecretKeyAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var attr = (AssemblySecretKeyAttribute)attributes[0];
                    string key = attr.SecretKey;
                    if (!string.IsNullOrEmpty(key))
                        return key;
                }
            }
            catch
            {
            }
            return "printserver-license-secret"; // 默认值
        }

        /// <summary>
        /// 授权状态
        /// </summary>
        public enum LicenseStatus
        {
            Unknown,
            Licensed,
            Unlicensed,
            Expired,
            Disabled,
            NetworkError
        }

        /// <summary>
        /// 当前授权状态
        /// </summary>
        public static LicenseStatus CurrentStatus
        {
            get { return _currentStatus; }
            private set { _currentStatus = value; }
        }

        /// <summary>
        /// 当前授权码
        /// </summary>
        public static string CurrentLicenseKey
        {
            get { return _currentLicenseKey; }
            private set { _currentLicenseKey = value; }
        }

        /// <summary>
        /// 授权过期时间
        /// </summary>
        public static string LicenseExpiry
        {
            get { return _expiresAt; }
            private set { _expiresAt = value; }
        }

        /// <summary>
        /// 获取授权有效期文本
        /// </summary>
        public static string GetLicenseExpiryText()
        {
            if (string.IsNullOrEmpty(_expiresAt) || _expiresAt == "null" || _expiresAt == "")
                return "有效期: 永不过期";
            
            try
            {
                DateTime expireTime = DateTime.Parse(_expiresAt);
                if (expireTime < DateTime.Now)
                    return "⌛ 已过期: " + expireTime.ToString("yyyy-MM-dd HH:mm");
                else
                    return "有效期至: " + expireTime.ToString("yyyy-MM-dd HH:mm");
            }
            catch
            {
                return "有效期: " + _expiresAt;
            }
        }

        /// <summary>
        /// 获取是否永不过期
        /// </summary>
        public static bool IsExpiryNever
        {
            get { return string.IsNullOrEmpty(_expiresAt) || _expiresAt == "null" || _expiresAt == ""; }
        }

        /// <summary>
        /// 获取授权到期剩余天数
        /// </summary>
        public static int GetExpiryRemainingDays()
        {
            if (IsExpiryNever) return 9999;
            try
            {
                DateTime expireTime = DateTime.Parse(_expiresAt);
                return (int)(expireTime - DateTime.Now).TotalDays;
            }
            catch
            {
                return -1;
            }
        }

        /// <summary>
        /// 检查本地授权文件是否存在
        /// 修复Bug1：删除 license.dat 后必须重新激活
        /// </summary>
        public static bool HasLocalLicenseFile
        {
            get { return System.IO.File.Exists(LicenseFilePath); }
        }

        /// <summary>
        /// 强制重置授权状态为未授权（当本地 license.dat 被删除时调用）
        /// 使程序弹出 LicenseForm 要求重新激活
        /// </summary>
        public static void ForceLicenseReactivation()
        {
            _currentStatus = LicenseStatus.Unlicensed;
            _currentLicenseKey = "";
        }

        /// <summary>
        /// 本机机器码
        /// </summary>
        public static string MachineCode
        {
            get
            {
                if (string.IsNullOrEmpty(_machineCode))
                    _machineCode = MachineCodeHelper.GenerateMachineCode();
                return _machineCode;
            }
        }

        /// <summary>
        /// 授权状态变更事件
        /// </summary>
        public static event EventHandler<LicenseStatusEventArgs> StatusChanged;

        /// <summary>
        /// 初始化授权系统
        /// </summary>
        public static void Initialize()
        {
            try
            {
                Directory.CreateDirectory(LicenseFileDir);
            }
            catch
            {
            }

            // 配置 HttpClient
            _httpClient.Timeout = TimeSpan.FromSeconds(30);
            _httpClient.DefaultRequestHeaders.UserAgent.ParseAdd("PrintServer/" + Application.ProductVersion);

            // 从硬编码获取服务器 URL（编译后无法修改）
            _serverBaseUrl = CryptoHelper.DecodeLicenseUrl();
            if (!_serverBaseUrl.EndsWith("/"))
                _serverBaseUrl += "/";

            // 读取本地缓存
            LoadLocalLicense();
        }

        /// <summary>
        /// 从 Assembly 属性读取授权验证间隔（小时）
        /// 编译时固定，不可通过配置文件修改
        /// </summary>
        private static int GetLicenseValidationInterval()
        {
            try
            {
                var assembly = System.Reflection.Assembly.GetExecutingAssembly();
                var attributes = assembly.GetCustomAttributes(typeof(AssemblyLicenseValidationIntervalAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var attr = (AssemblyLicenseValidationIntervalAttribute)attributes[0];
                    int interval = attr.IntervalHours;
                    return interval < 1 ? 1 : interval;
                }
            }
            catch
            {
            }
            return 3; // 默认3小时
        }

        /// <summary>
        /// 启动授权验证（程序入口调用）
        /// 返回 true = 授权有效，false = 需要激活/授权失效
        /// </summary>
        public static bool StartValidation()
        {
            // 反调试检测点：授权验证入口
            // 如果检测到调试器，会触发惩罚（删除授权+注册表拉黑+上报服务端）
            AntiDebug.Checkpoint("StartValidation");

            // 第一次：强制联网校验
            bool valid = ValidateWithServerSync();

            // 启动定时校验（GUI 模式和服务模式都会执行到这里）
            StartValidationTimer();

            OnStatusChanged(valid ? LicenseStatus.Licensed : _currentStatus);
            return valid;
        }

        /// <summary>
        /// 启动定时校验
        /// 首次延迟 = intervalHours 小时，之后每 intervalHours 小时执行一次
        /// 如果网络失败，每 5 分钟重试一次，最多重试 12 次（1小时）
        /// </summary>
        private static void StartValidationTimer()
        {
            if (_validationTimer != null)
                return;

            int intervalHours = GetLicenseValidationInterval();
            if (intervalHours < 1) intervalHours = 1;

            _validationTimer = new System.Threading.Timer(
                OnValidationTimer,
                null,
                TimeSpan.FromHours(intervalHours),
                TimeSpan.FromHours(intervalHours)
            );
        }

        /// <summary>
        /// 停止定时校验
        /// </summary>
        public static void StopValidation()
        {
            if (_validationTimer != null)
            {
                _validationTimer.Dispose();
                _validationTimer = null;
            }
        }

        /// <summary>
        /// 手动检查授权（用户点击按钮）
        /// </summary>
        public static bool ManualCheck()
        {
            if (_isChecking) return false;
            
            _isChecking = true;
            try
            {
                bool valid = ValidateWithServerSync();
                OnStatusChanged(valid ? LicenseStatus.Licensed : _currentStatus);
                return valid;
            }
            finally
            {
                _isChecking = false;
            }
        }

        /// <summary>
        /// 在线激活（输入授权码）
        /// </summary>
        public static ActivationResult ActivateOnline(string licenseKey)
        {
            try
            {
                var hardwareInfo = MachineCodeHelper.GetHardwareInfo();

                var data = new Dictionary<string, string>
                {
                    { "license_key", licenseKey.Trim().ToUpperInvariant() },
                    { "machine_code", MachineCode },
                    { "hostname", Environment.MachineName },
                    { "os_version", MachineCodeHelper.GetOsVersion() },
                    { "dotnet_version", MachineCodeHelper.GetDotNetVersion() },
                    { "cpu_id", hardwareInfo["cpu_id"] },
                    { "cpu_name", hardwareInfo["cpu_name"] },
                    { "motherboard_sn", hardwareInfo["motherboard_sn"] },
                    { "motherboard_model", hardwareInfo["motherboard_model"] },
                    { "disk_sn", hardwareInfo["disk_sn"] },
                    { "disk_model", hardwareInfo["disk_model"] },
                    { "mac_address", hardwareInfo["mac_address"] },
                    { "app_version", Application.ProductVersion }
                };

                string json = BuildJson(data);
                string response = HttpPost(_serverBaseUrl + "activate", json);

                if (string.IsNullOrEmpty(response))
                    return new ActivationResult(false, "网络请求失败，请检查网络连接");

                // 使用标准 JSON 库解析响应
                var serializer = new JavaScriptSerializer();
                var result = serializer.Deserialize<Dictionary<string, object>>(response);

                if (result != null && result.ContainsKey("success") && Convert.ToBoolean(result["success"]))
                {
                    // 解析过期时间
                    if (result.ContainsKey("data"))
                    {
                        var dataObj = result["data"] as Dictionary<string, object>;
                        if (dataObj != null && dataObj.ContainsKey("expires_at"))
                        {
                            string expiresAt = Convert.ToString(dataObj["expires_at"]);
                            if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                            {
                                _expiresAt = expiresAt;
                            }
                            else
                            {
                                _expiresAt = ""; // 永不过期
                            }
                        }
                    }

                    // 激活成功，保存本地授权
                    SaveLocalLicense(licenseKey.Trim().ToUpperInvariant(), "online");
                    
                    // 检查是否有离线待上报标记
                    if (File.Exists(PendingReportFile))
                    {
                        try { File.Delete(PendingReportFile); } catch { }
                    }

                    _currentStatus = LicenseStatus.Licensed;
                    OnStatusChanged(LicenseStatus.Licensed);
                    return new ActivationResult(true, "激活成功");
                }
                else
                {
                    // 提取错误消息
                    string message = ExtractMessageFromJson(result, "激活失败");
                    return new ActivationResult(false, message);
                }
            }
            catch (Exception ex)
            {
                return new ActivationResult(false, "网络错误: " + ex.Message);
            }
        }

        /// <summary>
        /// 检测外网授权服务器是否可达
        /// 使用全新的独立 HttpClient 发送 POST 请求到 validate 接口
        /// 完全避免与共享 _httpClient 的任何交互
        /// 使用同步方式避免异步/同步转换死锁
        /// </summary>
        private static bool IsServerReachable()
        {
            try
            {
                // 确保 _serverBaseUrl 已初始化
                string url = _serverBaseUrl;
                if (string.IsNullOrEmpty(url))
                {
                    url = CryptoHelper.DecodeLicenseUrl();
                }
                if (!url.EndsWith("/"))
                    url += "/";

                // 使用全新的独立 HttpClient
                // 完全避免与共享 _httpClient 的任何交互
                using (var client = new System.Net.Http.HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(5);
                    
                    // 构建 POST 请求
                    var data = new Dictionary<string, string>
                    {
                        { "machine_code", MachineCode }
                    };
                    string json = BuildJson(data);
                    var content = new StringContent(json, Encoding.UTF8, "application/json");
                    
                    // 使用同步方式发送 POST 请求
                    // 使用 Task.Run 避免死锁
                    var task = Task.Run(async () =>
                    {
                        var response = await client.PostAsync(url + "validate", content);
                        // 只要服务器有响应（无论 HTTP 状态码是什么），就说明服务器可达
                        return true;
                    });
                    
                    return task.Result;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 离线激活（导入 .lic 文件）
        /// 支持两种格式：
        ///   v1 加密格式：{"v":1,"enc":true,"data":"...","sig":"..."}
        ///   旧版明文格式：{"license_key":"...","machine_code":"...","expires_at":"...","signature":"..."}
        /// </summary>
        public static ActivationResult ActivateOffline(string filePath)
        {
            try
            {
                // 防御性检查：如果外网授权服务器可达，禁止使用离线激活
                if (IsServerReachable())
                {
                    return new ActivationResult(false, "检测到外网授权服务器可达，请使用在线激活，禁止离线激活");
                }

                string content = File.ReadAllText(filePath, Encoding.UTF8);
                if (string.IsNullOrWhiteSpace(content))
                    return new ActivationResult(false, "授权文件为空");

                // 使用标准 JSON 解析判断文件格式
                var serializer = new JavaScriptSerializer();
                var jsonObj = serializer.Deserialize<Dictionary<string, object>>(content);

                if (jsonObj == null)
                    return new ActivationResult(false, "无效的授权文件格式");

                // 检测文件格式：是否为新版加密格式（包含 "v"、"enc"、"data"、"sig" 字段）
                if (jsonObj.ContainsKey("v") && jsonObj.ContainsKey("enc") && 
                    jsonObj.ContainsKey("data") && jsonObj.ContainsKey("sig"))
                {
                    return ActivateOfflineV1(jsonObj);
                }
                else
                {
                    return ActivateOfflineLegacy(jsonObj);
                }
            }
            catch (Exception ex)
            {
                return new ActivationResult(false, "读取授权文件失败: " + ex.Message);
            }
        }

        /// <summary>
        /// 新版加密 .lic 格式验证
        /// {"v":1,"enc":true,"data":"AES加密Base64","sig":"HMAC签名"}
        /// </summary>
        private static ActivationResult ActivateOfflineV1(Dictionary<string, object> jsonObj)
        {
            try
            {
                string dataField = Convert.ToString(jsonObj["data"]);
                string sigField = Convert.ToString(jsonObj["sig"]);

                if (string.IsNullOrEmpty(dataField) || string.IsNullOrEmpty(sigField))
                    return new ActivationResult(false, "无效的授权文件格式");

                // 使用默认密钥解密
                string secret = GetDefaultSecretKey();

                // 解密 .lic 文件（使用修复后的统一 AES 解密）
                string decryptedJson = CryptoHelper.DecryptLicenseFile(dataField, sigField, secret);
                if (string.IsNullOrEmpty(decryptedJson))
                {
                    // 尝试配置中的自定义密钥（如果有的话）
                    string defaultKey = GetDefaultSecretKey();
                    string configSecret = ConfigurationHelper.GetSetting("LicenseSecretKey", defaultKey);
                    if (configSecret != defaultKey)
                    {
                        decryptedJson = CryptoHelper.DecryptLicenseFile(dataField, sigField, configSecret);
                    }

                    if (string.IsNullOrEmpty(decryptedJson))
                        return new ActivationResult(false, "授权文件签名无效，已被篡改");
                }

                // 使用标准 JSON 解析解密后的内容
                var serializer = new JavaScriptSerializer();
                var decrypted = serializer.Deserialize<Dictionary<string, object>>(decryptedJson);

                if (decrypted == null)
                    return new ActivationResult(false, "授权文件内容无效");

                string licenseKey = Convert.ToString(decrypted["license_key"]);
                string machineCode = Convert.ToString(decrypted["machine_code"]);
                string expiresAt = decrypted.ContainsKey("expires_at") ? Convert.ToString(decrypted["expires_at"]) : "";

                if (string.IsNullOrEmpty(licenseKey) || string.IsNullOrEmpty(machineCode))
                    return new ActivationResult(false, "授权文件内容无效");

                // 验证机器码
                if (machineCode != MachineCode)
                    return new ActivationResult(false, "授权文件与本机不匹配");

                // 检查有效期
                if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                {
                    DateTime expireTime;
                    if (DateTime.TryParse(expiresAt, out expireTime))
                    {
                        if (expireTime < DateTime.Now)
                            return new ActivationResult(false, "授权文件已过期");
                    }
                }

                // 🔧 修复：保存过期时间到全局字段
                if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                    _expiresAt = expiresAt;
                else
                    _expiresAt = "";

                // 激活成功
                SaveLocalLicense(licenseKey, "offline");

                // 标记：有网时需要补报
                try { File.WriteAllText(PendingReportFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); } catch { }

                _currentStatus = LicenseStatus.Licensed;
                OnStatusChanged(LicenseStatus.Licensed);
                return new ActivationResult(true, "离线激活成功");
            }
            catch (Exception ex)
            {
                return new ActivationResult(false, "解析授权文件失败: " + ex.Message);
            }
        }

        /// <summary>
        /// 旧版明文 .lic 格式验证（兼容旧版）
        /// </summary>
        private static ActivationResult ActivateOfflineLegacy(Dictionary<string, object> jsonObj)
        {
            try
            {
                string licenseKey = jsonObj.ContainsKey("license_key") ? Convert.ToString(jsonObj["license_key"]) : "";
                string machineCode = jsonObj.ContainsKey("machine_code") ? Convert.ToString(jsonObj["machine_code"]) : "";
                string expiresAt = jsonObj.ContainsKey("expires_at") ? Convert.ToString(jsonObj["expires_at"]) : "";
                string signature = jsonObj.ContainsKey("signature") ? Convert.ToString(jsonObj["signature"]) : "";

                if (string.IsNullOrEmpty(licenseKey) || string.IsNullOrEmpty(machineCode))
                    return new ActivationResult(false, "无效的授权文件");

                // 验证机器码
                if (machineCode != MachineCode)
                    return new ActivationResult(false, "授权文件与本机不匹配");

                // 验证签名（HMAC-SHA256）
                string expiresForSign = "";
                if (string.IsNullOrEmpty(expiresAt) || expiresAt == "null" || expiresAt == "")
                {
                    expiresForSign = "never";
                }
                else
                {
                    expiresForSign = expiresAt;
                }

                string secret = GetDefaultSecretKey();
                string dataToVerify = licenseKey + machineCode + expiresForSign;
                if (!CryptoHelper.VerifyHmacSignature(dataToVerify, signature, secret))
                {
                    // 尝试配置中的自定义密钥
                    string defaultKey = GetDefaultSecretKey();
                    string configSecret = ConfigurationHelper.GetSetting("LicenseSecretKey", defaultKey);
                    if (configSecret != defaultKey)
                    {
                        if (!CryptoHelper.VerifyHmacSignature(dataToVerify, signature, configSecret))
                            return new ActivationResult(false, "授权文件签名无效，已被篡改");
                    }
                    else
                    {
                        return new ActivationResult(false, "授权文件签名无效，已被篡改");
                    }
                }

                // 检查有效期
                if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null")
                {
                    DateTime expireTime;
                    if (DateTime.TryParse(expiresAt, out expireTime))
                    {
                        if (expireTime < DateTime.Now)
                            return new ActivationResult(false, "授权文件已过期");
                    }
                }

                // 🔧 修复：保存过期时间到全局字段
                if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                    _expiresAt = expiresAt;
                else
                    _expiresAt = "";

                // 激活成功
                SaveLocalLicense(licenseKey, "offline");

                // 标记：有网时需要补报
                try { File.WriteAllText(PendingReportFile, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")); } catch { }

                _currentStatus = LicenseStatus.Licensed;
                OnStatusChanged(LicenseStatus.Licensed);
                return new ActivationResult(true, "离线激活成功");
            }
            catch (Exception ex)
            {
                return new ActivationResult(false, "读取授权文件失败: " + ex.Message);
            }
        }

        /// <summary>
        /// 上报机器信息到服务端（未授权时调用 / 离线授权补报）
        /// </summary>
        public static bool ReportMachine()
        {
            try
            {
                var hardwareInfo = MachineCodeHelper.GetHardwareInfo();

                var data = new Dictionary<string, string>
                {
                    { "machine_code", MachineCode },
                    { "hostname", Environment.MachineName },
                    { "os_version", MachineCodeHelper.GetOsVersion() },
                    { "dotnet_version", MachineCodeHelper.GetDotNetVersion() },
                    { "cpu_id", hardwareInfo["cpu_id"] },
                    { "cpu_name", hardwareInfo["cpu_name"] },
                    { "motherboard_sn", hardwareInfo["motherboard_sn"] },
                    { "motherboard_model", hardwareInfo["motherboard_model"] },
                    { "disk_sn", hardwareInfo["disk_sn"] },
                    { "disk_model", hardwareInfo["disk_model"] },
                    { "mac_address", hardwareInfo["mac_address"] },
                    { "app_version", Application.ProductVersion }
                };

                string json = BuildJson(data);
                string response = HttpPost(_serverBaseUrl + "report", json);

                if (!string.IsNullOrEmpty(response))
                {
                    // 清除待上报标记
                    if (File.Exists(PendingReportFile))
                    {
                        try { File.Delete(PendingReportFile); } catch { }
                    }

                    // 使用标准 JSON 库解析
                    var serializer = new JavaScriptSerializer();
                    var result = serializer.Deserialize<Dictionary<string, object>>(response);

                    if (result != null && result.ContainsKey("data"))
                    {
                        var dataObj = result["data"] as Dictionary<string, object>;
                        if (dataObj != null && dataObj.ContainsKey("licensed") && Convert.ToBoolean(dataObj["licensed"]))
                        {
                            // 意外发现已被授权，更新本地状态
                            _currentStatus = LicenseStatus.Licensed;
                            OnStatusChanged(LicenseStatus.Licensed);
                        }
                    }
                    return true;
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 检查是否有待上报标记（离线授权后未联网补报）
        /// </summary>
        public static bool HasPendingReport()
        {
            return File.Exists(PendingReportFile);
        }

        /// <summary>
        /// 获取授权状态文本
        /// </summary>
        public static string GetStatusText()
        {
            switch (_currentStatus)
            {
                case LicenseStatus.Licensed:
                    return "✅ 已授权";
                case LicenseStatus.Unlicensed:
                    return "❌ 未授权";
                case LicenseStatus.Expired:
                    return "⌛ 授权已过期";
                case LicenseStatus.Disabled:
                    return "🚫 授权已被禁用";
                case LicenseStatus.NetworkError:
                    return "⚠ 网络连接失败，授权验证未通过";
                default:
                    return "⏳ 验证中...";
            }
        }

        #region Private Methods

        /// <summary>
        /// 从 JSON 响应字典中提取 message 字段
        /// </summary>
        private static string ExtractMessageFromJson(Dictionary<string, object> jsonObj, string defaultMsg)
        {
            try
            {
                if (jsonObj != null && jsonObj.ContainsKey("message"))
                    return Convert.ToString(jsonObj["message"]);
            }
            catch { }
            return defaultMsg;
        }

        /// <summary>
        /// 构建简易 JSON 字符串
        /// </summary>
        private static string BuildJson(Dictionary<string, string> data)
        {
            var serializer = new JavaScriptSerializer();
            // 先转为普通 Dictionary<string, object> 再序列化
            var obj = new Dictionary<string, object>();
            foreach (var kv in data)
            {
                obj[kv.Key] = kv.Value;
            }
            return serializer.Serialize(obj);
        }

        /// <summary>
        /// 校验本地授权文件的有效性
        /// 检查：机器码匹配、过期时间
        /// </summary>
        private static bool ValidateLocalLicense()
        {
            try
            {
                if (!File.Exists(LicenseFilePath))
                    return false;

                string encrypted = File.ReadAllText(LicenseFilePath);
                string json = CryptoHelper.DecryptFromBase64(encrypted);

                if (string.IsNullOrEmpty(json))
                    return false;

                var serializer = new JavaScriptSerializer();
                var result = serializer.Deserialize<Dictionary<string, object>>(json);

                if (result == null)
                    return false;

                // 检查机器码是否匹配
                string savedMachineCode = result.ContainsKey("machine_code") ? Convert.ToString(result["machine_code"]) : "";
                if (string.IsNullOrEmpty(savedMachineCode))
                    return false;

                bool machineMatch = (savedMachineCode == MachineCode);

                // 如果机器码不完全匹配，尝试部分匹配（物理网卡 MAC 交集）
                if (!machineMatch)
                {
                    string savedMacListStr = result.ContainsKey("mac_list") ? Convert.ToString(result["mac_list"]) : "";
                    if (!string.IsNullOrEmpty(savedMacListStr))
                    {
                        List<string> currentMacList = MachineCodeHelper.GetPhysicalMacList();
                        HashSet<string> savedMacSet = new HashSet<string>(
                            savedMacListStr.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                            StringComparer.OrdinalIgnoreCase
                        );

                        foreach (string currentMac in currentMacList)
                        {
                            if (savedMacSet.Contains(currentMac))
                            {
                                machineMatch = true;
                                break;
                            }
                        }
                    }
                }

                if (!machineMatch)
                    return false;

                // 检查过期时间
                string expiresAt = result.ContainsKey("expires_at") ? Convert.ToString(result["expires_at"]) : "";
                if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                {
                    DateTime expireTime;
                    if (DateTime.TryParse(expiresAt, out expireTime))
                    {
                        if (expireTime < DateTime.Now)
                            return false; // 已过期
                    }
                }

                // 本地校验通过
                _currentLicenseKey = result.ContainsKey("license_key") ? Convert.ToString(result["license_key"]) : "";
                _expiresAt = expiresAt;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 联网验证授权（同步）
        /// 如果服务端失联（网络错误），回退到校验本地授权文件
        /// </summary>
        private static bool ValidateWithServerSync()
        {
            // 相辅相成：校验前先检查反调试系统是否被禁用
            // 如果守护线程被停止或反调试被绕过，这里会检测到
            if (AntiDebug.IsLicenseSystemTampered())
            {
                LogHelper.WriteLog("[授权] 检测到授权系统被篡改，执行惩罚");
                AntiDebug.ForcePenalty();
                return false;
            }

            try
            {
                var hardwareInfo = MachineCodeHelper.GetHardwareInfo();

                var data = new Dictionary<string, string>
                {
                    { "license_key", _currentLicenseKey },
                    { "machine_code", MachineCode },
                    { "hostname", Environment.MachineName },
                    { "os_version", MachineCodeHelper.GetOsVersion() },
                    { "dotnet_version", MachineCodeHelper.GetDotNetVersion() },
                    { "cpu_id", hardwareInfo["cpu_id"] },
                    { "cpu_name", hardwareInfo["cpu_name"] },
                    { "motherboard_sn", hardwareInfo["motherboard_sn"] },
                    { "motherboard_model", hardwareInfo["motherboard_model"] },
                    { "disk_sn", hardwareInfo["disk_sn"] },
                    { "disk_model", hardwareInfo["disk_model"] },
                    { "mac_address", hardwareInfo["mac_address"] },
                    { "app_version", Application.ProductVersion }
                };

                string json = BuildJson(data);
                string response = HttpPost(_serverBaseUrl + "validate", json);

                // 服务端失联（网络错误），回退到本地校验
                if (string.IsNullOrEmpty(response))
                {
                    bool localValid = ValidateLocalLicense();
                    if (localValid)
                    {
                        _currentStatus = LicenseStatus.Licensed;
                        return true;
                    }
                    else
                    {
                        _currentStatus = LicenseStatus.NetworkError;
                        return false;
                    }
                }

                // 使用标准 JSON 库解析
                var serializer = new JavaScriptSerializer();
                var result = serializer.Deserialize<Dictionary<string, object>>(response);

                if (result == null)
                {
                    // 响应格式错误，回退到本地校验
                    bool localValid = ValidateLocalLicense();
                    if (localValid)
                    {
                        _currentStatus = LicenseStatus.Licensed;
                        return true;
                    }
                    else
                    {
                        _currentStatus = LicenseStatus.NetworkError;
                        return false;
                    }
                }

                // 解析验证结果
                if (result.ContainsKey("valid") && Convert.ToBoolean(result["valid"]))
                {
                    _currentStatus = LicenseStatus.Licensed;
                    
                    string serverLicenseKey = "";
                    if (result.ContainsKey("license_key"))
                    {
                        serverLicenseKey = Convert.ToString(result["license_key"]);
                    }

                    // 解析过期时间
                    if (result.ContainsKey("expires_at"))
                    {
                        string expiresAt = Convert.ToString(result["expires_at"]);
                        if (!string.IsNullOrEmpty(expiresAt) && expiresAt != "null" && expiresAt != "")
                        {
                            _expiresAt = expiresAt;
                        }
                        else
                        {
                            _expiresAt = ""; // 永不过期
                        }
                    }
                    
                string keyToSave = "";
                if (!string.IsNullOrEmpty(serverLicenseKey))
                {
                    keyToSave = serverLicenseKey;
                }
                else if (!string.IsNullOrEmpty(_currentLicenseKey))
                {
                    keyToSave = _currentLicenseKey;
                }
                else
                {
                    keyToSave = "MC-" + MachineCode.Substring(0, Math.Min(MachineCode.Length, 16));
                }
                
                if (!string.IsNullOrEmpty(keyToSave))
                {
                    SaveLocalLicense(keyToSave, "online");
                }
                    
                    // 🔧 修复：同步上报硬件信息（不再用后台线程，确保上报完成）
                    // 离线激活后首次联网，将硬件信息同步到服务端
                    if (HasPendingReport())
                    {
                        ReportMachine();
                    }
                    
                    return true;
                }
                else if ((result.ContainsKey("status") && Convert.ToString(result["status"]) == "expired") ||
                         (result.ContainsKey("expired") && Convert.ToBoolean(result["expired"])))
                {
                    _currentStatus = LicenseStatus.Expired;
                    return false;
                }
                else if (result.ContainsKey("status") && Convert.ToString(result["status"]) == "disabled")
                {
                    _currentStatus = LicenseStatus.Disabled;
                    return false;
                }
                else
                {
                    _currentStatus = LicenseStatus.Unlicensed;
                    // 🔧 修复：服务端无此机器记录时，自动上报注册硬件信息
                    // 之前需要用户手动在LicenseForm中点击"上报"，现在自动完成
                    if (result.ContainsKey("status") && Convert.ToString(result["status"]) == "none")
                    {
                        ReportMachine();
                    }
                    return false;
                }
            }
            catch
            {
                // 网络异常，回退到本地校验
                bool localValid = ValidateLocalLicense();
                if (localValid)
                {
                    _currentStatus = LicenseStatus.Licensed;
                    return true;
                }
                else
                {
                    _currentStatus = LicenseStatus.NetworkError;
                    return false;
                }
            }
        }

        /// <summary>
        /// 定时器回调
        /// 定期联网校验授权状态
        /// 如果服务端返回 disabled/expired，立即触发惩罚
        /// </summary>
        private static void OnValidationTimer(object state)
        {
            if (_isChecking) return;
            _isChecking = true;
            try
            {
                // 反调试检测点：定时校验
                AntiDebug.Checkpoint("TimerValidation");

                bool valid = ValidateWithServerSync();
                OnStatusChanged(valid ? LicenseStatus.Licensed : _currentStatus);

                // 如果服务端返回禁用或过期，立即执行惩罚
                if (_currentStatus == LicenseStatus.Disabled || _currentStatus == LicenseStatus.Expired)
                {
                    LogHelper.WriteLog(string.Format("[授权] 服务端返回状态: {0}，授权码: {1}，执行惩罚",
                        _currentStatus, _currentLicenseKey));
                    AntiDebug.ForcePenalty();
                }
            }
            finally
            {
                _isChecking = false;
            }
        }

        /// <summary>
        /// 保存本地授权缓存
        /// </summary>
        private static void SaveLocalLicense(string licenseKey, string method)
        {
            try
            {
                Directory.CreateDirectory(LicenseFileDir);

                // 获取当前所有物理网卡 MAC 列表，用于后续部分匹配验证
                List<string> macList = MachineCodeHelper.GetPhysicalMacList();
                string macListStr = string.Join(",", macList);

                var data = new Dictionary<string, string>
                {
                    { "license_key", licenseKey },
                    { "machine_code", MachineCode },
                    { "activate_method", method },
                    { "expires_at", _expiresAt ?? "" },
                    { "saved_at", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") },
                    { "mac_list", macListStr } // 保存物理网卡 MAC 列表，用于部分匹配
                };

                string json = BuildJson(data);

                // DPAPI 加密存储
                string encrypted = CryptoHelper.EncryptToBase64(json);
                
                File.WriteAllText(LicenseFilePath, encrypted);
                
                _currentLicenseKey = licenseKey;
            }
            catch
            {
            }
        }

        /// <summary>
        /// 加载本地授权缓存
        /// </summary>
        private static void LoadLocalLicense()
        {
            try
            {
                if (!File.Exists(LicenseFilePath))
                {
                    _currentStatus = LicenseStatus.Unlicensed;
                    return;
                }

                string encrypted = File.ReadAllText(LicenseFilePath);
                string json = CryptoHelper.DecryptFromBase64(encrypted);
                
                if (string.IsNullOrEmpty(json))
                {
                    _currentStatus = LicenseStatus.Unlicensed;
                    return;
                }

                // 使用标准 JSON 库解析
                var serializer = new JavaScriptSerializer();
                var result = serializer.Deserialize<Dictionary<string, object>>(json);

                if (result == null)
                {
                    _currentStatus = LicenseStatus.Unlicensed;
                    return;
                }

                _currentLicenseKey = result.ContainsKey("license_key") ? Convert.ToString(result["license_key"]) : "";

                // 读取过期时间
                _expiresAt = result.ContainsKey("expires_at") ? Convert.ToString(result["expires_at"]) : "";

                // 验证机器码是否匹配
                string savedMachineCode = result.ContainsKey("machine_code") ? Convert.ToString(result["machine_code"]) : "";
                if (savedMachineCode == MachineCode)
                {
                    // 机器码完全匹配，状态待验证（启动时会联网校验）
                    _currentStatus = LicenseStatus.Unknown;
                }
                else
                {
                    // 机器码不完全匹配，尝试部分匹配：检查物理网卡 MAC 是否有交集
                    // 场景：机器有 3 个物理网卡，授权时记录了 3 个 MAC，
                    //       后来某个网卡变了（如换了无线网卡），但其他物理网卡没变，
                    //       只要还有至少一个物理网卡 MAC 匹配，就认为还是同一台机器
                    bool partialMatch = false;

                    // 读取授权时保存的 MAC 列表
                    string savedMacListStr = result.ContainsKey("mac_list") ? Convert.ToString(result["mac_list"]) : "";
                    if (!string.IsNullOrEmpty(savedMacListStr))
                    {
                        // 获取当前物理网卡 MAC 列表
                        List<string> currentMacList = MachineCodeHelper.GetPhysicalMacList();
                        
                        // 将保存的 MAC 列表拆分为集合
                        HashSet<string> savedMacSet = new HashSet<string>(
                            savedMacListStr.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries),
                            StringComparer.OrdinalIgnoreCase
                        );

                        // 检查是否有交集：当前任意一个物理网卡 MAC 在授权时记录的列表中
                        foreach (string currentMac in currentMacList)
                        {
                            if (savedMacSet.Contains(currentMac))
                            {
                                partialMatch = true;
                                break;
                            }
                        }
                    }

                    if (partialMatch)
                    {
                        // 部分匹配成功：至少有一个物理网卡 MAC 没变，认为是同一台机器
                        // 重新保存授权（更新机器码和 MAC 列表）
                        _currentStatus = LicenseStatus.Unknown;
                        // 更新本地授权文件中的 machine_code 和 mac_list
                        SaveLocalLicense(_currentLicenseKey, "partial_match");
                    }
                    else
                    {
                        // 完全无匹配，授权无效
                        _currentLicenseKey = "";
                        _currentStatus = LicenseStatus.Unlicensed;
                        try { File.Delete(LicenseFilePath); } catch { }
                    }
                }
            }
            catch
            {
                _currentStatus = LicenseStatus.Unlicensed;
            }
        }

        /// <summary>
        /// 发送 HTTP POST 请求（使用 HttpClient 替代已过时的 WebClient）
        /// </summary>
        private static string HttpPost(string url, string json)
        {
            try
            {
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                
                // 同步调用 HttpClient.PostAsync（使用 Task.Run 避免异步传播到整个调用链）
                var task = Task.Run(async () =>
                {
                    var response = await _httpClient.PostAsync(url, content);
                    response.EnsureSuccessStatusCode();
                    return await response.Content.ReadAsStringAsync();
                });

                return task.Result;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 触发状态变更事件
        /// </summary>
        private static void OnStatusChanged(LicenseStatus status)
        {
            var handler = StatusChanged;
            if (handler != null)
                handler(null, new LicenseStatusEventArgs(status));
        }

        #endregion
    }

    /// <summary>
    /// 授权状态事件参数
    /// </summary>
    public class LicenseStatusEventArgs : EventArgs
    {
        public LicenseHelper.LicenseStatus Status { get; private set; }
        public string StatusText { get; private set; }

        public LicenseStatusEventArgs(LicenseHelper.LicenseStatus status)
        {
            Status = status;
            StatusText = LicenseHelper.GetStatusText();
        }
    }

    /// <summary>
    /// 激活结果
    /// </summary>
    public class ActivationResult
    {
        public bool Success { get; private set; }
        public string Message { get; private set; }

        public ActivationResult(bool success, string message)
        {
            Success = success;
            Message = message;
        }
    }
}
