using System;

namespace PrintServer
{
    /// <summary>
    /// 授权验证间隔（小时），编译时固定，不可通过配置文件修改
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false)]
    public class AssemblyLicenseValidationIntervalAttribute : Attribute
    {
        public int IntervalHours { get; private set; }

        public AssemblyLicenseValidationIntervalAttribute(int intervalHours)
        {
            IntervalHours = intervalHours;
        }
    }

    /// <summary>
    /// 授权服务器 API 地址，编译时固定，不可通过配置文件修改
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false)]
    public class AssemblyLicenseUrlAttribute : Attribute
    {
        public string Url { get; private set; }

        public AssemblyLicenseUrlAttribute(string url)
        {
            Url = url;
        }
    }

    /// <summary>
    /// 授权加密密钥，编译时固定，不可通过配置文件修改
    /// </summary>
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false)]
    public class AssemblySecretKeyAttribute : Attribute
    {
        public string SecretKey { get; private set; }

        public AssemblySecretKeyAttribute(string secretKey)
        {
            SecretKey = secretKey;
        }
    }
}
