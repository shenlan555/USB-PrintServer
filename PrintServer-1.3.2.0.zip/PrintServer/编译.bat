@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
set w=80 & set h=30
powershell -command "$host.UI.RawUI.BufferSize = New-Object System.Management.Automation.Host.Size(%w%, 9999); $host.UI.RawUI.WindowSize = New-Object System.Management.Automation.Host.Size(%w%, %h%)" 2>nul
title 网络打印服务器编译 By:浪里个浪 https://www.itlog.vip
echo.
echo =========================================
echo   网络打印服务器编译工具
echo   https://www.itlog.vip
echo =========================================
echo.
echo 正在关闭旧进程...
taskkill /f /im PrintServer.exe >nul 2>&1
echo.

C:\Windows\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe PrintServer.csproj /t:Rebuild /p:Configuration=Release

if %errorlevel% equ 0 (
    echo.
    echo ====================================
    echo   编译成功！
    echo ====================================
    echo.
    echo 程序位置: bin\PrintServer-v1.3.1.1\PrintServer.exe
    echo.
    explorer bin\PrintServer-v1.3.1.1
) else (
    echo.
    echo 编译失败，请检查错误
)
timeout /n 1