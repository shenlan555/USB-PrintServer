using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace PrintServer
{
    /// <summary>
    /// 反调试检测类（加强版）
    /// 四层防护：
    ///   第一层：增强检测
    ///   第二层：代码完整性校验
    ///   第三层：多线程守护
    ///   第四层：严厉惩罚
    /// </summary>
    public static class AntiDebug
    {
        #region Native Methods

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool IsDebuggerPresent();

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CheckRemoteDebuggerPresent(IntPtr hProcess, ref bool isDebuggerPresent);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetCurrentProcess();

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtQueryInformationProcess(IntPtr processHandle, int processInformationClass,
            out IntPtr processInformation, int processInformationLength, out int returnLength);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetThreadContext(IntPtr hThread, ref CONTEXT lpContext);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr OpenThread(ThreadAccess dwDesiredAccess, bool bInheritHandle, int dwThreadId);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool CloseHandle(IntPtr hObject);

        [Flags]
        private enum ThreadAccess : uint
        {
            THREAD_GET_CONTEXT = 0x0008,
            THREAD_QUERY_INFORMATION = 0x0040,
        }

        private const int CONTEXT_DEBUG_REGISTERS = 0x00010000;

        [StructLayout(LayoutKind.Sequential)]
        private struct CONTEXT
        {
            public uint ContextFlags;
            public uint Dr0;
            public uint Dr1;
            public uint Dr2;
            public uint Dr3;
            public uint Dr6;
            public uint Dr7;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
            public uint[] Reserved;
        }

        private const int ProcessDebugPort = 7;
        private const int ProcessDebugObjectHandle = 30;
        private const int ProcessDebugFlags = 31;

        #endregion

        private static bool _penaltyTriggered = false;
        private static readonly Random _random = new Random();
        private static Thread _guardianThread = null;
        private static bool _guardianRunning = false;
        private static int _detectionCount = 0;
        private static readonly int DETECTION_THRESHOLD = 3;
        private static DateTime _lastCheckTime = DateTime.MinValue;
        private static readonly int CHECK_INTERVAL_MS = 30000; // 两次检测间隔至少30秒

        private static readonly string REGISTRY_PATH = @"Software\PrintServer";
        private static readonly string REGISTRY_BLACKLIST_KEY = "Blacklisted";

        /// <summary>
        /// 执行完整的反调试检测（带频率限制，防止误判）
        /// </summary>
        public static bool CheckAll()
        {
            if (_penaltyTriggered)
                return true;

            // 频率限制：两次检测之间至少间隔 CHECK_INTERVAL_MS
            if ((DateTime.Now - _lastCheckTime).TotalMilliseconds < CHECK_INTERVAL_MS)
                return false;
            _lastCheckTime = DateTime.Now;

            bool detected = false;

            // 1. 基础调试器检测（最可靠）
            if (CheckDebuggerPresent())
                detected = true;

            // 2. 调试端口检测（NtQueryInformationProcess）
            if (CheckDebugPort())
                detected = true;

            // 3. 调试对象句柄检测
            if (CheckDebugObjectHandle())
                detected = true;

            // 4. 进程调试标志检测
            if (CheckDebugFlags())
                detected = true;

            // 5. 硬件断点检测（只检测其他线程，不检测自己）
            if (CheckHardwareBreakpoints())
                detected = true;

            // 6. 调试器模块检测
            if (CheckDebuggerModules())
                detected = true;

            // 7. 调试器进程名检测
            if (CheckDebuggerProcesses())
                detected = true;

            if (detected)
            {
                _detectionCount++;
                if (_detectionCount >= DETECTION_THRESHOLD)
                {
                    return true;
                }
            }
            else
            {
                if (_detectionCount > 0)
                    _detectionCount--;
            }

            return false;
        }

        /// <summary>
        /// 在指定位置插入反调试检测点
        /// </summary>
        public static void Checkpoint(string location)
        {
            if (CheckAll())
            {
                LogSecurityAlert(location);
                ExecutePenalty();
            }
        }

        /// <summary>
        /// 启动守护线程
        /// </summary>
        public static void StartGuardian()
        {
            if (_guardianRunning)
                return;

            _guardianRunning = true;
            _guardianThread = new Thread(GuardianLoop)
            {
                IsBackground = true,
                Name = "AntiDebugGuardian"
            };
            _guardianThread.Start();
        }

        /// <summary>
        /// 停止守护线程
        /// </summary>
        public static void StopGuardian()
        {
            _guardianRunning = false;
            _guardianThread = null;
        }

        /// <summary>
        /// 检查注册表黑名单
        /// </summary>
        public static bool IsBlacklisted()
        {
            try
            {
                using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(REGISTRY_PATH))
                {
                    if (key != null)
                    {
                        object val = key.GetValue(REGISTRY_BLACKLIST_KEY);
                        if (val != null && Convert.ToInt32(val) == 1)
                            return true;
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 强制触发惩罚（供 LicenseHelper 在服务端返回禁用/过期时调用）
        /// </summary>
        public static void ForcePenalty()
        {
            ExecutePenalty();
        }

        /// <summary>
        /// 校验授权系统是否被篡改
        /// 如果 LicenseHelper 的关键方法被跳过或返回值被篡改，这里会检测到
        /// </summary>
        public static bool IsLicenseSystemTampered()
        {
            try
            {
                // 检查 LicenseHelper 的关键状态
                // 如果状态是 Unknown 但本地有授权文件，说明校验可能被跳过
                if (LicenseHelper.CurrentStatus == LicenseHelper.LicenseStatus.Unknown &&
                    LicenseHelper.HasLocalLicenseFile)
                {
                    // 尝试手动触发一次校验，如果校验被跳过，说明有问题
                    // 这里不做实际校验，只是检查状态是否合理
                    return false;
                }

                // 检查是否有人直接修改了 CurrentStatus 字段
                // 正常流程中，状态只会通过 ValidateWithServerSync 或 LoadLocalLicense 改变
                // 如果状态突然变成 Licensed 但没有经过校验，说明被篡改
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// 初始化反调试系统
        /// </summary>
        public static void Initialize()
        {
            // 检查注册表黑名单
            if (IsBlacklisted())
            {
                LogSecurityAlert("BlacklistCheck");
                Environment.Exit(0);
            }

            // 启动守护线程
            StartGuardian();
        }

        #region 检测方法

        /// <summary>
        /// 检测调试器是否附加
        /// </summary>
        private static bool CheckDebuggerPresent()
        {
            try
            {
                if (IsDebuggerPresent())
                    return true;

                bool isDebugged = false;
                if (CheckRemoteDebuggerPresent(Process.GetCurrentProcess().Handle, ref isDebugged))
                {
                    if (isDebugged)
                        return true;
                }

                if (Debugger.IsAttached)
                    return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测调试端口
        /// </summary>
        private static bool CheckDebugPort()
        {
            try
            {
                IntPtr debugPort = IntPtr.Zero;
                int returnLength;
                int status = NtQueryInformationProcess(
                    GetCurrentProcess(), ProcessDebugPort,
                    out debugPort, IntPtr.Size, out returnLength);
                if (status == 0 && debugPort != IntPtr.Zero)
                    return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测调试对象句柄
        /// </summary>
        private static bool CheckDebugObjectHandle()
        {
            try
            {
                IntPtr debugObjectHandle = IntPtr.Zero;
                int returnLength;
                int status = NtQueryInformationProcess(
                    GetCurrentProcess(), ProcessDebugObjectHandle,
                    out debugObjectHandle, IntPtr.Size, out returnLength);
                if (status == 0 && debugObjectHandle != IntPtr.Zero)
                    return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测进程调试标志
        /// </summary>
        private static bool CheckDebugFlags()
        {
            try
            {
                IntPtr debugFlags = IntPtr.Zero;
                int returnLength;
                int status = NtQueryInformationProcess(
                    GetCurrentProcess(), ProcessDebugFlags,
                    out debugFlags, IntPtr.Size, out returnLength);
                if (status == 0 && debugFlags == IntPtr.Zero)
                    return true;
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测硬件断点（只检测其他线程，避免死锁）
        /// </summary>
        private static bool CheckHardwareBreakpoints()
        {
            try
            {
                int currentThreadId = Thread.CurrentThread.ManagedThreadId;
                Process currentProcess = Process.GetCurrentProcess();

                foreach (ProcessThread thread in currentProcess.Threads)
                {
                    // 跳过当前线程，避免死锁
                    if (thread.Id == currentThreadId)
                        continue;

                    try
                    {
                        IntPtr hThread = OpenThread(
                            ThreadAccess.THREAD_GET_CONTEXT | ThreadAccess.THREAD_QUERY_INFORMATION,
                            false, thread.Id);

                        if (hThread == IntPtr.Zero)
                            continue;

                        try
                        {
                            CONTEXT ctx = new CONTEXT();
                            ctx.ContextFlags = CONTEXT_DEBUG_REGISTERS;
                            ctx.Reserved = new uint[128];

                            if (GetThreadContext(hThread, ref ctx))
                            {
                                if (ctx.Dr0 != 0 || ctx.Dr1 != 0 || ctx.Dr2 != 0 || ctx.Dr3 != 0)
                                    return true;
                                if ((ctx.Dr7 & 0xFF) != 0)
                                    return true;
                            }
                        }
                        finally
                        {
                            CloseHandle(hThread);
                        }
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测调试器模块
        /// </summary>
        private static bool CheckDebuggerModules()
        {
            try
            {
                Process currentProcess = Process.GetCurrentProcess();
                string[] suspiciousModules = {
                    "scylla.dll", "scyllahide.dll",
                    "hook.dll", "inject.dll", "vmt.dll",
                    "sharpod.dll", "x64dbg.dll", "x32dbg.dll",
                    "ollydbg.dll", "strongod.dll", "phnt.dll"
                };

                foreach (ProcessModule module in currentProcess.Modules)
                {
                    try
                    {
                        string moduleName = module.ModuleName.ToLowerInvariant();
                        foreach (string suspicious in suspiciousModules)
                        {
                            if (moduleName == suspicious)
                                return true;
                        }
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 检测调试器进程名
        /// </summary>
        private static bool CheckDebuggerProcesses()
        {
            try
            {
                string[] debuggerProcesses = {
                    "x64dbg", "x32dbg", "x96dbg", "ollydbg",
                    "ida", "ida64", "windbg", "windbg64",
                    "dnspy", "cheatengine",
                    "immunitydebugger"
                };

                Process[] processes = Process.GetProcesses();
                foreach (Process proc in processes)
                {
                    try
                    {
                        string processName = proc.ProcessName.ToLowerInvariant();
                        foreach (string debugger in debuggerProcesses)
                        {
                            if (processName.Contains(debugger))
                                return true;
                        }
                    }
                    catch { }
                }
            }
            catch { }
            return false;
        }

        #endregion

        #region 守护线程

        private static void GuardianLoop()
        {
            while (_guardianRunning)
            {
                try
                {
                    Thread.Sleep(30000); // 每30秒检测一次

                    if (!_guardianRunning)
                        break;

                    // 1. 反调试检测
                    if (CheckAll())
                    {
                        LogSecurityAlert("GuardianThread");
                        ExecutePenalty();
                    }

                    // 2. 校验授权系统是否被篡改（相辅相成）
                    //    如果破解者跳过了授权校验，这里会检测到
                    if (IsLicenseSystemTampered())
                    {
                        LogSecurityAlert("LicenseSystemTampered");
                        ExecutePenalty();
                    }
                }
                catch { }
            }
        }

        #endregion

        #region 惩罚措施

        private static void ExecutePenalty()
        {
            if (_penaltyTriggered)
                return;

            _penaltyTriggered = true;
            StopGuardian();

            // 1. 删除授权文件
            DeleteLicenseFile();

            // 2. 写入注册表黑名单
            WriteBlacklistToRegistry();

            // 3. 联网上报服务端（异步）
            ReportTamperingToServer();

            // 4. 随机延迟 10-30 秒
            int delaySeconds = _random.Next(10, 30);
            Thread.Sleep(delaySeconds * 1000);

            // 5. 随机选择惩罚方式
            int penaltyType = _random.Next(1, 4);
            switch (penaltyType)
            {
                case 1:
                    MessageBox.Show("系统检测到异常环境，程序已退出", "安全提示",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Environment.Exit(0);
                    break;
                case 2:
                    MessageBox.Show("程序遇到未知错误，即将关闭", "错误",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Environment.Exit(1);
                    break;
                case 3:
                    Environment.Exit(0);
                    break;
            }
        }

        private static void DeleteLicenseFile()
        {
            try
            {
                string licensePath = Path.Combine(
                    Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                    "license.dat");

                if (File.Exists(licensePath))
                {
                    byte[] garbage = new byte[1024];
                    _random.NextBytes(garbage);
                    File.WriteAllBytes(licensePath, garbage);
                    File.Delete(licensePath);
                }
            }
            catch { }
        }

        private static void WriteBlacklistToRegistry()
        {
            try
            {
                using (var key = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(REGISTRY_PATH))
                {
                    if (key != null)
                    {
                        key.SetValue(REGISTRY_BLACKLIST_KEY, 1);
                        key.SetValue("TamperTime",
                            DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
                    }
                }
            }
            catch { }
        }

        private static void ReportTamperingToServer()
        {
            try
            {
                Thread reportThread = new Thread(() =>
                {
                    try
                    {
                        string machineCode = MachineCodeHelper.GenerateMachineCode();
                        string licenseKey = LicenseHelper.CurrentLicenseKey;

                        var data = new Dictionary<string, string>
                        {
                            { "machine_code", machineCode },
                            { "license_key", licenseKey },
                            { "hostname", Environment.MachineName },
                            { "action", "tamper_report" },
                            { "timestamp", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") }
                        };

                        string json = BuildJson(data);
                        string serverUrl = CryptoHelper.DecodeLicenseUrl();

                        using (var client = new System.Net.Http.HttpClient())
                        {
                            client.Timeout = TimeSpan.FromSeconds(10);
                            var content = new System.Net.Http.StringContent(
                                json, Encoding.UTF8, "application/json");
                            var response = client.PostAsync(serverUrl + "report_tamper", content)
                                .GetAwaiter().GetResult();
                        }
                    }
                    catch { }
                })
                {
                    IsBackground = true,
                    Name = "TamperReportThread"
                };
                reportThread.Start();
            }
            catch { }
        }

        private static string BuildJson(Dictionary<string, string> data)
        {
            var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            var obj = new Dictionary<string, object>();
            foreach (var kv in data)
            {
                obj[kv.Key] = kv.Value;
            }
            return serializer.Serialize(obj);
        }

        private static void LogSecurityAlert(string location)
        {
            try
            {
                string logMessage = string.Format("[SECURITY] {0:yyyy-MM-dd HH:mm:ss} - 反调试触发 - {1}\r\n",
                    DateTime.Now, location);
                string logPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "PrintServer", "security.log");

                Directory.CreateDirectory(Path.GetDirectoryName(logPath));
                File.AppendAllText(logPath, logMessage);
            }
            catch { }
        }

        #endregion
    }
}
