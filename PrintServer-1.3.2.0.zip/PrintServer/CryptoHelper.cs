using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace PrintServer
{
    /// <summary>
    /// 加解密辅助类
    /// 提供 RSA 签名验证、HMAC-SHA256、AES-256-CBC、DPAPI 加密
    /// 
    /// ⚠️ 重要：修改 URL 请修改 AssemblyInfo.cs 中的 AssemblyLicenseUrl 属性
    /// 编译后不可通过配置文件修改
    /// </summary>
    public static class CryptoHelper
    {
        // 本地 AES 密钥（用于本地缓存等内部加密，不与 PHP 服务端交互）
        private static readonly byte[] AesKey = Encoding.UTF8.GetBytes("P5@ntS3rv3rK3y!9");
        private static readonly byte[] AesIv = Encoding.UTF8.GetBytes("P5@ntS3rv3r1v@9!");

        /// <summary>
        /// 从 Assembly 属性读取授权服务器 URL
        /// </summary>
        public static string DecodeLicenseUrl()
        {
            try
            {
                var assembly = System.Reflection.Assembly.GetExecutingAssembly();
                var attributes = assembly.GetCustomAttributes(typeof(AssemblyLicenseUrlAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var attr = (AssemblyLicenseUrlAttribute)attributes[0];
                    string url = attr.Url;
                    if (!string.IsNullOrEmpty(url))
                        return url;
                }
            }
            catch
            {
            }
            return "https://www.itlog.vip/api/ps/v1/"; // 默认值
        }

        #region RSA 签名验证

        /// <summary>
        /// 验证 RSA 签名
        /// </summary>
        public static bool VerifySignature(string data, string signature, string publicKey)
        {
            try
            {
                using (RSA rsa = RSA.Create())
                {
                    rsa.FromXmlString(publicKey);
                    byte[] dataBytes = Encoding.UTF8.GetBytes(data);
                    byte[] signatureBytes = Convert.FromBase64String(signature);

                    return rsa.VerifyData(dataBytes, signatureBytes, HashAlgorithmName.SHA256, RSASignaturePadding.Pkcs1);
                }
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region HMAC-SHA256 验证

        /// <summary>
        /// 生成 HMAC-SHA256 签名
        /// </summary>
        public static string GenerateHmacSignature(string data, string secret)
        {
            try
            {
                byte[] keyBytes = Encoding.UTF8.GetBytes(secret);
                byte[] dataBytes = Encoding.UTF8.GetBytes(data);

                using (HMACSHA256 hmac = new HMACSHA256(keyBytes))
                {
                    byte[] hash = hmac.ComputeHash(dataBytes);
                    return Convert.ToBase64String(hash);
                }
            }
            catch
            {
                return "";
            }
        }

        /// <summary>
        /// 验证 HMAC-SHA256 签名
        /// </summary>
        public static bool VerifyHmacSignature(string data, string signature, string secret)
        {
            try
            {
                string expected = GenerateHmacSignature(data, secret);
                return string.Equals(expected, signature, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        #endregion

        #region AES-256-CBC 内部加密/解密（用于本地缓存，不与 PHP 交互）

        /// <summary>
        /// AES-256-CBC 加密并输出 Base64（使用内部固定密钥，仅用于本地存储）
        /// </summary>
        public static string AesEncryptToBase64(string plainText)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = GetAes256Key();
                    aes.IV = AesIv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    ICryptoTransform encryptor = aes.CreateEncryptor();
                    byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                    byte[] encrypted = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                    return Convert.ToBase64String(encrypted);
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// AES-256-CBC 解密（从 Base64，使用内部固定密钥，仅用于本地存储）
        /// </summary>
        public static string AesDecryptFromBase64(string encryptedBase64)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = GetAes256Key();
                    aes.IV = AesIv;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = aes.CreateDecryptor();
                    byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
                    byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                    return Encoding.UTF8.GetString(decrypted);
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 将密钥扩展到 256 位（32 字节）
        /// </summary>
        private static byte[] GetAes256Key()
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(AesKey);
            }
        }

        #endregion

        #region AES-256-CBC 服务端兼容加密/解密（与 PHP 端保持一致，用于 .lic 文件）

        /// <summary>
        /// 使用与服务端 PHP 一致的 AES-256-CBC 加密
        /// Key = SHA256(secret), IV = SHA256(secret + "iv_salt") 的前16字节
        /// </summary>
        public static string AesEncryptWithSecret(string plainText, string secret)
        {
            try
            {
                byte[] keyBytes = Sha256Bytes(secret);
                byte[] ivBytes = Sha256Bytes(secret + "iv_salt");
                Array.Resize(ref ivBytes, 16);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = keyBytes;
                    aes.IV = ivBytes;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    ICryptoTransform encryptor = aes.CreateEncryptor();
                    byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                    byte[] encrypted = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);

                    return Convert.ToBase64String(encrypted);
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 使用与服务端 PHP 一致的 AES-256-CBC 解密
        /// Key = SHA256(secret), IV = SHA256(secret + "iv_salt") 的前16字节
        /// </summary>
        public static string AesDecryptWithSecret(string encryptedBase64, string secret)
        {
            try
            {
                byte[] keyBytes = Sha256Bytes(secret);
                byte[] ivBytes = Sha256Bytes(secret + "iv_salt");
                Array.Resize(ref ivBytes, 16);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = keyBytes;
                    aes.IV = ivBytes;
                    aes.Mode = CipherMode.CBC;
                    aes.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = aes.CreateDecryptor();
                    byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
                    byte[] decrypted = decryptor.TransformFinalBlock(encryptedBytes, 0, encryptedBytes.Length);

                    return Encoding.UTF8.GetString(decrypted);
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 计算字符串的 SHA256 原始字节
        /// </summary>
        private static byte[] Sha256Bytes(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                return sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
            }
        }

        #endregion

        #region DPAPI 加密/解密（用于本地授权缓存）

        /// <summary>
        /// DPAPI 加密并输出 Base64
        /// </summary>
        public static string EncryptToBase64(string plainText)
        {
            try
            {
                byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                byte[] encrypted = ProtectedData.Protect(plainBytes, null, DataProtectionScope.CurrentUser);
                return Convert.ToBase64String(encrypted);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// DPAPI 解密（从 Base64）
        /// </summary>
        public static string DecryptFromBase64(string encryptedBase64)
        {
            try
            {
                byte[] encryptedBytes = Convert.FromBase64String(encryptedBase64);
                byte[] decrypted = ProtectedData.Unprotect(encryptedBytes, null, DataProtectionScope.CurrentUser);
                return Encoding.UTF8.GetString(decrypted);
            }
            catch
            {
                return null;
            }
        }

        #endregion

        #region 离线 .lic 文件解密（修复：统一使用与服务端 PHP 一致的 AES 派生方式）

        /// <summary>
        /// 解密离线授权 .lic 文件
        /// 已修复：使用与服务端 PHP 一致的 AES-256-CBC 解密
        ///   Key = SHA256(secret), IV = SHA256(secret + "iv_salt") 的前16字节
        /// </summary>
        /// <param name="encryptedData">.lic 文件中的 data 字段（AES加密+Base64）</param>
        /// <param name="signature">.lic 文件中的 sig 字段（HMAC签名）</param>
        /// <param name="secret">密钥（默认 printserver-license-secret）</param>
        /// <returns>解密成功返回 JSON 字符串，失败返回 null</returns>
        public static string DecryptLicenseFile(string encryptedData, string signature, string secret)
        {
            try
            {
                // 1. 验证 HMAC 签名（用加密后的 data 验签）
                if (!VerifyHmacSignature(encryptedData, signature, secret))
                {
                    return null;
                }

                // 2. 使用与服务端 PHP 一致的 AES-256-CBC 解密
                //    注意：这里必须用 AesDecryptWithSecret，不能用旧的 AesDecryptFromBase64
                string decrypted = AesDecryptWithSecret(encryptedData, secret);
                return decrypted;
            }
            catch
            {
                return null;
            }
        }

        #endregion
    }
}
